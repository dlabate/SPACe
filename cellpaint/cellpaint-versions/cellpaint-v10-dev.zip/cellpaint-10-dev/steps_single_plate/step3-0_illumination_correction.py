import tifffile
from pathlib import WindowsPath
import matplotlib.pyplot as plt

import numpy as np
from joblib import memory
from scipy import ndimage as ndi
from skimage.filters import median

"""
Given a 384 well plate, We would like to correct the illumination of the image across all wells.
So here is my work follow:
    1) Find the average image
    2) Find the dilated image  (Does not apply to our case)
    3) Find the smoothed image
    4) Find the scale image    (Does not apply to our case)
"""


class IlluminationCorrection:
    """Taken from
    https://github.com/CellProfiler/CellProfiler/blob/master/cellprofiler/modules/correctilluminationcalculate.py
    https://github.com/CellProfiler/CellProfiler/blob/master/cellprofiler/modules/correctilluminationapply.py
    """
    block_size = 60
    object_width = 90
    border_size = 50
    smoothing_filter_size = object_width/3.5

    def __init__(self):
        self.get_mask_img = memory.cache(self.get_mask_img)

    def run(self, img_path):
        orig_image = tifffile.imread(img_path)
        bg_img = self.step0_preprocess_image_for_averaging(orig_image)
        illum_function_img = self.step1_apply_smoothing(bg_img)
        output_img = self.step2_apply(orig_image, illum_function_img)
        print(orig_image.dtype, np.amin(orig_image), np.amax(orig_image))
        print(bg_img.dtype, np.amin(bg_img), np.amax(bg_img))
        print(illum_function_img.dtype,
              np.amin(illum_function_img),
              np.amax(illum_function_img))
        print(output_img.dtype, np.amin(output_img), np.amax(output_img))
        fig, axes = plt.subplots(2, 2, sharex=True, sharey=True)
        axes[0, 0].imshow(orig_image, cmap="gray")
        axes[0, 1].imshow(bg_img, cmap="gray")
        axes[1, 0].imshow(illum_function_img, cmap="gray")
        axes[1, 1].imshow(output_img, cmap="gray")
        plt.show()

    def get_mask_img(self, img):
        mask_img = np.zeros_like(img, dtype=bool)
        mask_img[
            :self.border_size, img.shape[0]-self.border_size:,
            :self.border_size, img.shape[1]-self.border_size:] = 1
        return mask_img

    def step0_preprocess_image_for_averaging(self, orig_image):
        # Here we are assuming the original image has mask!!!

        """Create a version of the image appropriate for averaging"""
        # For background, we create a labels image using the block
        # size and find the minimum within each block.
        labels, indexes = self.block_fn(orig_image.shape[:2], (self.block_size, self.block_size))
        # if orig_image.has_mask:
        #     labels[~orig_image.mask] = -1
        labels[self.mask_img] = -1

        min_block = np.zeros(orig_image.shape, dtype=np.float32)
        minima = self.fixup_scipy_ndimage_result(ndi.minimum(orig_image, labels, indexes))
        min_block[labels != -1] = minima[labels[labels != -1]]
        print(labels.dtype, labels.shape, np.unique(labels))
        print(indexes.dtype, indexes.shape)
        print(minima.dtype, minima.shape)
        print(min_block.dtype, min_block.shape)
        return min_block

    def step1_apply_smoothing(self, pixel_data):
        # sigma = self.smoothing_filter_size
        filter_sigma = max(1, int(self.smoothing_filter_size + 0.5))
        print(self.smoothing_filter_size, filter_sigma)
        strel = self.strel_disk(filter_sigma)
        rescaled_pixel_data = pixel_data * 65535
        rescaled_pixel_data = rescaled_pixel_data.astype(np.uint16)
        # rescaled_pixel_data *= mask
        output_pixels = median(rescaled_pixel_data, strel, behavior="rank")
        return output_pixels

    @staticmethod
    def step2_apply(orig_image, illum_function_pixel_data):
        output_pixels = orig_image - illum_function_pixel_data
        output_pixels[output_pixels < 0] = 0
        return output_pixels

    @staticmethod
    def fixup_scipy_ndimage_result(whatever_it_returned):
        """
        Taken from https://github.com/CellProfiler/centrosome/blob/master/centrosome/cpmorphology.py

            Convert a result from scipy.ndimage to a numpy array

            scipy.ndimage has the annoying habit of returning a single, bare
            value instead of an array if the indexes passed in are of length 1.
            For instance:
            scind.maximum(image, labels, [1]) returns a float
            but
            scind.maximum(image, labels, [1,2]) returns a list
        """
        if getattr(whatever_it_returned, "__getitem__", False):
            return np.array(whatever_it_returned)
        else:
            return np.array([whatever_it_returned])

    @staticmethod
    def block_fn(shape, block_shape):
        """
        Taken from https://github.com/CellProfiler/centrosome/blob/master/centrosome/cpmorphology.py

            Create a labels image that divides the image into blocks

            shape - the shape of the image to be blocked
            block_shape - the shape of one block

            returns a labels matrix and the indexes of all labels generated

            The idea here is to block-process an image by using SciPy label
            routines. This routine divides the image into blocks of a configurable
            dimension. The caller then calls scipy.ndimage functions to process
            each block as a labeled image. The block values can then be applied
            to the image via indexing. For instance:

            labels, indexes = block(image.shape, (60,60))
            minima = scind.minimum(image, labels, indexes)
            img2 = image - minima[labels]
        """
        shape = np.array(shape)
        block_shape = np.array(block_shape)
        i, j = np.mgrid[0: shape[0], 0: shape[1]]
        ijmax = (shape.astype(float) / block_shape.astype(float)).astype(int)
        ijmax = np.maximum(ijmax, 1)
        multiplier = ijmax.astype(float) / shape.astype(float)
        i = (i * multiplier[0]).astype(int)
        j = (j * multiplier[1]).astype(int)
        labels = i * ijmax[1] + j
        indexes = np.array(list(range(np.product(ijmax))))
        return labels, indexes

    @staticmethod
    def strel_disk(radius):
        """
        Taken from https://github.com/CellProfiler/centrosome/blob/master/centrosome/cpmorphology.py

            Create a disk structuring element for morphological operations

            radius - radius of the disk
        """
        iradius = int(radius)
        x, y = np.mgrid[-iradius: iradius + 1, -iradius: iradius + 1]
        radius2 = radius * radius
        strel = np.zeros(x.shape)
        strel[x * x + y * y <= radius2] = 1
        return strel


if __name__ == "__main__":
    myclass = IlluminationCorrection()
    main_path = WindowsPath(r"P:\tmp\MBolt\Cellpainting\Cellpainting-Flavonoid")
    exp_fold = "20230413-CP-MBolt-FlavScreen-RT4-1-3_20230415_005621"
    img_fold = "AssayPlate_PerkinElmer_CellCarrier-384"
    img_path = "AssayPlate_PerkinElmer_CellCarrier-384_A01_T0001F001L01A01Z01C01.tif"
    myclass.run(main_path/exp_fold/img_fold/img_path)
