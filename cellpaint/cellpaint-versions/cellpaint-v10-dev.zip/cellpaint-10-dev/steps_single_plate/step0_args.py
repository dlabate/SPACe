import re
import argparse
import warnings
from sys import platform
from typing import Union
from pathlib import WindowsPath, PosixPath, Path

import math
import xlrd
import string
import numbers
import numpy as np
import pandas as pd
from tifffile import imread

# TODO: Add proper documentation for all the different class
# TODO: Add a README file that explains the steps,
#  the purpose behind each step, as well as the arguments that can be changed
# TODO: Fix Step 7 & Step of cellpaint for all the different cases


class Args():
    """
    creates self.args namespace that takes in all the constants necessary to perform the cell-paint analysis
    """
    analysis_step = 0

    # TODO: remove dependency on the OS for pathlib path objects.
    def __init__(
            self,
            experiment,
            main_path="F:\\CellPainting",
            mode="full",
            analysis_part=1,
            organelles=("Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"),  # the name assigned to each channel
            ####################################################################
            # hyperparameters/constants used in Cellpaint Step 0
            #######################################################################
            nucleus_idx=0,
            cyto_idx=1,
            nucleoli_idx=2,
            actin_idx=3,
            mito_idx=4,
            max_chars=21,
            n_fovs_per_well=9,

            # hyperparameters/constants used in Cellpaint Step 1
            #######################################################################
            cellpose_nucleus_diam=100,
            cellpose_cyto_diam=100,
            cellpose_batch_size=64,

            # hyperparameters/constants used in Cellpaint Step 2
            #######################################################################
            min_fov_cell_count=20,
            w0_bd_size=300,
            # min_cyto_size=1500,
            min_nucleus_size=1000,
            # nucleoli segmentation hyperparameters
            nucleoli_channel_rescale_intensity_percentile_ub=99,
            nucleoli_bd_area_to_nucleoli_area_threshold=.2,
            min_nucleoli_size_multiplier=.005,
            max_nucleoli_size_multiplier=.3,
            nucleus_area_to_cyto_area_thresh=.75,

            # hyperparameters/constants used in Cellpaint Step 4 & Cellpaint Step 5
            #######################################################################
            min_well_cell_count=100,

            # hyperparameters/constants used in Cellpaint Step 4
            #######################################################################
            # The 3 hyperparameters used to quality a well as pass or fail
            qc_fail_compartment_count=4,
            qc_mad_multiplier=7,
            qc_pass_dynamic_range_thresh=.1,
            # minimum cell count/row count in the features dataframe,
            # to qualify a (cell-line, density, treatment, dosage) case for QC Wasserstein Distance Calc
            qc_min_feat_rows=450,
            # total number of wells that are batched together in the pytorch-dataset for QC
            qc_batch_size=16,

            # hyperparameters/constants used in Cellpaint Step 5
            #######################################################################
            # minimum number of cells which is the number of rows in the features dataframe,
            # to qualify a (cell-line, density, treatment) case for Distmap Wasserstein Distance Calc
            distmap_min_feat_rows=1000,
            distmap_batch_size=64,

            # hyperparameters/constants used in Cellpaint Step 7
            #######################################################################
            hit_compartment_count=4,
            hit_mad_mult=10,
            controls_only=False,
            hit_calling=True,
    ):
        """
        experiment:
            The name of the experiment folder to perform cellpaint analysis on
        main_path:
            The name of the mother folder where the experiment data (images and platemap) are located
        mode:
            whether to run the analysis steps_single_plate (.py files) in debug mode, test mode,
            or full mode.
            args.mode=test or args.mode=ful should be used when the code is already debugged
            and we can use the multiproccessing pool during segmentation/step2
             and feature extraction/step3 for speed up
        analysis_part:
            Determine whether we are in part I or part II of image analysis.
            For all cellpaint part I steps, we need the image folder and image dimensions.
            For all of Cellpaint part II steps, we DO NOT need the image folder and image dimensions.
            So, sometimes we would like to analyse

        min_fov_cell_count:
            minimum # of segmented cells, in a single FOV, to not skip image during segmentation,
            cellpaint step1 and cellpaint step2
        min_well_cell_count:
            "minimum # of segmented cells, in a single well, to not skip the well during
            Wasserstein-distance calculation"
        nucleus_idx:
            Nucleus channel index in the tif image(~w1)
        Cyto channel index in the tif image(~w2)
        Nucleoli channel index in the tif image(~w3)
        Actin channel index in the tif image(~w4)
        Mito channel index in the tif image(~w5)
        """

        # # TODO: Fix this because can have args passing in through terminal, with the current implementation.
        # for all the steps_single_plate
        parser = argparse.ArgumentParser(description='Cell-paint')
        # # the order of the channel for images taken by fabio at baylor is as follows:
        # # w1: Nucleus channel, w2: cyto channel, w3: nucleoli channel, w4: actin channel, w5: mito channel
        # parser.add_argument("--min_fov_cell_count", type=int, default=20,
        #                     help="minimum # of segmented cells, in a single FOV, to not skip image")
        # parser.add_argument("--min_well_cell_count", type=int, default=100,
        #                     help="minimum # of segmented cells, in a single well, to not skip image")
        #
        # parser.add_argument("--nucleus_idx", type=int, default=0, help="Nucleus channel index in the tif image(~w1)")
        # parser.add_argument("--cyto_idx", type=int, default=1, help="Cyto channel index in the tif image(~w2)")
        # parser.add_argument("--nucleoli_idx", type=int, default=2,
        #                     help="Nucleoli channel index in the tif image(~w3)")
        # parser.add_argument("--actin_idx", type=int, default=3, help="Actin channel index in the tif image(~w4)")
        # parser.add_argument("--mito_idx", type=int, default=4, help="Mito channel index in the tif image(~w5)")
        # parser.add_argument("--max_chars", type=int, default=21,
        #                     help="treatment or cellline name maximum number of chars to display "
        #                          "in case the name is too long!")
        # parser.add_argument("--controls_only", type=bool, default=False,
        #                     help="whether to generate ROC-Curve and ROC-AUC only for the control treatments!")
        # parser.add_argument("--hit_calling", type=bool, default=True,
        #                     help="whether to perform hit-calling analysis!")

        self.args = parser.parse_args()
        self.args.mode = mode
        self.args.show_masks = True
        self.args.main_path = WindowsPath(main_path)
        self.args.experiment = experiment

        # Cellpaint Step 0) that can be tuned to the plate and image dimensions
        #######################################################################
        self.args.analysis_part = analysis_part
        self.args.nucleus_idx = nucleus_idx
        self.args.cyto_idx = cyto_idx
        self.args.nucleoli_idx = nucleoli_idx
        self.args.actin_idx = actin_idx
        self.args.mito_idx = mito_idx
        self.args.n_fovs_per_well = n_fovs_per_well
        self.args.max_chars = max_chars

        #######################################################################
        # Cellpaint Step 1) that can be tuned to the plate and image dimensions
        self.args.min_fov_cell_count = min_fov_cell_count
        self.args.cellpose_nucleus_diam = cellpose_nucleus_diam
        self.args.cellpose_cyto_diam = cellpose_cyto_diam
        self.args.cellpose_batch_size = cellpose_batch_size

        #######################################################################
        # Cellpaint Step 2) argumnets that can be tuned to the plate and image dimensions
        # nuclues and cyto segmentation hyperparameters
        # min_cyto_size = 1500
        self.args.w0_bd_size = w0_bd_size
        self.args.min_nucleus_size = min_nucleus_size
        self.args.nucleus_area_to_cyto_area_thresh = nucleus_area_to_cyto_area_thresh
        # nucleoli segmentation hyperparameters
        self.args.min_nucleoli_size_multiplier = min_nucleoli_size_multiplier
        self.args.max_nucleoli_size_multiplier = max_nucleoli_size_multiplier
        self.args.nucleoli_bd_area_to_nucleoli_area_threshold = nucleoli_bd_area_to_nucleoli_area_threshold
        self.args.nucleoli_channel_rescale_intensity_percentile_ub = nucleoli_channel_rescale_intensity_percentile_ub

        #######################################################################
        # Cellpaint Step 4) arguments that can be tuned to the plate and image dimensions
        self.args.qc_fail_compartment_count = qc_fail_compartment_count
        self.args.qc_mad_multiplier = qc_mad_multiplier
        self.args.qc_pass_dynamic_range_thresh = qc_pass_dynamic_range_thresh
        # minimum cell count/row count in the features dataframe,
        # to qualify a (cell-line, density, treatment, dosage) case for QC
        self.args.qc_min_feat_rows = qc_min_feat_rows
        self.args.qc_batch_size = qc_batch_size

        ##########################################################################
        # Cellpaint Step 5) argument that can be tuned to the plate and image dimensions
        # minimum cell count/row count in the features dataframe,
        # to qualify a (cell-line, density, treatment, dosage) case for Wasserstein-distance-map calculation
        self.args.distmap_min_feat_rows = distmap_min_feat_rows
        self.args.distmap_batch_size = distmap_batch_size

        #######################################################################
        # Cellpaint Step 4) & Step 5) argument that can be tuned to the plate and image dimensions
        # minimum cell count/row count per well in the features dataframe,
        # to qualify a (cell-line, density, treatment, dosage, well-id) case for Wasserstein-distance-map calculation
        self.args.min_well_cell_count = min_well_cell_count
        #######################################################################
        # Cellpaint Step 7) arguments that can be tuned to the plate and image dimensions
        self.args.hit_compartment_count = hit_compartment_count
        self.args.hit_mad_mult = hit_mad_mult
        self.args.controls_only = controls_only
        self.args.hit_calling = hit_calling

        # In case we want to redo analysis after Cell-paint step 3 and the image folder is missing or
        # it has not been transferred!!!
        if self.args.analysis_part == 1:
            self.args.img_folder = list(filter(
                lambda x: "AssayPlate" in str(x),
                (self.args.main_path / self.args.experiment).iterdir()))[0].stem
            print("self.args.img_folder:", self.args.img_folder)
            # Get generic width and height dimensions of the image, in the specific experiment.
            # We assume height and width are the same for every single images, in the same experiment!!!
            if "perkinelmer" in self.args.img_folder.lower() or \
                    "greiner" in self.args.img_folder.lower() or \
                    "combchem" in self.args.img_folder.lower():
                self.args.plate_protocol = self.args.img_folder.split("_")[1].lower()
                self.args.height, self.args.width = imread(
                    list((self.args.main_path / self.args.experiment / self.args.img_folder).
                         rglob(f'{self.args.img_folder}_*.tif'))[0]).shape
                self.args.img_suffix = "tif"
            elif "cpg0012" in self.args.img_folder.lower():
                self.args.plate_protocol = self.args.img_folder
                self.args.height, self.args.width = imread(
                    list((self.args.main_path / self.args.experiment / self.args.img_folder).rglob("*.tif"))[0]).shape
                self.args.img_suffix = "tif"
            elif "cpg0001" in self.args.img_folder.lower():
                self.args.plate_protocol = self.args.img_folder
                self.args.height, self.args.width = imread(
                    list((self.args.main_path / self.args.experiment / self.args.img_folder).rglob("*.tiff"))[0]).shape
                self.args.img_suffix = "tiff"
            else:
                raise NotImplementedError("")

        self.platemap_filepath = list((self.args.main_path / self.args.experiment).rglob("platemap*.xlsx"))[0]

        self.add_save_path_args()
        # for Step 3) feature extraction
        self.add_platemap_args()
        self.add_feature_args(organelles)
        # for Step 4) Distance-map calculation
        self.add_platemap_anchor_args()
        # for Step 5) Quality Control
        self.add_platemap_control_args()
        # for debug mode
        self.add_other_args()  # for coloring cells when displaying images in test mode
        self.args.num_debug_images = 3

        # channel_dies = {
        #     "C1": "DAPI",  # nucleus
        #     "C2": "Concanavalin A",  # cyto
        #     "C3": "Syto14",  # nucleoli
        #     "C4": "WGA+Phalloidin",  # actin
        #     "C5": "MitoTracker",  # mito
        # }

    # def add_path_object(self,):
    #     # linux or mac machine
    #     if platform == "linux" or platform == "darwin":
    #         self.args.path_object = PosixPath
    #
    #     elif platform == "win32":
    #         self.args.path_object = WindowsPath

    @staticmethod
    def shorten_str(name, key, max_chars):
        name = name.lower()[0:max_chars]
        n = 7
        if key == "treatment":
            return name if len(name) <= n else '\n'.join([name[i:i+n] for i in range(0, len(name), n)])
        elif key == "cell-line":
            return '\n'.join(name.split('-'))
        else:
            NotImplementedError("")

    def add_save_path_args(self, ):
        """Create a saving folder for the results obtained at each step of the Cellpaint process."""

        # if self.args.mode.lower() == "debug":
        #     self.args.analysis_save_path = self.args.main_path / self.args.experiment / "Debug"
        # elif self.args.mode.lower() == "test":
        #     self.args.analysis_save_path = self.args.main_path / self.args.experiment / "Test"
        # elif self.args.mode.lower() == "full":
        #     self.args.analysis_save_path = self.args.main_path / self.args.experiment
        # else:
        #     raise ValueError("""self.args.mode value should be one of the following: debug  test full""")
        # define save folders
        self.args.analysis_save_path = self.args.analysis_save_path = self.args.main_path / self.args.experiment
        self.args.step1_save_path = self.args.analysis_save_path / "Step1_MasksP1"
        self.args.step2_save_path = self.args.analysis_save_path / "Step2_MasksP2"
        self.args.step3_save_path = self.args.analysis_save_path / "Step3_Features"
        self.args.step4_save_path = self.args.analysis_save_path / "Step4_QualityControl"
        self.args.step5_save_path = self.args.analysis_save_path / "Step5_DistanceMaps"
        self.args.step6_save_path = self.args.analysis_save_path / "Step6_HeatMaps"
        self.args.step7_save_path = self.args.analysis_save_path / "Step7_DerivativeMaps"
        self.args.step8_save_path = self.args.analysis_save_path / "Step8_HitCallingSensitivityAnalysis"

        # create the save folders if they do not already exist
        self.args.step1_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step2_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step3_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step4_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step5_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step6_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step7_save_path.mkdir(exist_ok=True, parents=True)
        self.args.step8_save_path.mkdir(exist_ok=True, parents=True)

    def add_platemap_args(self, ):
        """
        This step is a must for the analysis to work.
        It extracts all the necessary metadata self.args from all the sheets of the plate-map excel file,
        except the last one.
        """
        if self.args.experiment in [
            "2021-CP007",
            "2021-CP008",
            "20220607-CP-Fabio-U2OS-density-10x",
            "20220623-CP-Fabio-Seema-Transfected",
            "20220810-CP-Fabio-WGA-Restain",
            "others"
        ]:
            raise ValueError("Experiment not implemented or is in discard pile!")
        # TODO: check sheetnames and raise value error if sheetname is not present or is incorrect
        # xls = xlrd.open_workbook(self.platemap_filepath, on_demand=True)
        # print(xls.sheet_names())
        # xls.sheet_names()  # <- remeber: xlrd sheet_names is a function, not a property

        self.args.wellid2treatment = self.get_wellid2meta(sheetname="Treatment")
        self.args.wellid2cellline = self.get_wellid2meta(sheetname="CellLine")
        self.args.wellid2dosage = self.get_wellid2meta(sheetname="Dosage")
        self.args.wellid2density = self.get_wellid2meta(sheetname="Density")
        self.args.wellid2other = self.get_wellid2meta(sheetname="Other")

        wkeys = list(self.args.wellid2treatment.keys())
        vals = list(self.args.wellid2treatment.values())
        self.args.wellids = np.unique(wkeys)
        self.args.treatments = np.unique(vals)
        self.args.celllines = np.unique([str(it) for it in list(self.args.wellid2cellline.values())])

        if self.args.wellid2dosage is None:
            self.args.wellid2dosage = {key: 0 for key in wkeys}
            self.args.dosages = np.array([0])
        else:
            self.args.dosages = np.unique(list(self.args.wellid2dosage.values()))

        if self.args.wellid2density is None:
            self.args.wellid2density = {key: 0 for key in wkeys}
            self.args.densities = np.array([0])
        else:
            self.args.densities = np.unique(list(self.args.wellid2density.values()))

        if self.args.wellid2other is None:
            self.args.wellid2other = {key: 0 for key in wkeys}
            self.args.others = np.array([0])
        else:
            # print(list(self.args.wellid2other.values()))
            self.args.others = np.unique(list(self.args.wellid2other.values()))

        # print("treatments: ", self.args.treatments)
        # print("cell-lines: ", self.args.celllines)
        # print("densities: ", self.args.densities)
        # print("dosages: ", self.args.dosages)

        N = len(self.args.wellids)
        cols = ["well-id", "treatment", "cell-line", "density", "dosage", "other"]
        self.args.platemap = np.zeros((N, len(cols)), dtype=object)
        for ii, it in enumerate(self.args.wellids):
            self.args.platemap[ii, :] = \
                (it, self.args.wellid2treatment[it], self.args.wellid2cellline[it],
                 self.args.wellid2density[it], self.args.wellid2dosage[it], self.args.wellid2other[it])
        self.args.platemap = pd.DataFrame(self.args.platemap, columns=cols)
        # print(self.args.wellids)
        return self.args

    def add_platemap_anchor_args(self, ):
        """This step is necessary to automate step IV of the cellpaint Analysis"""
        # anchors
        meta = pd.read_excel(self.platemap_filepath, sheet_name="Anchor")
        self.args.anchor_treatment = meta["Treatment"].values[0]
        self.args.anchor_cellline = str(meta["CellLine"].values[0])
        self.args.anchor_density = meta["Density"].values[0]
        self.args.anchor_dosage = meta["Dosage"].values[0]
        self.args.anchor_other = meta["Other"].values[0]

        # fix the entries of the 5 columns in the "Anchor" sheet
        if self.args.anchor_treatment == np.nan:
            raise ValueError("self.args.anchor_treatment value cannot be Nan. Please specify a value for it.")
        elif self.args.anchor_treatment.lower() != "dmso":
            warnings.warn("self.args.anchor_treatment is not set to DMSO. "
                          "If it is set correctly, ignore this warning!")
        assert isinstance(self.args.anchor_treatment, str), "Anchor treatment must be a string!"

        self.args.anchor_treatment = self.args.anchor_treatment.lower()
        self.args.anchor_cellline = self.fix_anchor_val(self.args.anchor_cellline, "CellLine")
        self.args.anchor_density = self.fix_anchor_val(self.args.anchor_density, "Density")
        self.args.anchor_dosage = self.fix_anchor_val(self.args.anchor_dosage, "Dosage")
        self.args.anchor_other = self.fix_anchor_val(self.args.anchor_other, "Other")
        print(
            f"anchor treatment: {self.args.anchor_treatment}   "
            f"anchor cell-line: {self.args.anchor_cellline}   "
            f"anchor density: {self.args.anchor_density}   "
            f"anchor dosage: {self.args.anchor_dosage}   "
            f"anchor other: {self.args.anchor_other}")

        return self.args

    def add_platemap_control_args(self, ):
        """This step is necessary to automate step IV of the cellpaint Analysis"""
        # anchors
        meta = pd.read_excel(self.platemap_filepath, sheet_name="Control")["Treatment"].to_numpy()
        controls = [self.fix_entry(it, "Treatment") for it in meta]
        for it in controls:
            assert np.isin(it, self.args.treatments), \
                f"Control treatment {it} has to be present in list of treatments, but it is not!!!"
        # making sure control treatments always starts with self.args.anchor_treatment == "dmso"
        """https://stackoverflow.com/questions/1014523/
        simple-syntax-for-bringing-a-list-element-to-the-front-in-python"""
        controls.insert(0, controls.pop(controls.index(self.args.anchor_treatment)))
        # print("controls", controls)
        self.args.control_treatments = np.array(controls, dtype=object)
        print("control_treatments: ", self.args.control_treatments)

    def add_feature_args(self, organelles):
        """
        This step is mainly used in feature extraction/step3 of the cellpaint analysis.

        Create names, with certain rules, for all the extracted features columns, that going to be saved
        to the following csv files in "Features" folder:
        metadata_of_features.csv, misc_features.csv
        w0_features.csv, w1_features.csv, w2_features.csv, w3_features.csv, and w4_features.csv

        Also, we use median and mad statistics to summarize the haralick and moment features.
        This helps shrink the size/width of the feature-heatmap.
        """
        self.args.organelles = organelles
        self.args.num_channels = len(self.args.organelles)
        ################################################################################################
        # CSV Files column name
        # metadata_of_features.csv column anme
        self.args.metadata_cols = ["exp-id", "well-id", "fov", "treatment", "cell-line", "density", "dosage", "other"]
        # print(f"organelles before if statement: {self.args.organelles}")
        if "Nucleoli" in self.args.organelles:
            self.args.metadata_cols += ["has-nucleoli"]
        #############################################################################################
        # feature name compartments in order of appearance in the final heatmap
        self.args.heatmap_feature_groups = []
        #####################################################################################################
        # misc_feature.csv file column names (misc stands for miscellaneous and is used here because
        # these features do not belong to a specific channel
        self.args.misc_cols = [
            "nucleoli-count",
            "nucleus-area-TO-cyto-area",
            "mito-area-TO-cyto-area",
            "nucleoli-area-TO-nucleus-area"]
        self.args.misc_cols = [f"All_Miscs_{it}" for it in self.args.misc_cols]
        self.args.heatmap_feature_groups += ["Miscs"]
        #################################################################################################
        # features used in each w*_features.csv file in order of appearance
        # 0) bounding-box -> feature cols  (These 4 will be removed during distancemap and heatmap creation)
        self.args.bbox_cols = ["y0", "x0", "y1", "x1"]
        self.args.bbox_cols = [f"Bbox_{it}" for it in self.args.bbox_cols]
        # having these bounding-box columns helps going back to the images and putting feature numbers
        # as text over images for explainability. Without them, we do not know which cell resides where in each image.
        ####################################################################################################
        # 1) Shape -> feature cols
        self.args.shape_cols = \
            ["area", "convex-area", "perimeter", "perimeter-crofton",
             "circularity", "efc-ratio", "eccentricity", "equivalent-diam",
             "feret-diam-max", "solidity", "extent"]
        self.args.shape_cols = [f"Shapes_{it}" for it in self.args.shape_cols]
        self.args.heatmap_feature_groups += ["Shapes"]
        ###################################################################################################
        # 2) Intensity --> feature cols
        self.args.intensity_percentiles = [10, 15, 25, 40, 60, 75, 80, 90, 93, 95, 97, 99, 99.9, 99.99]
        self.args.intensity_cols = [f"{prc}%" for prc in self.args.intensity_percentiles] + \
                              ["median", "mad", "mean", "std"]
        self.args.intensity_cols = [f"Intensities_{it}" for it in self.args.intensity_cols]
        self.args.heatmap_feature_groups += ["Intensities"]
        ###################################################################################################
        # 3) Haralick -> feature cols
        self.args.haralick_names = ["contrast", "dissimilarity", "homogeneity", "asm", "correlation"]

        self.args.num_discrete_levels = 8
        self.args.angles = np.array([0, np.pi / 2], dtype=np.float32)
        self.args.angles_name = ["0", "pi/2"]  # TODO: Use symbolic to get string values for np.pi and np.pi/2
        self.args.stat_summaries = ["median", "mad"]
        self.args.distances = np.arange(1, 11, 1)
        self.args.haralick_cols = [
            f"{it1}-{it2}-{it3}"
            for it1 in self.args.haralick_names
            for it2 in self.args.stat_summaries
            for it3 in self.args.angles_name]
        self.args.haralick_cols = [f"Haralicks_{it}" for it in self.args.haralick_cols]
        self.args.heatmap_feature_groups += ["Haralicks"]
        # self.args.haralick_cols = [
        #     f'{mm}-{ii}-{jj}'
        #     for mm in self.args.haralick_names for jj in self.args.distances for ii in self.args.angles_name]
        #################################################################################################
        # 4) Scattering feature cols
        # self.args.scatter_cols = []  # say what they!!!
        # self.args.scatter_cols = [f"Scatter_{it}" for it in self.args.scatter_cols]
        # add scatter keyword to the begining
        # self.args.scatter_feature_groups += ["Scatter"]
        ###############################################################################################
        # # 5) Moment feature cols
        # self.args.moment_cols = \
        #     [f'{mm}-{ii}' for mm in ['local_cent', 'w-local-cent', ] for ii in [0, 1]] + \
        #     [f"{mm}-{st}"
        #      for mm in ["normalized", "w-normalized", "hue", "w-hue"]
        #      for st in ["median", "mad"]]
        # self.args.moment_cols = [f"Moments_{it}" for it in self.args.moment_cols]
        # self.args.heatmap_feature_groups += ["Moments"]
        # self.args.mn_ids = [2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        # # self.args.moment_cols = \
        # #     [f'moments_{mm}-{ii}' for mm in ['local_cent', 'w-local-cent', ] for ii in [0, 1]] + \
        # #     [f"moments_n-{ii}" for ii in self.args.mn_ids] + \
        # #     [f"moments_w-n-{ii}" for ii in self.args.mn_ids] + \
        # #     [f"moments_hue-{ii}" for ii in range(0, 7)] + \
        # #     [f"moments_w-hue-{ii}" for ii in range(0, 7)]
        ##########################################################################################################
        # w*_features.csv columns names
        self.args.feature_cols = self.args.bbox_cols + \
                            self.args.shape_cols + \
                            self.args.intensity_cols + \
                            self.args.haralick_cols
        #                    + self.args.scatter_cols
        self.args.organelle_cols = [[f"{it1}_{it2}" for it2 in self.args.feature_cols]
                                    for it1 in self.args.organelles]
        #####################################################################################################
        # These constants help with initializing our zeros-numpy-array/feature-accumulators with current dimensions,
        # inside the self.get_features function as wells as outside of it, when it is called over and over
        # in the self.run_loop function.
        self.args.num_organelles = len(self.args.organelles)
        self.args.num_metadata_cols = len(self.args.metadata_cols)
        # print(self.args.metadata_cols, self.args.num_metadata_cols)
        self.args.num_feat_cols = len(self.args.feature_cols)
        self.args.num_misc_cols = len(self.args.misc_cols)
        # starting feature column index for each column group in w*_feature
        self.args.n1 = len(self.args.bbox_cols)
        self.args.n2 = self.args.n1 + len(self.args.shape_cols)
        self.args.n3 = self.args.n2 + len(self.args.intensity_cols)
        self.args.n4 = self.args.n3 + len(self.args.haralick_cols)
        # self.args.n5 = self.args.n4 + len(self.args.scatter_cols)

    def add_other_args(self, ):
        self.args.colors = [
            "red", "green", "blue", "orange", "purple", "lightgreen", "yellow", "pink",
            "khaki", "lime", "olivedrab", "azure", "orchid", "darkslategray",
            "peru", "tan"]
        self.args.csfont = {"fontname": "Comic Sans MS", "fontsize": 16}
        return self.args

    def get_wellid2meta(self, sheetname):
        platemap_filepath = list((self.args.main_path / self.args.experiment).rglob("platemap*.xlsx"))[0]
        meta = pd.read_excel(platemap_filepath, sheet_name=sheetname)
        meta.index = meta["Unnamed: 0"]
        meta.index.name = "row_id"
        meta.drop(["Unnamed: 0", ], axis=1, inplace=True)
        if meta.isnull().values.all():
            return None
        meta = meta.loc[~np.all(meta.isna(), axis=1), ~np.all(meta.isna(), axis=0)]
        wellid2meta = {}
        for row_id in meta.index:
            for col_id in meta.columns:
                wellid2meta[f"{row_id}{str(col_id).zfill(2)}"] = self.fix_entry(meta.loc[row_id, col_id], sheetname)
        return wellid2meta

    @staticmethod
    def fix_entry(entry, belongs_to):
        # print("fix_entry", entry)
        if belongs_to == "Dosage":
            assert isinstance(entry, numbers.Number), "Must be int or float"
            return entry
        elif belongs_to == "Density":
            assert isinstance(entry, numbers.Number), "Must be int or float"
            return np.uint64(entry)

        elif belongs_to in ["Treatment", "CellLine"]:
            if isinstance(entry, str):
                entry = entry.lstrip().strip()
                entry = entry.replace(" + ", '+')
                entry = entry.replace(' ', '-').replace('_', '-')
                return entry.lower()
            elif isinstance(entry, numbers.Number):
                return str(entry)
            else:
                raise ValueError("Data type not supported!!!")
        elif belongs_to == "Other":
            if isinstance(entry, str):
                entry = entry.lstrip().strip()
                entry = entry.replace(" + ", '+')
                entry = entry.replace(' ', '-').replace('_', '-')
                return entry.lower()
            elif isinstance(entry, numbers.Number):
                return entry
            else:
                raise ValueError("Data type not supported!!!")

    def fix_anchor_val(self, val, belongs_to):
        return 0 if isinstance(val, numbers.Number) and math.isnan(val) else self.fix_entry(val, belongs_to)
