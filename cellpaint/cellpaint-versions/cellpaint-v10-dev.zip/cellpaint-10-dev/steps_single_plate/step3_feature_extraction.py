import time
from tqdm import tqdm
from pathlib import WindowsPath


import numpy as np
import pandas as pd


import tifffile
from scipy.ndimage import find_objects
from scipy.stats import median_abs_deviation
import skimage.io as sio
from skimage.measure import label

from cellpaint.utils.shared_memory import MyBaseManager, TestProxy, create_shared_np_num_arr
from cellpaint.utils.img_files import get_all_file_paths, sort_key_for_imgs, sort_key_for_masks, load_img
from cellpaint.utils.extensions_skimage import RegionPropertiesExtension
from cellpaint.steps_single_plate.step0_args import Args

import re
import warnings
from PIL import Image
import multiprocessing as mp
from functools import partial, lru_cache
from ctypes import c_int


class FeatureExtractor:
    """The heatmp and distmap classes slightly depend on this class because of args.
    This dependency needs to be resolved for clarity and ease of use.
    """
    analysis_step = 3
    cell_count_per_fov_ub = 2000
    cache_max_size = 5
    n_channels_calc = 10
    n_levels = 16
    distances = np.arange(1, 21)
    angles = np.array([0, np.pi/2, np.pi])
    testing = True
    intensity_percentiles = [5, 10, 25, 75, 90, 95]

    def __init__(self, args):
        self.args = args

        self.img_path_groups, self.w1_mask_paths, self.w2_mask_paths, args.num_channels = \
            get_all_file_paths(
                args.main_path, args.experiment, args.analysis_save_path,
                args.plate_protocol, mask_folder=args.step2_save_path.stem,
                nucleus_idx=self.args.nucleus_idx, cyto_idx=self.args.cyto_idx)
        self.N = len(self.img_path_groups)
        print(f"number of images in step III: {self.N}")
        # there has to be at least 8 cpu cores available on the computer.
        self.num_workers = min(8, mp.cpu_count(), self.N)

        self.w3_mask_paths = [it.parents[0] / f"w2_{'_'.join(it.stem.split('_')[1:])}.png" for it in self.w1_mask_paths]
        self.w5_mask_paths = [it.parents[0] / f"w4_{'_'.join(it.stem.split('_')[1:])}.png" for it in self.w1_mask_paths]
        # Each image group must match with its corresponding set of 4 masks (w0_mask, w1_mask, w2_mask, w5_mask).
        self.assert_matchings()
        # sometimes some well_ids coming from image files might be missing from the provided platemap,
        # on the other hand, sometimes some well_ids from the platemap might have no corresponding image file
        # in the experiment folder, in both cases the user should be warned by the program.
        self.warn_user_about_missing_wellids()

    @staticmethod
    def containsLetterAndNumber(input):
        """https://stackoverflow.com/questions/64862663/how-to-check-if-a-string-is-strictly-
        contains-both-letters-and-numbers"""
        return input.isalnum() and not input.isalpha() and not input.isdigit()

    def assert_matchings(self, ):
        """ match well_id, and fov between
        img_channels_group, w0_mask_path, w1_mask_path, and w2_mask_path
        Each image group will match with its corresponding mask."""
        # check if the number items in each file group match
        N = len(self.img_path_groups)
        assert N == len(self.w1_mask_paths) == len(self.w2_mask_paths)  # == len(w2_mask_paths) == len(w5_mask_paths)

        # check whether all images have the same number of channels
        # M = len(self.img_path_groups[0])
        # for ii in range(N):
        #     assert M == len(self.img_path_groups[ii])

        # check whether keys between mask files and image (per channel) match
        for ii in range(N):
            key = sort_key_for_masks(self.w1_mask_paths[ii])
            assert key == \
                   sort_key_for_masks(self.w2_mask_paths[ii]) == \
                   sort_key_for_masks(self.w3_mask_paths[ii]) == \
                   sort_key_for_masks(self.w5_mask_paths[ii])

            for jj in range(len(self.img_path_groups[ii])):
                assert sort_key_for_imgs(
                    self.img_path_groups[ii][jj],
                    self.args.plate_protocol,
                    sort_purpose="to_match_it_with_mask_path") == key

    def warn_user_about_missing_wellids(self, ):
        wellids_from_img_files = [
            sort_key_for_imgs(it[0], self.args.plate_protocol, sort_purpose="to_get_well_id")
            for it in self.img_path_groups]
        wellids_from_platemap = self.args.wellids

        missig_wells_1 = np.setdiff1d(wellids_from_img_files, wellids_from_platemap)
        missig_wells_2 = np.setdiff1d(wellids_from_platemap, wellids_from_img_files)

        if len(missig_wells_1) > 0:
            raise ValueError(
                f"The following well-ids are in the image-folder  {self.args.experiment},\n"
                f" but are missing from the platemap file:\n"
                f"{missig_wells_1}")
        elif len(missig_wells_2) > 0:
            warnings.warn(
                f"The following well-ids are in the platemap file,\n"
                f" but are missing from the image-folder  {self.args.experiment}:\n"
                f"{missig_wells_2}\n\n"
                f"DO NOT WORRY ABOUT THIS IF args.mode==test or args.mode==debug!")
        else:
            print("no well-id is missing!!! Enjoy!!!")

    def get_metadata(self, index):
        w1_mask = np.array(Image.open(self.w1_mask_paths[index])).astype(np.uint16)
        # check cell-count
        N = len(np.unique(w1_mask)) - 1
        num_cells = 0 if N < self.args.min_fov_cell_count else N

        # extract metadata
        well_id = self.w1_mask_paths[index].stem.split("_")[-2]
        fov = self.w1_mask_paths[index].stem.split("_")[-1]
        if self.containsLetterAndNumber(fov):
            fov = int(re.findall(r'\d+', fov)[0])
        elif fov.isdigit:
            fov = int(fov)
        else:
            raise ValueError(f"FOV value {fov} is unacceptable!")

        dosage = self.args.wellid2dosage[well_id]
        treatment = self.args.wellid2treatment[well_id]
        cell_line = self.args.wellid2cellline[well_id]
        density = self.args.wellid2density[well_id]
        other = self.args.wellid2other[well_id]

        return num_cells, (self.args.experiment, well_id, fov, treatment, cell_line, density, dosage, other)

    def get_metadata_loop(self):
        # print(self.args.metadata_cols, self.args.num_metadata_cols)
        arr_metadata = np.zeros(
            (self.N*self.cell_count_per_fov_ub, self.args.num_metadata_cols-1),
            dtype=object)
        arr_cell_count = np.zeros((self.N, self.args.num_metadata_cols), dtype=object)
        arr_bad_img_idxs = -1*np.ones((self.N, ), dtype=int)
        total_cell_count = 0
        # total_cell_count = mp.Value(c_int, 0, lock=True)

        with mp.Pool(processes=self.num_workers) as pool:
            for ii, (num_cells, meta) in tqdm(enumerate(pool.imap(self.get_metadata, range(self.N))), total=self.N):
                arr_cell_count[ii] = (num_cells,)+meta
                if num_cells == 0:
                    arr_bad_img_idxs[ii] = ii
                # only extract and store the meta data for images with enough # of cells
                else:
                    arr_metadata[total_cell_count:total_cell_count+num_cells, :] = meta
                    total_cell_count += num_cells
        arr_metadata = arr_metadata[0:total_cell_count]

        pd.DataFrame(arr_cell_count, columns=("cell-count", )+tuple(self.args.metadata_cols[:-1])). \
            to_csv(self.args.step3_save_path / "cell_count.csv",
                   index=False,
                   float_format="%.2f")

        arr_bad_img_idxs = arr_bad_img_idxs[arr_bad_img_idxs != -1]
        arr_good_img_idxs = np.setdiff1d(np.arange(self.N), arr_bad_img_idxs)
        np.save(self.args.step3_save_path / "good_img_idxs.npy", arr_good_img_idxs)

        return total_cell_count, arr_good_img_idxs, arr_metadata

    @lru_cache(maxsize=cache_max_size)
    def step0_preprocessing(self, img_paths, mask_paths):
        """
            w0_mask_path = .../w0_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            w1_mask_path = .../w1_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            w2_mask_path = .../w2_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            w5_mask_path = .../w4_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            img_channels_group:
            [
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w1DCEB3369-8F24-4915-B0F6-B543ADD85297.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w2C3AF00C2-E9F2-406A-953F-2ACCF649F58B.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w3524F4D75-8D83-4DDC-828F-136E6A520E5D.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w4568AFB8E-781D-4841-8BC8-8FD870A3147F.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w5D9A405BD-1C0C-45E4-A335-CEE88A9AD244.tif,
            ]

            index is an int that refers to the index of the img_path_group in
            self.img_path_groups
            """

        # loading the image files for the 5 channels
        nucleus_img = tifffile.imread(img_paths[0])
        cyto_img = tifffile.imread(img_paths[1])
        nucleoli_img = tifffile.imread(img_paths[2])
        actin_img = tifffile.imread(img_paths[3])
        mito_img = tifffile.imread(img_paths[4])

        # loading the mask files for the 4 channels that have their own mask
        nucleus_mask = sio.imread(mask_paths[0])
        cell_mask = sio.imread(mask_paths[1])
        nucleoli_mask = sio.imread(mask_paths[2])
        mito_mask = sio.imread(mask_paths[3])

        cyto_mask = cell_mask.copy()
        cyto_mask[nucleus_mask > 0] = 0
        # nucleoli_mask[]
        # fig, axes = plt.subplots(1, 3, sharex=True, sharey=True)
        # axes[0].imshow(nucleus_mask, cmap="gray")
        # axes[1].imshow(cyto_mask, cmap="gray")
        # axes[2].imshow(cell_mask, cmap="gray")
        # plt.show()
        # print(len(np.unique(cell_mask)))
        # print(len(np.unique(cyto_mask)))
        # print(len(np.unique(nucleus_mask)))

        assert np.array_equal(np.unique(cell_mask), np.unique(cyto_mask))

        img = np.zeros((5, self.args.height, self.args.width), dtype=np.uint16)
        mask = np.zeros((6, self.args.height, self.args.width), dtype=np.uint16)

        ##############################################################
        # TODO: Need to add the illumination correction step right here!!!
        ###########################################################
        img[0], mask[0] = nucleus_img, nucleus_mask
        img[1], mask[1] = cyto_img, cyto_mask
        img[2], mask[2] = nucleoli_img, nucleoli_mask
        img[3], mask[3] = actin_img, cyto_mask
        img[4], mask[4] = mito_img, mito_mask
        mask[5] = cell_mask
        # img[5], mask[5] = nucleus_img, cell_mask
        # img[6], mask[6] = cyto_img, cell_mask
        # img[7], mask[7] = nucleoli_img, cell_mask
        # img[8], mask[8] = actin_img, cell_mask
        # img[9], mask[9] = mito_img, cell_mask
        return img, mask

    def step1_get_features(self, img, mask):
        max_ = np.amax(mask[0])
        # N = len(np.unique(mask[0])) - 1
        N = 1000
        nucleus_objects = find_objects(mask[0], max_label=max_)
        cyto_objects = find_objects(mask[1], max_label=max_)
        nucleoli_objects = find_objects(mask[2], max_label=max_)
        mito_objects = find_objects(mask[4], max_label=max_)
        cell_objects = find_objects(mask[5], max_label=max_)
        #################################################################
        cnt = 0
        # has_nucleoli = np.zeros(shape=(N, 1), dtype=bool)
        # misc_features = np.zeros((N, self.args.num_misc_cols), dtype=np.float32)
        # features = np.zeros(shape=(self.args.num_organelles, N, self.args.num_feat_cols), dtype=np.float32)
        range_ = tqdm(range(max_), total=max_) if self.testing else range(max_)
        # range_ = range(max_)
        bbox_features = np.zeros((N, 8), dtype=np.float32)
        shape_features = np.zeros((N, 25), dtype=np.float32)
        intensity_features = np.zeros((N, 10*10), dtype=np.float32)
        texture_features = np.zeros((N, 400*10), dtype=np.float32)
        misc_features = np.zeros((N, 9), dtype=np.float32)

        # Here we are assuming each object have the exact same label across all masks.
        # Also since cell_object is the biggest mask, we also assume that no other labelled object
        # can be found inside a single slice/labelled_object from cell_object!
        for ii in range_:  # loops over each cell/roi/bbox
            cell_obj = cell_objects[ii]
            nucleus_obj = nucleus_objects[ii]
            cyto_obj = cyto_objects[ii]
            nucleoli_obj = nucleoli_objects[ii]
            mito_obj = mito_objects[ii]
            obj_label = ii + 1

            # if there is no cell or no nucleoli skip it the cell.
            if (nucleus_obj is None) or (nucleoli_obj is None):
                # if nucleus_obj is None or np.sum(nucleoli_props.image) == 0:
                continue
            # print(ii, nucleus_obj, nucleoli_obj)

            # TODO: Figure out the correct index of all masks
            # get shape features AND bounding boxes for nucleus mask and cyto mask
            nucleus_props = RegionPropertiesExtension(cell_obj, obj_label, mask[0], img[0])
            cyto_props = RegionPropertiesExtension(cyto_obj, obj_label, mask[1], img[1])
            nucleoli_props = RegionPropertiesExtension(nucleoli_obj, obj_label, mask[2], img[2])
            actin_props = RegionPropertiesExtension(cyto_obj, obj_label, mask[3], img[3])
            mito_props = RegionPropertiesExtension(mito_obj, obj_label, mask[4], img[4])

            cell_w1_props = RegionPropertiesExtension(cell_obj, obj_label, mask[5], img[0])
            cell_w2_props = RegionPropertiesExtension(cell_obj, obj_label, mask[5], img[1])
            cell_w3_props = RegionPropertiesExtension(cell_obj, obj_label, mask[5], img[2])
            cell_w4_props = RegionPropertiesExtension(cell_obj, obj_label, mask[5], img[3])
            cell_w5_props = RegionPropertiesExtension(cell_obj, obj_label, mask[5], img[4])

            bbox_features[cnt, :] = nucleus_props.bbox+cyto_props.bbox
            shape_features[cnt, :] = \
                (cell_w1_props.area, nucleus_props.area, cyto_props.area, nucleoli_props.area, mito_props.area,

                 nucleus_props.area_convex, nucleus_props.perimeter, nucleus_props.perimeter_crofton,
                 nucleus_props.circularity, nucleus_props.efc_ratio,
                 nucleus_props.eccentricity, nucleus_props.equivalent_diameter_area,
                 nucleus_props.feret_diameter_max, nucleus_props.solidity, nucleus_props.extent,

                 cell_w1_props.area_convex, cell_w1_props.perimeter, cell_w1_props.perimeter_crofton,
                 cell_w1_props.circularity, cell_w1_props.efc_ratio,
                 cell_w1_props.eccentricity, cell_w1_props.equivalent_diameter_area,
                 cell_w1_props.feret_diameter_max, cell_w1_props.solidity, cell_w1_props.extent)

            # intensity and texture feature profile using each prop!
            intensity_mt1_w1 = nucleus_props.intensity_statistics
            intensity_mt1_w2 = cyto_props.intensity_statistics
            intensity_mt1_w3 = nucleoli_props.intensity_statistics
            intensity_mt1_w4 = actin_props.intensity_statistics
            intensity_mt1_w5 = mito_props.intensity_statistics

            intensity_mt2_w1 = cell_w1_props.intensity_statistics
            intensity_mt2_w2 = cell_w2_props.intensity_statistics
            intensity_mt2_w3 = cell_w3_props.intensity_statistics
            intensity_mt2_w4 = cell_w4_props.intensity_statistics
            intensity_mt2_w5 = cell_w5_props.intensity_statistics

            intensity_features[cnt, :] = \
                intensity_mt1_w1 + intensity_mt1_w2 + intensity_mt1_w3 + intensity_mt1_w4 + intensity_mt1_w5 + \
                intensity_mt2_w1 + intensity_mt2_w2 + intensity_mt2_w3 + intensity_mt2_w4 + intensity_mt2_w5

            glcm_mt1_w1 = nucleus_props.glcm_features
            glcm_mt1_w2 = cyto_props.glcm_features
            glcm_mt1_w3 = nucleoli_props.glcm_features
            glcm_mt1_w4 = actin_props.glcm_features
            glcm_mt1_w5 = mito_props.glcm_features

            glcm_mt2_w1 = cell_w1_props.glcm_features
            glcm_mt2_w2 = cell_w2_props.glcm_features
            glcm_mt2_w3 = cell_w3_props.glcm_features
            glcm_mt2_w4 = cell_w4_props.glcm_features
            glcm_mt2_w5 = cell_w5_props.glcm_features

            # glszm_mt2_w1 = nucleus_props.glszm_features
            a = nucleus_props.glszm

            texture_features[cnt, :] = \
                glcm_mt1_w1 + glcm_mt1_w2 + glcm_mt1_w3 + glcm_mt1_w4 + glcm_mt1_w5 + \
                glcm_mt2_w1 + glcm_mt2_w2 + glcm_mt2_w3 + glcm_mt2_w4 + glcm_mt2_w5

            misc_features[cnt, 0] = np.amax(label(nucleoli_props.image, connectivity=2, background=0))
            # Now we need to extract the bounding box of the cell_object from each image channel
            cnt += 1
        shape_features = shape_features[0:cnt]
        intensity_features = intensity_features[0:cnt]
        texture_features = texture_features[0:cnt]
        misc_features = misc_features[0:cnt]

        misc_features[:, 1] = shape_features[:, 1] / shape_features[:, 0]  # nucleus area to cell area
        misc_features[:, 2] = shape_features[:, 2] / shape_features[:, 0]  # cyto area to cell area
        misc_features[:, 3] = shape_features[:, 3] / shape_features[:, 0]  # nucleoli area to cell area
        misc_features[:, 4] = shape_features[:, 4] / shape_features[:, 0]  # mito area to cell area

        misc_features[:, 5] = shape_features[:, 1] / shape_features[:, 2]  # nucleus area to cyto area
        misc_features[:, 6] = shape_features[:, 4] / shape_features[:, 2]  # mito area to cyto area
        misc_features[:, 7] = shape_features[:, 3] / shape_features[:, 2]  # nucleoli area to cyto area
        misc_features[:, 8] = shape_features[:, 3] / shape_features[:, 1]  # nucleoli area to nucleus area
        return shape_features, intensity_features, texture_features, misc_features

    def load_mask(self, index):
        # read the masks and image from hard drive
        w1_mask = np.array(Image.open(self.w1_mask_paths[index])).astype(np.uint16)  # nuclei mask
        # check cell-count
        N = len(np.unique(w1_mask)) - 1
        num_cells = 0 if N < self.args.min_fov_cell_count else N
        max_ = np.amax(w1_mask)

        w2_mask = np.array(Image.open(self.w2_mask_paths[index])).astype(np.uint16)  # w1 mask
        w3_mask = np.array(Image.open(self.w3_mask_paths[index])).astype(np.uint16)  # w2 mask
        w5_mask = np.array(Image.open(self.w5_mask_paths[index])).astype(np.uint16)  # w4 mask
        # already taken care of in step2_segmentation_p2.py
        ###########################################################################
        # # remove the nucleus from the cytoplasm mask
        # w1_mask[w0_mask > 0] = 0
        #############################################################################
        # relabel w2_mask with the nuclei/w1plasm masks (already matching) labels
        # w2_mask[w2_mask > 0] = w0_mask[w2_mask > 0]
        # w2_mask = w0_mask * (w2_mask > 0).astype(np.uint8)
        # cell_mask = w0_mask + w1_mask  # actin mask
        # assert np.array_equal(cell_mask * (w0_mask > 0), w0_mask)
        masks = np.concatenate([
            w1_mask[np.newaxis],
            w2_mask[np.newaxis],
            w3_mask[np.newaxis],
            w2_mask[np.newaxis],
            w5_mask[np.newaxis],

        ], axis=0)
        #################################################################################################
        w1_objects = find_objects(w1_mask, max_label=max_)
        w2_objects = find_objects(w2_mask, max_label=max_)
        w3_objects = find_objects(w3_mask, max_label=max_)
        w5_objects = find_objects(w5_mask, max_label=max_)
        ##########################################################
        objects = [w1_objects, w2_objects, w3_objects, w2_objects, w5_objects]

        return num_cells, max_, masks, objects

    def get_features(self, index):
        """
            w0_mask_path = .../w0_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            w1_mask_path = .../w1_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            w2_mask_path = .../w2_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            w5_mask_path = .../w4_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
            img_channels_group:
            [
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w1DCEB3369-8F24-4915-B0F6-B543ADD85297.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w2C3AF00C2-E9F2-406A-953F-2ACCF649F58B.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w3524F4D75-8D83-4DDC-828F-136E6A520E5D.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w4568AFB8E-781D-4841-8BC8-8FD870A3147F.tif,
            .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w5D9A405BD-1C0C-45E4-A335-CEE88A9AD244.tif,
            ]

            index is an int that refers to the index of the img_path_group in
            self.img_path_groups
            """
        ###############################################################
        # 1) load the image
        # img of the fov with 5 channels: (DAPI, CYTO, Nucleoli, Actin, MITO)
        img = load_img(self.img_path_groups[index], self.args.num_channels, self.args.height, self.args.width)
        # TODO: this might need to be added to load_img, for other labs doing cellpaint may not use the same
        #  ordering of the channels
        #     img = img[[self.args.nucleus_idx, self.args.cyto_idx,
        #                self.args.nucleoli_idx, self.args.actin_idx, self.args.mito_idx]]
        #################################################################
        # 2) load the mask
        out = self.load_mask(index)
        N, max_, masks, objects = out
        #################################################################
        cnt = 0
        has_nucleoli = np.zeros(shape=(N, 1), dtype=bool)
        misc_features = np.zeros((N, self.args.num_misc_cols), dtype=np.float32)
        features = np.zeros(shape=(self.args.num_organelles, N, self.args.num_feat_cols), dtype=np.float32)
        # range_ = tqdm(range(max_), total=max_) if self.args.mode=="debug" else range(max_)
        for ii in range(max_):  # loops over each cell/roi/bbox
            if objects[0][ii] is None:  # if there is no cell skip it (this cell was removed in preprocessing).
                continue
            obj_label = ii + 1

            for jj in range(0, 5):  # loops over the 5 channels
                if jj == 2 and objects[2][ii] is None:  # if there is no nucleoli skip channel 2.
                    has_nucleoli[cnt] = 0
                    continue
                has_nucleoli[cnt] = 1

                props = RegionPropertiesExtension(objects[jj][ii], obj_label, masks[jj], img[jj])
                if jj == 2:  # add nucleoli count
                    misc_features[cnt, 0] = np.amax(label(props.image, connectivity=2, background=0))
                #####################
                # bounding box
                features[jj, cnt, 0:self.args.n1] = props.bbox
                ###############################
                # shape features
                features[jj, cnt, self.args.n1:self.args.n2] = \
                    (props.area, props.area_convex, props.perimeter, props.perimeter_crofton,
                     props.circularity, props.efc_ratio, props.eccentricity, props.equivalent_diameter_area,
                     props.feret_diameter_max, props.solidity, props.extent)
                ##################
                # intensity features
                features[jj, cnt, self.args.n2:self.args.n3] = props.intensity_statistics
                #########################################################
                # haralick features: from locally discretized image (each bounding box is discretized separately)
                features[jj, cnt, self.args.n3:self.args.n4] = props.glcm_features
                # features[jj, cnt, self.args.n4:self.args.n5] = # scattering
                # ##################
                # # moments features
                # mn = props.moments_normalized.reshape(-1, order='C')[self.args.mn_ids]
                # mwn = props.moments_weighted_normalized.reshape(-1, order='C')[self.args.mn_ids]
                # mh = props.moments_hu.reshape(-1, order='C')
                # mwh = props.moments_weighted_hu.reshape(-1, order='C')
                # features[jj, cnt, self.args.n5:self.args.n6] = \
                #     tuple(props.centroid_local) + tuple(props.centroid_weighted_local) + (
                #         np.median(mn), median_abs_deviation(mn, axis=None),
                #         np.median(mwn), median_abs_deviation(mwn, axis=None),
                #         np.median(mh), median_abs_deviation(mh, axis=None),
                #         np.median(mwh), median_abs_deviation(mwh, axis=None))
            cnt += 1
        misc_features[:, 1] = features[0, :, 4] / features[1, :, 4]  # nucleus area to cyto area
        misc_features[:, 2] = features[4, :, 4] / features[1, :, 4]  # mito area to cyto area
        misc_features[:, 3] = features[2, :, 4] / features[0, :, 4]  # nucleoli area to nucleus area
        return has_nucleoli, misc_features, features

    # def write_text_over_img(self, ):
    #     import tifffile
    #     import matplotlib.pyplot as plt
    #
    #     img_path = self.img_path_groups[0][0]
    #     img = tifffile.imread((img_path))
    #     fig, axes = plt.subplots(1, 2)
    #     axes[0].imshow(img, origin="upper", cmap="gray")
    #     axes[1].imshow(img, origin="upper", cmap="gray")
    #     axes[0].text(500, 500, 'KP', bbox=dict(fill=False, edgecolor='red', linewidth=2), fontsize=30, color='blue')
    #     axes[1].text(500, 500, 'KP', bbox=dict(fill=False, edgecolor='red', linewidth=2), fontsize=30, color='blue')
    #     plt.show()


def step3_run_single_process_for_loop(args):
    assert args.mode == "debug"
    inst = FeatureExtractor(args)
    # extract metadata separately because they are string/non-numeric objects.
    # This separation significantly speeds up the program.
    inst.total_cell_count, inst.arr_good_img_idxs, inst.arr_metadata = inst.get_metadata_loop()
    # initialize feature accumulators and starting row position
    srow = 0
    arr_features = np.zeros(
        (inst.args.num_organelles, inst.total_cell_count, inst.args.num_feat_cols),
        dtype=np.float32)
    arr_has_nucleoli = np.zeros((inst.total_cell_count, 1), dtype=bool)
    arr_misc_features = np.zeros((inst.total_cell_count, len(inst.args.misc_cols)), dtype=np.float32)

    for iiii in tqdm(inst.arr_good_img_idxs, total=len(inst.arr_good_img_idxs)):
        out = inst.get_features(iiii)
        ncells = out[0].shape[0]
        arr_has_nucleoli[srow:srow + ncells] = out[0]
        arr_misc_features[srow:srow + ncells, :] = out[1]
        arr_features[:, srow:srow + ncells, :] = out[2]
        srow += ncells

    inst.arr_metadata = np.concatenate((inst.arr_metadata, arr_has_nucleoli), axis=1)

    print("converting features to a dataframe and saving to csv")
    pd.DataFrame(inst.arr_metadata, columns=inst.args.metadata_cols). \
        to_csv(inst.args.step3_save_path / "metadata_of_features.csv", index=False, float_format="%.2f")

    for idx in range(inst.args.num_organelles):
        pd.DataFrame(arr_features[idx], columns=inst.args.organelle_cols[idx]). \
            to_csv(inst.args.step3_save_path / f"w{idx}_features.csv", index=False, float_format="%.2f")

    pd.DataFrame(arr_misc_features, columns=inst.args.misc_cols). \
        to_csv(inst.args.step3_save_path / "misc_features.csv", index=False, float_format="%.2f")


def step3_run_multi_process_for_loop(args, myclass):
    assert args.mode != "debug"
    """
    Main loop that calls the "get_features" function over on each single
        (image_group, w0_mask, w1_mask, w2_mask w3_mask, w5_mask) entry

    We have to Register the FeatureExtractor class object as well as its attributes as shared using:
    https://stackoverflow.com/questions/26499548/accessing-an-attribute-of-a-multiprocessing-proxy-of-a-class
    """
    MyManager = MyBaseManager()
    # register the custom class on the custom manager
    MyManager.register(myclass.__name__, myclass, TestProxy)
    # create a new manager instance
    with MyManager as manager:
        inst = getattr(manager, myclass.__name__)(args)

        # get features and metadata
        # extract metadata separately because they are string/non-numeric objects.
        # This separation significantly speeds up the program.
        inst.total_cell_count, inst.arr_good_img_idxs, inst.arr_metadata = inst.get_metadata_loop()
        T = len(inst.arr_good_img_idxs)

        srow = 0
        # srow = mp.Value(c_int, 0, lock=True)
        arr_features = create_shared_np_num_arr(
            (inst.args.num_organelles, inst.total_cell_count, inst.args.num_feat_cols), c_dtype="c_float")
        arr_has_nucleoli = create_shared_np_num_arr((inst.total_cell_count, 1), c_dtype="c_bool")
        arr_misc_features = create_shared_np_num_arr(
            (inst.total_cell_count, len(inst.args.misc_cols)), c_dtype="c_float")

        with mp.Pool(processes=inst.num_workers) as pool:
            """Using pool.imap whichs preserve order, so that no two processes write to the same row!!!"""
            for out in tqdm(pool.imap(inst.get_features, inst.arr_good_img_idxs), total=T):
                ncells = out[0].shape[0]
                arr_has_nucleoli[srow:srow + ncells] = out[0]
                arr_misc_features[srow:srow + ncells, :] = out[1]
                arr_features[:, srow:srow + ncells, :] = out[2]
                srow += ncells

        inst.arr_metadata = np.concatenate((inst.arr_metadata, arr_has_nucleoli), axis=1)

        # save features and metadata
        print("converting features to a dataframe and saving to csv")
        pd.DataFrame(inst.arr_metadata, columns=inst.args.metadata_cols). \
            to_csv(inst.args.step3_save_path / "metadata_of_features.csv", index=False, float_format="%.2f")

        for idx in range(inst.args.num_organelles):
            pd.DataFrame(arr_features[idx], columns=inst.args.organelle_cols[idx]). \
                to_csv(inst.args.step3_save_path / f"w{idx}_features.csv", index=False, float_format="%.2f")

        pd.DataFrame(arr_misc_features, columns=inst.args.misc_cols). \
            to_csv(inst.args.step3_save_path / "misc_features.csv", index=False, float_format="%.2f")


def step3_main_run_loop(args, myclass=FeatureExtractor):
    """
    Main function for cellpaint step III:
        It Extract features from all the 5 channels using:
            w0_mask for channel 0 / nucleus channel.
            w1_mask for channel 1 / cytoplasm channel.
            w2_mask for channel 2 / nucleoli channel.
            w1_mask for channel 3 / actin channel.
            w5_mask for channel 4 / mito channel.
        It all extracts misc/other features using a combination of different masks.
        It saves all those features as separate csv files into:
            save_path / "w0_features.csv"
            save_path / "w1_features.csv"
            save_path / "w2_features.csv"
            save_path / "w3_features.csv"
            save_path / "w4_features.csv"
            save_path / "misc_features.csv"
            save_path / "meta_of_features.csv"

        It saves feature csv files into:

        if args.mode.lower() == "debug":
            self.args.step3_save_path = args.main_path / args.experiment / "Debug" / "Features"
        elif args.mode.lower() == "test":
            self.args.step3_save_path = args.main_path / args.experiment / "Test" / "Features"
        elif args.mode.lower() == "full":
            self.args.step3_save_path = args.main_path / args.experiment / "Features"
    """

    print("Cellpaint Step 3: \n"
          "feature extraction from all 5 channels using the masks from Cellpaint Step II:\n"
          "w0_mask= Nucleus Mask    "
          "w1_mask= Cytoplasm Mask  "
          "w2_mask= Nucleoli Mask   "
          "w1_mask= Action Mask     "
          "w5_mask= Mitocondira Mask ......")
    s_time = time.time()
    # stepIII_run_single_process_for_loop(args)
    if args.mode == "debug":
        step3_run_single_process_for_loop(args)
    else:
        step3_run_multi_process_for_loop(args, myclass)
    print(f"Finished Cellpaint step 3 in: {(time.time()-s_time)/3600} hours\n")


well_id, fov = "C10", "F005"
main_path = WindowsPath(r"P:\tmp\MBolt\Cellpainting\Cellpainting-Flavonoid")
exp_fold = "20230413-CP-MBolt-FlavScreen-RT4-1-3_20230415_005621"

args = Args(experiment=exp_fold, main_path=main_path, mode="full").args
myclass = FeatureExtractor(args)

img_paths = (
    main_path/exp_fold/args.img_folder/f"AssayPlate_PerkinElmer_CellCarrier-384_{well_id}_T0001{fov}L01A01Z01C01.tif",
    main_path/exp_fold/args.img_folder/f"AssayPlate_PerkinElmer_CellCarrier-384_{well_id}_T0001{fov}L01A02Z01C02.tif",
    main_path/exp_fold/args.img_folder/f"AssayPlate_PerkinElmer_CellCarrier-384_{well_id}_T0001{fov}L01A04Z01C03.tif",
    main_path/exp_fold/args.img_folder/f"AssayPlate_PerkinElmer_CellCarrier-384_{well_id}_T0001{fov}L01A03Z01C04.tif",
    main_path/exp_fold/args.img_folder/f"AssayPlate_PerkinElmer_CellCarrier-384_{well_id}_T0001{fov}L01A05Z01C05.tif",
)

mask_paths = (
    main_path/exp_fold/args.step2_save_path/f"w0_{well_id}_{fov}.png",
    main_path/exp_fold/args.step2_save_path/f"w1_{well_id}_{fov}.png",
    main_path/exp_fold/args.step2_save_path/f"w2_{well_id}_{fov}.png",
    main_path/exp_fold/args.step2_save_path/f"w4_{well_id}_{fov}.png",
)
img, mask = myclass.step0_preprocessing(img_paths, mask_paths)
myclass.step1_get_features(img, mask)
##############################################
# info = torch.iinfo(torch.int8)
# print(info)