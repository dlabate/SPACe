import time
from tqdm import tqdm

import numpy as np
import pandas as pd

import seaborn as sns
import matplotlib.pyplot as plt

import multiprocessing as mp
from functools import partial

from cellpaint.utils.helpers import MyBaseManager, TestProxy
pd.options.mode.chained_assignment = None


def find_first_occurance(string_list, substring):
    N = len(string_list)
    for ii in range(N):
        if substring in string_list[ii]:
            return ii


def unique_with_preservered_order(mylist):
    a = np.array(mylist)
    _, idx = np.unique(a, return_index=True)
    return a[np.sort(idx)]


class FoundItem(Exception):
    pass


class HeatMap:
    # sns.set_context(font_scale=0.7)  # scale factor for all fonts
    # def __init__(self, csv_file_paths, args):
    #     self.args = args
    #     self.csv_file_paths = csv_file_paths
    #
    # def loop(self):
    #     """https://stackoverflow.com/questions/45311398/python-multiprocessing-class-methods"""
    #     print(self, 'loop')
    #     for ii in range(len(self.csv_file_paths)):
    #          self.get_heatmap(self.csv_file_paths[ii])
    num_meta = 8

    def __init__(self, args, heatmap_threshold=.1):
        self.args = args
        self.heatmap_threshold = heatmap_threshold
        self.csv_paths = list(args.distancemaps_path.glob("*.csv"))
        self.N = len(self.csv_paths)

    def get_heatmap(self, ii):
        """Main function """
        self.load_heatmap_csv_file(ii)
        self.handle_columns()
        self.apply_threshold()
        self.create_heatmap_figure_object()
        self.create_xlabels_below_figure()
        self.create_ylabels_left_of_figure()
        self.create_ylabels_right_of_figure()
        self.create_xlabels_above_figure()
        self.rotate_tick_labels()
        self.adjust_colorbar_location()
        self.save_heatmap_figure(ii)

    def load_heatmap_csv_file(self, ii):
        # load distance map
        # print(self.csv_paths[ii].stem)
        self.df_distance = pd.read_csv(self.csv_paths[ii], index_col=0).reset_index()
        # self.prefix, self.dist_type, self.channel = csv_file_path.stem.split('_')
        split = self.csv_paths[ii].stem.split('_')
        self.prefix, self.dist_type = '_'.join(split[0:-1]), split[-1]

    def handle_columns(self):
        """get column names which is divided into to sets:
        meta data columns, self.df_meta, and feature distance columns, self.fd_cols"""
        # get columns data
        # "cell-count", "exp-id", "well-id", "cell-line", "density", "treatment", "other", "dosage"
        self.meta_cols = list(self.df_distance.columns)[0:self.num_meta]
        # print(self.meta_cols)
        self.df_meta = self.df_distance[self.meta_cols]
        # shorten treatment names to maximum of 10 characters
        self.df_meta["treatment"] = self.df_meta["treatment"].apply(lambda x: x[:np.min([len(x) - 2, 10])] + x[-2:])
        # get none-meta/feature-distance columns
        self.fd_cols = list(self.df_distance.columns)[self.num_meta:]

        # get cell count for unique treatment, density, dosage triplets
        # exclude the exp-id and well-id columns
        self.cols_in_yright = list(np.setdiff1d(self.meta_cols, ["exp-id", "well-id"]))
        self.vals_in_title = []
        # removing/dropping meta columns (excluding cell-count) that have only a single unique value
        for col in np.setdiff1d(self.cols_in_yright, ["cell-count"]):
            unix = np.unique(self.df_meta[col].values)
            if len(unix) == 1:
                self.cols_in_yright.remove(col)
                if col.lower() != "other":
                    self.vals_in_title.append(f"{col}={unix[0]}")
        """The part is a MUST!!!"""
        # resorting the entire dist-map dataframe has to happen here!
        # basically each dataframe has to be sorted by the column used
        # to obtain the self.ylabel_right_w_count
        self.other_cols = list(np.setdiff1d(self.cols_in_yright, ["cell-count"]))
        if "treatment" in self.other_cols: # putting treatment first
            self.other_cols.remove("treatment")
            self.other_cols.insert(0, "treatment")
        self.df_distance.sort_values(by=self.other_cols, ascending=["True"]*len(self.other_cols), inplace=True)
        self.df_meta.sort_values(by=self.other_cols, ascending=["True"]*len(self.other_cols), inplace=True)

    def apply_threshold(self):
        """We apply the intensity based upper and lower
        thresholds for better visibility/readability/ biological interpretability"""

        # self.df_distance only contains the feature distance columns, not any of the meta data columns
        self.df_distance = self.df_distance[
            (self.df_distance[self.fd_cols] <= -self.heatmap_threshold) |
            (self.df_distance[self.fd_cols] >= self.heatmap_threshold)][self.fd_cols]

    def create_heatmap_figure_object(self):
        """
        create the matplotlib/sns figure object. We set global values vmin=-1, vmax=1.
        This gives a universal and uniform color gradient to all generated heatmaps, and
        allows for apple to apple comparison of all figure maps."""

        self.fig, (ax1, axcb) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [1, 0.08]}, )
        self.fig.set_size_inches(21.3, 13.3)
        # self.fig.set_size_inches(54.1, 33.8 )
        # TODO: Fix the title
        self.fig.suptitle(
            # f"{self.args.experiment}: {self.dist_type} + {self.channel}",
            f"{self.args.experiment}:{self.dist_type}\n{'  '.join(self.vals_in_title)}",
            # fontname='Comic Sans MS',
            fontsize=12)
        # set lower and upper thresholds for heatmap values for better display
        # ymin, ymax = np.percentile(self.df_distance.values, 5), np.percentile(self.df_distance.values, 95)
        self.heatmap = sns.heatmap(
            self.df_distance,
            # linewidths=.05,
            # linecolor='black',
            cmap="jet",
            ax=ax1,
            cbar_ax=axcb,
            vmin=-1, vmax=1,
            cbar_kws={"shrink": 0.4})

    def create_xlabels_below_figure(self):
        """
        self.xlabels are basically all feature names put in a list:
        shape feature names,
        followed by intensity feature names,
        followed by moment feature names,
        followed by haralick feature names,
        """

        # predefine/preset x-axis labels
        self.xlabels = self.df_distance.columns.tolist()
        # ["All_", "Nucleus_", "Cyto_", "Nucleoli_", "Actin_", "Mito_"]
        self.xtitles = unique_with_preservered_order([it.split('_')[0] for it in self.xlabels])
        self.xsubtitles = unique_with_preservered_order([
            '_'.join(it.split('_')[0:2])
            for it in self.xlabels
            if it.split('_')[0] in self.xtitles[1:]])  # in ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]

        # remove channel name and feature category from the feature-distance column names
        self.xlabels_below = []
        for cin in ["All_", "Nucleus_", "Cyto_", "Nucleoli_", "Actin_", "Mito_"]:
            self.xlabels_below += ["".join(it.split('_')[2:]) for it in self.xlabels if cin in it]
        # print(self.xlabels_below)
        # print(self.xsubtitles)
        # print('\n')
        # set x ticks positions and values
        self.heatmap.set_xticks(np.arange(.5, len(self.xlabels_below) + .5, 1))
        self.heatmap.set_xticklabels([it for ii, it in enumerate(self.xlabels_below) if ii % 1 == 0])
        self.heatmap.set_xticklabels(self.heatmap.get_xmajorticklabels(), fontsize=3)

    def create_ylabels_left_of_figure(self):
        # predefine/preset y-axis labels
        self.ylabels_left = list(self.df_meta['well-id'] + "_#" + self.df_meta['cell-count'].astype(str))
        # set y ticks positions and values
        self.heatmap.set_yticks(np.arange(.5, len(self.ylabels_left) + .5, 1))
        self.heatmap.set_yticklabels([it.lower() for ii, it in enumerate(self.ylabels_left) if ii % 1 == 0])
        self.heatmap.set_yticklabels(self.heatmap.get_ymajorticklabels(), fontsize=3)

    def create_ylabels_right_of_figure(self):
        """
        Set treatment/cell-line labels on right side of the plot for better readability.

        Group over all metacols with more than 1 unique value,
        except the "cell-count" column itself.
        """
        #
        assert "cell-count" in self.cols_in_yright

        df_groups = self.df_meta[self.cols_in_yright].groupby(self.other_cols).agg(['sum']).reset_index()
        # print(df_groups)
        # including the "cell-count" column
        self.ylabel_right_w_count = df_groups.apply(lambda x: '_'.join(x.astype(str)), axis=1).to_list()
        # excluding the "cell-count" column, because it got aggregated and can't be used as reference
        ylabel_right_wo_count = df_groups[self.other_cols].apply(
            lambda x: '_'.join(x.astype(str)), axis=1).to_list()
        ylabel_right_all_rows = self.df_meta[self.other_cols].apply(
            lambda x: '_'.join(x.astype(str)), axis=1).to_list()
        # horizontal lines/stops locations
        self.hstops = [ylabel_right_all_rows.index(it) for it in ylabel_right_wo_count] + \
                      [len(ylabel_right_all_rows)]
        # for it in ylabel_right_wo_count:
        #     print(f"{it}      {ylabel_right_all_rows.index(it)}")
        #     print('\n')
        ##########################################################################

        # # labels for the bands, list of places where the bands start and stop
        # create a loop using the begin and end of each band, the colors and the labels
        for beg, end, label in zip(self.hstops[:-1], self.hstops[1:], self.ylabel_right_w_count):
            # add some text to the center right of this band
            self.heatmap.text(
                1.01, (beg + end) / 2,
                # '\n'.join(label.split())
                label,
                ha='left', va='center',
                transform=self.heatmap.get_yaxis_transform(), size=10)
        # add_horizontal_gridlines
        for stop in self.hstops[1:-1]:
            # y specifies where the line's starting point on the y-axis
            # xmin and xmax specify how long the line is (from where to where)
            self.heatmap.hlines(y=stop, xmin=0, xmax=len(self.xlabels),
                                linestyle='dashed', linewidth=.4, color="black")

    def create_xlabels_above_figure(self):
        self.xtitle_locs = [find_first_occurance(self.fd_cols, cin) for cin in self.xtitles]
        self.xsubtitle_locs = [find_first_occurance(self.fd_cols, cin) for cin in self.xsubtitles]
        ############################################################################################
        # add vertical lines
        hh = list(np.arange(0, len(self.ylabels_left), 1))
        for x_ in self.xsubtitle_locs:
            # x specifies where the line's starting point on the y-axis
            # xmin and xmax specify how long the line is (from where to where)
            self.heatmap.vlines(x=x_, ymin=0, ymax=len(hh), linestyle='dashed', linewidth=.4, color="gray")
        for x_ in self.xtitle_locs:
            # x specifies where the line's starting point on the y-axis
            # xmin and xmax specify how long the line is (from where to where)
            self.heatmap.vlines(x=x_, ymin=0, ymax=len(hh), linestyle='solid', linewidth=.6, color="black")
        ###############################################################################################
        self.xtitle_locs.append(len(self.fd_cols))
        # add text for sub-categories of features above the figure object
        for beg, end, label in zip(self.xtitle_locs[:-1], self.xtitle_locs[1:], self.xtitles):
            # add some text to the center right of this band
            self.heatmap.text((beg + end) / 2, 1.08,
                              # '\n'.join(label.split())
                              label,
                              va='top', ha='center',
                              transform=self.heatmap.get_xaxis_transform(), size=8, )
        ###################################################################################################
        self.xsubtitle_locs.append(len(self.fd_cols))
        # add text for sub-categories of features above the figure object
        for beg, end, label in zip(self.xsubtitle_locs[:-1], self.xsubtitle_locs[1:], self.xsubtitles):
            # add some text to the center right of this band
            self.heatmap.text((beg + end) / 2, 1.05,
                              # '\n'.join(label.split())
                              label.split('_')[1],
                              va='top', ha='center',
                              transform=self.heatmap.get_xaxis_transform(), size=5, )

    def rotate_tick_labels(self, ):
        """rotate the tick labels 90 degrees (correctly)"""
        self.heatmap.set_xticklabels(self.heatmap.get_xticklabels(), rotation=90)
        self.heatmap.set_yticklabels(self.heatmap.get_yticklabels(), rotation=0)

    def adjust_colorbar_location(self, ):
        """move the colorbar to the right to allow more space for ylabels_right"""
        plt.subplots_adjust(wspace=.32)

    def save_heatmap_figure(self, ii):
        """save the matplotlib.pyplot figure object to disk"""
        plt.savefig(self.args.heatmaps_path / f"{self.csv_paths[ii].stem}_{self.heatmap_threshold}.png",
                    bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close(self.fig)

    def remove_bad_wells_dep(self, filter_index):
        """Deprecated!!!"""
        valids = filter_index(list(self.df_distance.index))
        self.df_distance = self.df_distance[self.df_distance.index.isin(valids)]


def stepV_run_single_process_for_loop(args):
    """heatmap generation loop:
    Using a single process when there are less than 6 heatmaps in the self.args.heatmaps_path  folder."""
    inst = HeatMap(args, heatmap_threshold=.1)
    N = len(inst.csv_paths)
    for ii in range(0, N):
        print(ii)
        inst.get_heatmap(ii)


def stepV_run_multi_process_for_loop(args):
    """heatmap generation loop:
    Using a multi-processing for loop when there are more than 6 heatmaps in the self.args.heatmaps_path  folder."""
    MyManager = MyBaseManager()
    # register the custom class on the custom manager
    MyManager.register('HeatMap', HeatMap, TestProxy)
    # create a new manager instance
    with MyManager as manager:
        inst = manager.HeatMap(args, heatmap_threshold=.1)
        num_proc = min(mp.cpu_count(), inst.N)
        with mp.Pool(processes=num_proc) as pool:
            for _ in tqdm(pool.imap(inst.get_heatmap, np.arange(inst.N)), total=inst.N):
                pass


def stepV_main_run_loop(args):
    """
    Main function for cellpaint step V (currently it is the last step).
        It generate heatmaps using a loop over an instance of the HeatMap class.
        If there are more than 6 heatmaps, it uses a multi-processing for loop.

        It saves each resulting heat-maps into separate png files as:
            self.args.heatmaps_path / f"{self.csv_paths[ii].stem}_{self.heatmap_threshold}.png"

        where

        if args.mode.lower() == "debug":
            self.args.heatmaps_path = args.main_path / args.experiment / "Debug" / "HeatMaps"
        elif args.mode.lower() == "test":
            self.args.heatmaps_path = args.main_path / args.experiment / "Test" / "HeatMaps"
        elif args.mode.lower() == "full":
            self.args.heatmaps_path = args.main_path / args.experiment / "HeatMaps"

    """
    s_time = time.time()
    print("Cellpaint Step V: \n Calculating Heat-maps")
    # stepV_run_single_process_for_loop(args)
    if args.mode == "debug":
        stepV_run_single_process_for_loop(args)
    else:
        stepV_run_multi_process_for_loop(args)
    print(f"Finished Cellpaint step V in: {(time.time() - s_time) / 3600} hours")