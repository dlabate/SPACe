import itertools

import tifffile
import numpy as np
import SimpleITK as sitk
from skimage.exposure import rescale_intensity
from skimage.segmentation import find_boundaries
from skimage.color import label2rgb
from multiprocessing.managers import BaseManager, NamespaceProxy
from multiprocessing import RawArray


class MyBaseManager(BaseManager):
    """https://stackoverflow.com/questions/3671666/sharing-a-complex-object-between-processes"""
    """https://stackoverflow.com/questions/26499548/accessing-an-attribute-of-a-multiprocessing-proxy-of-a-class"""
    pass


class TestProxy(NamespaceProxy):
    """Needed to expose attributes when using MyBaseManger to register a python simple class as shared!
     Without it the MyBaseManger can expose the methods of the class to all processes, but not the attributes."""
    _exposed_ = ('__getattribute__', '__setattr__', '__delattr__')


def shared_to_numpy(shared_arr, dtype, shape):
    """Get a NumPy array from a shared memory buffer, with a given dtype and shape.
    No copy is involved, the array reflects the underlying shared buffer."""
    return np.frombuffer(shared_arr, dtype=dtype).reshape(shape)


def create_shared_array(data, dtype, shape):
    """Create a new shared array. Return the shared array pointer, and a NumPy array view to it.
    Note that the buffer values are not initialized.
    """
    dtype = np.dtype(dtype)
    # Get a ctype type from the NumPy dtype.
    cdtype = np.ctypeslib.as_ctypes_type(dtype)
    # Create the RawArray instance.
    shared_arr = RawArray(cdtype, int(np.prod(shape)))
    # Get a NumPy array view.
    np_arr = shared_to_numpy(shared_arr, dtype, shape)
    # Copy data to our shared array.
    np.copyto(np_arr, data)
    # np_arr.flat[:] = data
    return shared_arr


def ignore_imgaeio_warning():
    import warnings
    import imageio.core.util

    def ignore_warnings(*args, **kwargs):
        pass

    warnings.filterwarnings('ignore')
    imageio.core.util._precision_warn = ignore_warnings


def create_shared_multiprocessing_name_space_object(manager, args):
    """https://github.com/prickly-pythons/prickly-pythons/issues/14
    [HowTo] Shared data in multiprocessing with Manager.Namespace()

    https://stackoverflow.com/questions/2597278/python-load-variables-in-a-dict-into-namespace
    https://www.programiz.com/python-programming/methods/built-in/setattr
    """
    # Create manager object in module-level namespace
    # # manager = mp.Manager()
    # Then create a container of things that you want to share to processes as Manager.Namespace() object.
    config = manager.Namespace()
    # fill in the config shared-namespace object with normal name space object keys and values using a for loop
    args = vars(args)
    for key, value in args.items():
        setattr(config, key, value)
    return config


def sort_key_for_imgs(file_path, plate_protocol, sort_purpose):
    """
    Get sort key from the img filename.
    The function is used to sort image filenames for a specific experiment taken with a specific plate_protocol.
    """
    # plate_protocol = plate_protocol.lower()
    if plate_protocol == "greiner" or plate_protocol == "perkinelmer":
        """img filename example:
        .../AssayPlate_PerkinElmer_CellCarrier-384/AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif
        .../AssayPlate_Greiner_#781896/AssayPlate_Greiner_#781896_A04_T0001F001L01A01Z01C01.tif
        """

        folder = file_path.parents[1].stem  # "AssayPlate_PerkinElmer_CellCarrier-384"
        filename = file_path.stem  # AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif
        split = filename.split("_")
        well_id = split[-2]  # A02
        fkey = split[-1]  # T0001F001L01A01Z01C02
        inds = [fkey.index(ll, 0, len(fkey)) for ll in fkey if ll.isalpha()]
        inds.append(None)
        # print(inds)
        timestamp, fov, id2, x1, zslice, channel = \
            [fkey[inds[ii]:inds[ii + 1]] for ii in range(len(inds) - 1)]
        # print(well_id, parts)

    elif plate_protocol == "combchem":
        """img filename example:
        .../P000025-combchem-v3-U2OS-24h-L1-copy1/
        P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s5_w3C00578CF-AD4A-4A29-88AE-D2A2024F9A92.tif"""
        folder = file_path.parents[1].stem
        filename = file_path.stem
        split = filename.split("_")
        well_id = split[1]
        fov = split[2][1]
        channel = split[3][1]
        # print(well_id, parts)
    else:
        raise ValueError(f"{plate_protocol} is not implemented")

    if sort_purpose == "to_sort_channels":
        return folder, well_id, fov, channel
    elif sort_purpose == "to_group_channels":
        # print(folder, well_id, fov)
        return folder, well_id, fov
    elif sort_purpose == "to_group_channels_with_z":
        # print(folder, well_id, fov)
        return folder, well_id, fov, channel

    elif sort_purpose == "to_match_it_with_mask_path":
        return f"{well_id}_{fov}"
    elif sort_purpose == "to_get_well_id":
        return well_id
    else:
        raise ValueError(f"sort purpose {sort_purpose} does not exist!!!")


def sort_key_for_masks(mask_path):
    """example: .../w0_A02_F001.png"""
    split = mask_path.stem.split("_")
    well_id = split[-2]
    fov = split[-1]
    return f"{well_id}_{fov}"


def get_img_paths(main_path, experiment, plate_protocol):
    """AssayPlate_Greiner_#781896_A04_T0001F001L01A01Z01C01"""
    """AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif"""
    """P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s5_w3C00578CF-AD4A-4A29-88AE-D2A2024F9A92.tif"""

    img_paths = list((main_path / experiment).rglob("*.tif"))
    if plate_protocol.lower() in ['greiner', 'perkinelmer']:
        # sometimes there are other tif files in the experiment folder that are not an image, so we have to
        # remove them from img_paths, so that they do not mess-up the analysis.
        img_paths = [item for item in img_paths if item.stem.split("_")[-1][0:5] == "T0001"]
    img_paths = sorted(
        img_paths,
        key=lambda x: sort_key_for_imgs(x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))
    return img_paths


def remove_img_path_groups_with_no_masks(
        main_path, experiement, analysis_save_path,
        plate_protocol="PerkinElmer", mask_folder="MasksP1", nucleus_idx=0, cyto_idx=1):
    """In segmentation_step1 some of the images does to have enough cells
    ((#cells in w0_mask + #cells in w1_mask)//2 < args.min_cell_count),
    and therefore have to be remove, at the beginning of  segmentation_step2.

    Similarly, In segmentation_step2 some of the images does to have enough cells (#cells < args.min_cell_count),
    and therefore have to be remove, at the beginning of  feature extraction step.

    This function ensures a one-to-one correspondence/matching between:
     img_paths, mask0_paths, and mask1_paths at the start of segmentation_step2, and
     img_paths, mask0_paths, mask1_paths, mask2_paths, and mask4_paths at the start of feature extraction step.
    """

    img_paths = get_img_paths(main_path, experiement, plate_protocol)
    # print(nucleus_idx, cyto_idx, analysis_save_path / mask_folder)
    mask0_paths = list((analysis_save_path / mask_folder).rglob(f"w{nucleus_idx}_*.png"))  # Nucleus Masks
    mask1_paths = list((analysis_save_path / mask_folder).rglob(f"w{cyto_idx}_*.png"))  # Cytoplasm Masks
    # print(len(img_paths), len(mask0_paths), len(mask1_paths))
    mask_paths_keys = [sort_key_for_masks(it) for it in mask0_paths]
    # print(len(mask_paths_keys))
    assert len(mask_paths_keys) == len(np.unique(mask_paths_keys))
    # # through away image paths for which is no mask path file.
    img_paths = sorted(
        list(filter(
            lambda x: sort_key_for_imgs(x, plate_protocol, "to_match_it_with_mask_path") in mask_paths_keys,
            img_paths)),
        key=lambda x: sort_key_for_imgs(x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))
    mask0_paths = sorted(mask0_paths, key=sort_key_for_masks)
    mask1_paths = sorted(mask1_paths, key=sort_key_for_masks)

    #  grouping channels of each image together!
    keys, img_path_groups = [], []
    for item in itertools.groupby(
            img_paths, key=lambda x: sort_key_for_imgs(
                x, plate_protocol=plate_protocol, sort_purpose="to_group_channels")):
        keys.append(item[0])
        img_path_groups.append(list(item[1]))
    num_channels = len(img_path_groups[0])

    # making sure there is a one-to-one correspondence/matching between img_paths, mask0_paths, and mask1_paths.
    for it0, it1, it2 in zip(mask0_paths, mask1_paths, keys):
        split0, split1 = it0.stem.split("_"), it1.stem.split("_")
        assert "_".join(split0[-2:]) == "_".join(split0[-2:]) == "_".join(it2[1:])
    # img_path_groups = np.vstack(img_path_groups)
    return img_path_groups, mask0_paths, mask1_paths, num_channels


def load_img(file_path_group, num_channels, height, width):
    """load channel tiff files belonging to a single image into a single tiff file.
    file_path_group: list of channel tiff files
    example:
    [.../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C01.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C03.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C04.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C05.tiff,]
     num_channels: The number of channels contained in the image,
     height: height of each image (It is always fixed for a single experiment.),
     width: width of each image (It is always fixed for a single experiment.),
    """
    img = np.zeros((num_channels, height, width), dtype=np.float32)
    for jj in range(num_channels):
        img[jj] = tifffile.imread(file_path_group[jj])
    # for jj, fp in enumerate(file_path_group):
    #     img[jj] = tifffile.imread(fp)
    return img


def get_sitk_img_thresholding_mask(img, myfilter):
    tmp = img.copy()
    # tmp = (tmp - np.amin(tmp)) / (np.amax(tmp) - np.amin(tmp) + 1e-6)
    tmp1 = tmp[tmp > 0]
    tmp1 = tmp1.reshape((-1, 1))
    size = tmp1.shape[0]
    tmp1 = sitk.GetImageFromArray(tmp1)
    try:
        tmp1 = myfilter.Execute(tmp1)
        tmp1 = sitk.GetArrayFromImage(tmp1)
    except:
        tmp1 = np.zeros(size, dtype=np.uint16)
    tmp1 = tmp1.reshape(-1)
    tmp[tmp > 0] = tmp1
    return tmp


def get_overlay(img, labeled_mask, colors):
    mask_bd = find_boundaries(
        labeled_mask,
        connectivity=2,
        mode="inner").astype(np.uint16)
    mask_bd[mask_bd != 0] = labeled_mask[mask_bd != 0]
    mask_bd = label2rgb(mask_bd, colors=colors, bg_label=0)

    img = img.copy()
    img = (img - np.amin(img)) / (np.amax(img) - np.amin(img) + 1e-6)
    img = np.repeat(img[:, :, np.newaxis], 3, axis=2)
    # print(mask_bd.shape, img.shape)
    img[mask_bd != 0] = mask_bd[mask_bd != 0]
    return img


def move_figure(f, x, y):
    import matplotlib
    # Bottom vertical alignment for more space, size=14)
    """Move figure's upper left corner to pixel (x, y)"""
    backend = matplotlib.get_backend()
    if backend == 'TkAgg':
        f.canvas.manager.window.wm_geometry("+%d+%d" % (x, y))
    elif backend == 'WXAgg':
        f.canvas.manager.window.SetPosition((x, y))
    else:
        # This works for QT and GTK
        # You can also use window.setGeometry
        f.canvas.manager.window.move(x, y)


def creat_segmentation_example_fig(img, mask0, mask1, mask2, mask_path, args):
    import matplotlib.pyplot as plt
    well_id = mask_path.stem.split("_")[2]
    fov = mask_path.stem.split("_")[3]
    treat = args.wellid2treat[well_id]
    celline = args.wellid2celline[well_id]

    fig, axes = plt.subplots(2, 2, sharex=True, sharey=True)
    fig.suptitle(f"{celline:15}{treat:12}{well_id:8}{fov}", **args.csfont)
    fig.set_size_inches(12, 13)
    move_figure(fig, 30, 30)
    #############################################################################
    # Enhance the contrast in case the images look too dim.
    # for shelton2 these values seem to work
    if args.rescale_image:
        img[0] = rescale_intensity(img[0], in_range=tuple(np.percentile(img[0], (40, 99))))
        img[1] = rescale_intensity(img[1], in_range=tuple(np.percentile(img[1], (50, 95))))
        img[2] = rescale_intensity(img[2], in_range=tuple(np.percentile(img[2], (50, 95))))
        img[3] = rescale_intensity(img[3], in_range=tuple(np.percentile(img[3], (50, 95))))
    ############################################################################
    # img1 = np.abs(img[3]-img[1])
    for idx, (it, ax) in enumerate(zip(["Nucleus", "Cyto", "Nucleoli", "Actin"], axes.flatten())):
        ax.set_ylabel(it, **args.csfont)
        ax.set_title(f"Channel {idx + 1}", **args.csfont)
        ax.set_xticks([])
        ax.set_yticks([])
    axes[0, 0].imshow(get_overlay(img[0], mask0, args.colors), cmap="gray")
    axes[0, 1].imshow(get_overlay(img[1], mask1, args.colors), cmap="gray")
    axes[1, 0].imshow(get_overlay(img[2], mask2, args.colors), cmap="gray")
    axes[1, 1].imshow(get_overlay(img[3], mask2, args.colors), cmap="gray")
    plt.subplots_adjust(hspace=0.1, wspace=.02)
    plt.show()
