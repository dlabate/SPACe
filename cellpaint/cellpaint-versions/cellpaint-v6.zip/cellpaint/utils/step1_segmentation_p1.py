import os
import time
from tqdm import tqdm

import tifffile
from skimage import io

import random
import itertools
import numpy as np
from cellpose import models
from skimage.color import label2rgb
from skimage.exposure import rescale_intensity
import matplotlib.pyplot as plt
from multiprocessing import Pool


from cellpaint.utils.helpers import MyBaseManager, TestProxy, sort_key_for_imgs, get_img_paths
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


class CellposeSegmentation:
    """Read all the image tif files for the experiment as a list and sort them, "img_paths".
     Then divide the files into groups each containing the 4/5 channels of a single image, "img_paths_groups".
     for example,
     [[args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F001L01A01Z01C01.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F001L01A02Z01C02.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F001L01A03Z01C03.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F001L01A04Z01C04.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F001L01A05Z01C05.tif,],

     [args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F002L01A01Z01C01.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F002L01A02Z01C02.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F002L01A03Z01C03.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F002L01A04Z01C04.tif,
     args.main_path\args.experiment\args.plate_protocol\args.plate_protocol_B02_T0001F002L01A05Z01C05.tif,]

     Note that if the number of cells segmented in an image is smaller than "MIN_CELLS",
     meaning the FOV/image is mostly empty, this function will NOT save the corresponding mask into disk!!!
     """
    # cellpose segmentation hyperparameters
    # batch_size = number of 224x224 blocks used to learn/extract the mask from nuclues/cyto using cellpose
    batch_size = 256
    cellpose_nucleus_diam = 100
    cellpose_cyto_diam = 100
    cellpose_model_type = 'cyto2'
    num_test_wells_per_condition = 2
    num_test_fovs_per_condition = 2

    def __init__(self, args):
        """self.N is the total number of images (when all their channels are grouped together) in the
        args.main_path\args.experiment\args.plate_protocol folder."""
        self.args = args
        self.cellpose_model = models.Cellpose(gpu=True, model_type=self.cellpose_model_type, net_avg=False)
        # the three key attributes of this class
        self.filename_keys, self.img_paths_groups, self.N = self.group_img_channels()

        if self.args.mode.lower() == "full":
            pass

        elif self.args.mode.lower() == "test":
            self.get_test_samples()

        elif self.args.mode.lower() == "debug":
            self.get_debug_samples()
        else:
            raise ValueError(f"{self.args.mode} value is not allowed!")

    def group_img_channels(self):
        """
        sort all tiff file in the self.args.main_path/self.args.experiment/self.args.plate_protocol folder.
         Then group them in such a way that all the tiff file which belong to the same image,
         the 4/5 channels of the same image, go to the same group.
         """
        img_paths = get_img_paths(self.args.main_path, self.args.experiment, self.args.plate_protocol)
        # ################################################################
        # group files that are channels of the same image together.
        # f"{ASSAY}_A02_T0001F002L01A02Z01C01.tif"
        # to group channels we need key = (folder, well_id, fov)
        filename_keys, img_paths_groups = [], []
        for key, grp in itertools.groupby(
                img_paths,
                key=lambda x: sort_key_for_imgs(x, self.args.plate_protocol, sort_purpose="to_group_channels")):
            filename_keys.append(key)
            img_paths_groups.append(list(grp))
        filename_keys = np.array(filename_keys, dtype=object)
        img_paths_groups = np.array(img_paths_groups, dtype=object)

        N = len(img_paths_groups)
        return filename_keys, img_paths_groups, N

    def get_debug_samples(self, ):
        # pick random indices
        random_idxs = random.sample(range(self.N), self.args.num_debug_images)
        # update
        self.filename_keys = self.filename_keys[random_idxs]
        self.img_paths_groups = self.img_paths_groups[random_idxs]
        self.N = len(self.filename_keys)

    def get_test_samples(self, ):
        """
        Crazy things can happen which might lead into a sample out of range situation.
        BUT, 99% of the time we should be able to successfully perform this sampling algorithm.

        samples self.num_test_wells_per_condition
         well-ids for each unique ("cell-line", "density", "dosage", "other").
         Also, includes DMSO treatment in the sampling, as it is our anchor during DistMap calculation in
         StepIV of Cellpaint.

        Note, for this work,
        the sampled well_ids must be present in both the plate_map excel-file and the image_folder.
        """
        #############################
        # Step I) First things first, one should restrict our well-ids sample pool to the ones that are present
        # in both the platemap, and, the image folder:
        wellids_from_plt = self.args.wellids
        wellids_from_imgs = np.unique(self.filename_keys[:, 1])
        allowed_wellids = np.intersect1d(wellids_from_plt, wellids_from_imgs)
        # print(len(wellids_from_plt), '\n', len(wellids_from_imgs), '\n', len(allowed_wellids))
        platemap = self.args.platemap.loc[np.isin(self.args.platemap["well-id"].values, allowed_wellids)]
        ##############################################
        # Step II) sample well-ids per condition from self.args.plate-map
        if len(self.args.treatments) == 1:  # there is only one treatment (most likely just DMSO)
            conds = [np.ones(len(platemap), dtype=bool)]
        else:  # otherwise, we need to sample DMSO well-ids + sample other compounds well-ids
            cond0 = platemap["treatment"] == self.args.anchor_treatment
            cond1 = platemap["treatment"] != self.args.anchor_treatment
            conds = [cond0, cond1]

        wellids = []
        for ii in range(len(conds)):
            groups = platemap[conds[ii]].groupby(["cell-line", "density", "dosage", "other"])
            for key, grp in groups:
                grp = list(grp['well-id'])
                wellids += random.sample(grp, self.num_test_wells_per_condition)
        # for it in wellids:
        #     print(platemap[platemap["well-id"] == it].values[0])
        # print('\n')
        ################################################################
        # Step III) use sample well-ids + a random fov to sample from our pool of image filepaths
        cond = np.zeros((self.N, ), dtype=bool)
        for wid in wellids:
            cond1 = self.filename_keys[:, 1] == wid
            fovs = self.filename_keys[cond1, 2]

            # fov = fovs[random.randint(0, len(fovs)-1)]  # select a random fov within this well
            # cond2 = self.filename_keys[:, 2] == fov
            fovs = random.sample(list(fovs), self.num_test_fovs_per_condition)
            cond2 = np.isin(self.filename_keys[:, 2], fovs)

            # print(wid, np.sum(cond1), len(fovs), fovs, fov)
            cond |= (cond1 & cond2)
        # print(self.N, np.sum(cond))
        ###########################################################
        # Step IV) finally, apply the update
        self.filename_keys = self.filename_keys[cond]
        self.img_paths_groups = self.img_paths_groups[cond]
        self.N = len(self.filename_keys)

    def get_cellpose_masks(self, idx):
        """
        cellpose-segmentation of a single image:
        Segment the nucleus and cytoplasm channels using Cellpose then save the masks to disk."""
        # get nucleus mask
        img0 = tifffile.imread(self.img_paths_groups[idx][self.args.nucleus_idx])
        img1 = tifffile.imread(self.img_paths_groups[idx][self.args.cyto_idx])

        w0_mask, _, _, _ = self.cellpose_model.eval(
            img0,
            diameter=self.cellpose_nucleus_diam,
            channels=[0, 0],
            batch_size=self.batch_size,
            z_axis=None,
            channel_axis=None,
            resample=False,
        )
        # get cyto mask
        w1_mask, _, _, _ = self.cellpose_model.eval(
            img1,
            diameter=self.cellpose_cyto_diam,
            channels=[0, 0],
            batch_size=self.batch_size,
            z_axis=None,
            channel_axis=None,
            resample=False,
        )
        # print(f"w0 w1 mask gen {time.time() - et}")

        if self.args.mode.lower() == "debug":
            # from skimage.measure import label
            # from skimage.segmentation import find_boundaries
            # img0 = rescale_intensity(img0, in_range=tuple(np.percentile(img0, (90, 99.99))))
            # img1 = rescale_intensity(img1, in_range=tuple(np.percentile(img1, (50, 99.9))))
            fig, axes = plt.subplots(2, 2, sharex=True, sharey=True)
            axes[0, 0].imshow(img0, cmap="gray")
            axes[0, 1].imshow(img1, cmap="gray")
            axes[1, 0].imshow(label2rgb(w0_mask, bg_label=0), cmap="gray")
            axes[1, 1].imshow(label2rgb(w1_mask, bg_label=0), cmap="gray")
            plt.show()

        # If the total number of segmented cells in both DAPI and CYTO channels is small then skip that image
        if (len(np.unique(w1_mask)) + len(np.unique(w0_mask))) // 2 <= self.args.min_cell_count:
            return

        # Save the masks into disk
        ####################################################################################################
        # Create a savename choosing a name for the experiment name, and also using the well_id, and fov.
        # ('2022-0817-CP-benchmarking-density_20220817_120119', 'H24', 'F009')
        exp_id, well_id, fov = self.filename_keys[idx][0], \
                               self.filename_keys[idx][1], \
                               self.filename_keys[idx][2]
        ####################################################################################################
        # et = time.time()
        # self.args.masks_path_p1 = args.analysis_save_path / "MasksP1"
        # args.analysis_save_path = args.main_path / args.experiment / ...
        nucleus_mask_save_name = f"w{self.args.nucleus_idx}_{well_id}_{fov}.png"
        cyto_mask_save_name = f"w{self.args.cyto_idx}_{well_id}_{fov}.png"
        io.imsave(self.args.masks_path_p1 / nucleus_mask_save_name, w0_mask, check_contrast=False)
        io.imsave(self.args.masks_path_p1 / cyto_mask_save_name, w1_mask, check_contrast=False)
        # print(f"saving {time.time() - et}")


def stepI_main_run_loop(args):
    """
    Main function for cellpaint step I:
        It performs segmentation of nucleus and cytoplasm channels,
        (99% of the time,they are the first and the second channel of each image)
        using the cellpose python package.

        It saves the two masks as separate png files into:

        if args.mode == "debug":
            self.args.masks_path_p1 = args.main_path / args.experiment / "Debug" / "MasksP1"
        elif args.mode == "test":
            self.args.masks_path_p1 = args.main_path / args.experiment / "Test" / "MasksP1"
        elif args.mode == "full":
            self.args.masks_path_p1 = args.main_path / args.experiment / "MasksP1"
    """
    print("Cellpaint Step I: Cellpose segmentation of Nucleus and Cytoplasm ...")
    segmenter = CellposeSegmentation(args)
    s_time = time.time()
    ranger = np.arange(segmenter.N)

    if segmenter.args.mode.lower() in ["debug", "test"]:
        ranger = tqdm(ranger, total=segmenter.N)

    for ii in ranger:
        segmenter.get_cellpose_masks(ii)
    print(f"Number of images in step I: {segmenter.N}")
    print(f"Finished Cellpaint step I in: {(time.time() - s_time) / 3600} hours\n")


# def stepI_run_main_loop(args):
    # TODO: Hack cellpose to be able to use it with multiprocessing for significant speed-up
#     MyManager = MyBaseManager()
#     # register the custom class on the custom manager
#     MyManager.register('CellposeSegmentation', CellposeSegmentation, TestProxy)
#     # create a new manager instance
#     with MyManager as manager:
#         inst = manager.CellposeSegmentation(args)
#         with Pool(processes=3) as pool:
#             for _ in tqdm(pool.imap_unordered(inst.get_cellpose_masks, range(inst.N)), total=inst.N):
#                 pass
