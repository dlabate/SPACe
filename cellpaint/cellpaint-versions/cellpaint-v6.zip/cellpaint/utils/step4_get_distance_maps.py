import time
from tqdm import tqdm
from pathlib import WindowsPath

import torch
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

import string
from scipy import stats
from sklearn.preprocessing import minmax_scale, robust_scale
import multiprocessing as mp

from cellpaint.utils.torch_functions import wassertein_distance_2d, skewness_measures, gs_div


pd.options.mode.chained_assignment = None


class DistMapCalc:
    """ """
    grouping_col = "well-id"
    nucleus_mean_intensity_thresh = 500

    def __init__(self, args,
                 compare_col,
                 anchor_col,
                 anchor_col_val,
                 device="cuda"
                 ):

        self.args = args
        self.device = device
        self.compare_col = compare_col
        self.anchor_col = anchor_col
        self.anchor_col_val = anchor_col_val
        self.normalize_quartile_range = (2, 98)

        # these values can be over-ridden by the subclasses
        self.distance_metric = ["median", "mean", "mode",
                                "wasserstein",
                                # "alpha-geodes-divergence",
                                "skewness", "kurtosis", "bimodality-index"]
        self.num_distance_metric = len(self.distance_metric)
        self.group_cols = ["exp-id", "well-id", "cell-line", "density", "treatment", "other", "dosage"]
        self.sort_cols = ["cell-line", "density", "treatment", "other", "dosage"]
        self.sort_ascending = [True, ]*len(self.sort_cols)

    def get_anchor_features(self, features, expid, anchor_col, anchor_col_val):
        """anchor_treatment: anchor treatment column value"""

        return features[
            (features["exp-id"] == expid) &
            (features["treatment"] == self.args.anchor_treatment) &  # 99% of the time it is equal to DMSO
            (features[anchor_col] == anchor_col_val) &
            (features["other"] == self.args.anchor_other)]

    def load_and_preprocess_features(self, expid):
        self.args.experiment = expid
        self.args.features_path = self.args.main_path / self.args.experiment / "Features"
        # TODO: Get number of features at each stage to get some sort of summary stats for quality control.
        w0_features = pd.read_csv(self.args.features_path / "w0_features.csv")
        w1_features = pd.read_csv(self.args.features_path / "w1_features.csv")
        w2_features = pd.read_csv(self.args.features_path / "w2_features.csv")
        w3_features = pd.read_csv(self.args.features_path / "w3_features.csv")
        w4_features = pd.read_csv(self.args.features_path / "w4_features.csv")
        misc_features = pd.read_csv(self.args.features_path / "misc_features.csv")
        metadata = pd.read_csv(self.args.features_path / "metadata_of_features.csv")
        # print(metadata.columns)
        if "exp-id" not in list(metadata.columns):
            # metadata["exp-id"] = self.args.experiment
            metadata.insert(0, "exp-id", self.args.experiment)
        not_dark = self.filter_dark_cells_fn(w0_features)
        # automatically calculates when meta_cols end and feature cols starts, i.e. self.start_index

        # The first 4 feature columns for each channel are bounding boxes.
        # They are not used for distance-map calculation, and have to be removed.
        # all_features contains metadata columns and also feature columns,
        # i.e. feature columns belonging to each channel
        # print(w0_features.shape, w0_features.loc[not_dark, w0_features.columns[4:]].shape)
        all_features = pd.concat([
            metadata.loc[not_dark],
            misc_features.loc[not_dark],
            w0_features.loc[not_dark, w0_features.columns[4:]],
            w1_features.loc[not_dark, w1_features.columns[4:]],
            w2_features.loc[not_dark, w2_features.columns[4:]],
            w3_features.loc[not_dark, w3_features.columns[4:]],
            w4_features.loc[not_dark, w4_features.columns[4:]]],
            axis=1)
        all_features = all_features.loc[all_features["has-nucleoli"] == 1]
        all_features = self.remove_outer_wells_fn(all_features)
        print("shape of all_features after loading and some preprocessing: ", all_features.shape)
        ##################################################################################
        # Deprecated!!!
        # if self.args.experiment == "Bolt-MCF7-CellPaint_20220929_160725":
        #     # all_features.insert(0, "other", all_features["well-id"].apply(
        #     #     lambda x: "Treatment" if x['well-id'] in list("ABCDEFGH") else "Growth",axis=1))
        #     all_features["treatment"] = all_features[["treatment", "well-id"]].apply(
        #         lambda x: f"{x['treatment']}-t" if x['well-id'][0] in list("ABCDEFGH") else f"{x['treatment']}-g",
        #         axis=1)
        ######################################################################
        # self.meta_cols = metadata.columns
        self.start_index = metadata.shape[1]
        # print(all_features.shape, metadata.shape)
        # print(metadata.columns)
        # print(misc_features.columns)
        # print(all_features.columns)
        # print('\n')
        self.min_num_cols = self.start_index + 5 * 5

        return all_features

    def get_distance_matrix_wellwise_np(self, features, anchor_features):
        # get the list of features
        feat_cols = list(features.columns)[self.start_index:]
        # ensuring unique well-ids are taken from the specific col and not all the features
        anchor_features = anchor_features[feat_cols]
        # group them based on each well
        groups = features[
            ["exp-id", "well-id", ] + feat_cols].groupby(
            ["exp-id", "well-id", ], group_keys=False)
        print("started distance matrix calculations ...")
        print("features shape: ", features.shape)
        print("anchor_features shape: ", anchor_features.shape)

        # get median and mean of each feature
        mean_df = groups.mean(numeric_only=True)
        median_dist = groups.median(numeric_only=True).to_numpy()
        well_ids = mean_df.index
        mean_dist = mean_df.to_numpy()

        # get median and mean of each feature for dmso data frame
        anchor_median = anchor_features.median(axis=0, ).to_numpy()
        anchor_mean = anchor_features.mean(axis=0, ).to_numpy()
        anchor_features = anchor_features.to_numpy()

        # get signed median and mean distances for each feature
        median_dist = np.subtract(median_dist, anchor_median)
        sign_mat = np.sign(median_dist)
        mean_dist = sign_mat * np.subtract(mean_dist, anchor_mean)

        # get signed distribution distances for each feature
        distrib_dist = groups.apply(lambda x: self.get_wass_dist(x, anchor_features))
        distrib_dist = sign_mat * np.vstack(distrib_dist)
        return well_ids, distrib_dist, median_dist, mean_dist

    def get_distance_matrix_wellwise_torch(self, features, anchor_features, case_name, device):
        features.reset_index(inplace=True, drop=True)
        # get the list of features
        start_time = time.time()
        feat_cols = list(features.columns[self.start_index:])
        M = len(feat_cols)
        N1 = len(np.unique(features["exp-id"]))*len(np.unique(features["well-id"]))
        groups = features[self.group_cols].groupby(self.group_cols, group_keys=False)
        # loop over the (expid, wellid) unique pairs in the features dataframe
        # TODO: might need to figure out how to set this number properly
        groups_meta = np.zeros((N1, len(self.group_cols) + 1), dtype=object)
        groups_index = np.zeros((len(features),), dtype=np.int64)
        for ii, (key, slice_) in enumerate(groups):
            groups_meta[ii] = (len(slice_),) + tuple(key)  # len(slice_) is the cell-count
            groups_index[slice_.index] = ii
        groups_meta = groups_meta[0:ii + 1]
        N = len(groups_meta)
        # unix, counts = np.unique(groups_index, return_counts=True)
        # print(groups_meta.shape, groups_index.shape, len(unix), np.sum(counts))

        # We transfer the features dataframe to GPU once,
        # to avoid the transfer from cpu to gpu time cost.
        features_tensor = np.float32(features[feat_cols].to_numpy()).T
        anchor_features = np.float32(anchor_features[feat_cols].to_numpy()).T
        groups_index = torch.as_tensor(np.int64(groups_index)).to(device)
        features_tensor = torch.as_tensor(features_tensor).to(device)
        anchor_features = torch.as_tensor(anchor_features).to(device)
        # print(groups_index.shape, groups_index.dtype, features_tensor.shape, anchor_features.shape)
        distances = torch.zeros((len(self.distance_metric), N, M), dtype=torch.float32).to(device)
        with torch.no_grad():
            # ["median", "mean", "mode",
            # "wasserstein", "alpha-geodes-divergence", "skewness", "kurtosis", "bi-index"]
            for ii in range(N):
                # make sure you calculate the distance metrics in order of appearance
                cond = groups_index == ii
                median_distance = torch.median(features_tensor[:, cond], dim=1)[0] - \
                                  torch.median(anchor_features, dim=1)[0]
                median_sign = torch.sign(median_distance)
                mean_distance = torch.mul(torch.mean(features_tensor[:, cond], dim=1) -
                                          torch.mean(anchor_features, dim=1),
                                          median_sign)
                mode_distance = torch.mul(torch.mode(features_tensor[:, cond], dim=1)[0] -
                                          torch.mode(anchor_features, dim=1)[0],
                                          median_sign)
                wassertein_distance = torch.mul(wassertein_distance_2d(
                    features_tensor[:, cond], anchor_features),
                    median_sign)
                # alpha_gs_div_measure = torch.mul(gs_div(
                #     features_tensor[:, cond], anchor_features, alpha=-1, lmd=0.5, dim=1, reduction="mean"),
                #     median_sign)
                skew_measure, kurt_measure,  bi_index_measure = skewness_measures(
                    features_tensor[:, cond], dim=1)
                # print(median_distance.shape, mean_distance.shape, mode_distance.shape,
                #                     wassertein_distance.shape,
                #                     skew_measure.shape, kurt_measure.shape,  bi_index_measure.shape)
                distances[:, ii, :] = torch.stack([
                    median_distance, mean_distance, mode_distance,
                    wassertein_distance, # alpha_gs_div_measure,
                    skew_measure, kurt_measure,  bi_index_measure], dim=0)


        distances = distances.cpu().numpy()
        torch.cuda.empty_cache()
        print("time taken in secs ... ", time.time() - start_time)

        # saving, we have to split in two orders: 1) per experiment 2) per distance type
        for ii in range(distances.shape[0]):
            dist_data = pd.DataFrame(
                np.concatenate((groups_meta, distances[ii]), axis=1),
                columns=["cell-count"] + self.group_cols + feat_cols)
            dist_data.sort_values(by=self.sort_cols, ascending=self.sort_ascending, inplace=True)
            # save for each experiment in its own folder.
            dist_data = dist_data.groupby(["exp-id"], group_keys=False)
            for experiement, item in dist_data:
                # print(experiement, item)
                save_path = self.args.main_path / experiement / "DistanceMaps" / \
                            f"{case_name}_{self.distance_metric[ii]}.csv"
                item.to_csv(save_path, index=False)
        print('\n')

    def normalize_features(self, features):
        """Normalizes the feature columns of the features dataframe."""
        # normalize each feature column (NOT metadata columns)
        feature_cols = list(features.columns[self.start_index:])
        features[feature_cols] = robust_scale(
            features[feature_cols].to_numpy(), quantile_range=self.normalize_quartile_range)
        # clip outlier feature values to -1 and 1
        features[feature_cols] = features[feature_cols].clip(lower=-1, upper=1)
        return features

    def filter_dark_cells_fn(self, w0_features):
        """To take care of illumination issues in some of the experiments. Mainly, the ones with Griener
        plating protocol."""

        if self.args.filter_dark_cells:
            return w0_features['Nucleus_Intensities_mean'].to_numpy() > self.nucleus_mean_intensity_thresh
        return np.ones((w0_features.shape[0],), dtype=bool)

    def remove_outer_wells_fn(self, all_features, ):
        """To take care of illumination issues in some of the experiments. Mainly, the ones with Griener
        plating protocol."""
        if self.args.remove_outer_wells:
            rows = list(string.ascii_uppercase[:16])
            cols = [str(ii).zfill(2) for ii in np.arange(1, 25)]
            outer_wells = [row + col for row in ['A', 'P'] for col in cols] + \
                          [row + col for col in [cols[0], cols[-1]] for row in rows]
            all_features = all_features[~all_features['well-id'].isin(outer_wells)]
            # print(all_features.shape)
        return all_features

    def drop_uninformative_feature_cols(self, df):
        feature_cols = df.columns[self.start_index:]
        df.drop(
            df[feature_cols].columns[df[feature_cols].apply(lambda col: self.col_is_not_informative(col))],
            axis=1,
            inplace=True)
        return df

    @staticmethod
    def get_wass_dist(x, dmso_features):
        """
        x is an (N, num_features+1) pandas dataframe where the first column is the well_id,
        and the rest of the columns are feature columns. x contains info of all the cells belonging
        to a specific well.

        dmso_features is an (M, num_features)
        numpy array where the columns are the DMSO (our reference/zero compound/treatment) features.
        """
        feature_cols = list(x.columns)[1:]
        x = x[feature_cols].to_numpy()
        N = len(feature_cols)
        dists = np.zeros((N,), dtype=np.float32)
        for ii in range(N):
            dists[ii] = stats.wasserstein_distance(x[:, ii], dmso_features[:, ii])
        return dists

    @staticmethod
    def col_is_informative(col):
        """Identifies low variation and unstable columns, for removal."""
        col = col.to_numpy()
        median = np.median(col)
        mad = stats.median_abs_deviation(col)

        return (median >= 1e-4) & \
               (np.sum((-1e-6 < col) & (col < 1e-6)) / len(col) < .2) & \
               (np.abs(mad / median) >= 1e-4)

    @staticmethod
    def col_is_not_informative(col):
        """Identifies low variation and unstable columns, for removal."""
        col = col.to_numpy()
        if np.sum((-1e-6 < col) & (col < 1e-6)) / len(col) > .2:
            return True

        median = np.median(col)
        if median < 1e-4:
            return True

        mad = stats.median_abs_deviation(col)
        if np.abs(mad / median) < 1e-4:
            return True
        return False


class DRCBMCellLinesAcrossExperiments(DistMapCalc):
    """Comparing each Cell-line Across different experiments.
    To See How stable the features are across replicates."""

    def __init__(self,
                 args,
                 ):
        # investigate this bullshit problem later
        # args.anchor_dosage = 0 if np.isin(0, args.anchor_dosage) else 0.01
        # anchor_dosage = np.amin(args.anchor_dosage)
        super().__init__(
            args,
            compare_col="treatment",
            anchor_col="dosage",
            anchor_col_val=args.anchor_dosage, )

    #     self.args.cellline2exclude = "U2OS"
    # def exclude_celline(self, features):
    #     if self.args.cellline2exclude is not None:
    #         features = features[features["cell-line"].to_numpy() != self.args.cellline2exclude.lower()]
    #     return features

    # TODO: figure out a better way to handle more than 1 replicate
    def calculate(self, replicate_exp_ids, anchor_exp_id):
        print(replicate_exp_ids, anchor_exp_id)
        assert anchor_exp_id == replicate_exp_ids[0], """Always put the anchor as the first element."""
        print("calculating distance maps for DRC, all cell-lines together ... ")
        all_features = pd.concat([self.load_and_preprocess_features(it) for it in replicate_exp_ids], axis=0)
        # all_features = self.exclude_celline(all_features)
        print(f"all_features after combining:  shape={all_features.shape}  #cols={len(all_features.columns)}")
        print(np.unique(all_features["exp-id"]))
        groups = all_features.groupby(["density", "cell-line"], group_keys=False)
        for ii, (key, feats) in enumerate(groups):
            case_name = f"density={key[0]}_cellline={key[1]}"
            print(f"density={key[0]}  cellline={key[1]}  #cols={len(feats.columns)}")
            feats = self.drop_uninformative_feature_cols(feats)
            if feats.shape[1] <= self.min_num_cols:
                continue
            feats = self.normalize_features(feats)
            # if there are multiple experiments with the same cell-line, then anchor experiment matters,
            # otherwise it does not.
            anchor_exp_id = anchor_exp_id if np.isin(anchor_exp_id, feats["exp-id"].values) else \
                feats["exp-id"].iloc[0]
            anchor_feats = self.get_anchor_features(feats, anchor_exp_id, self.anchor_col, self.anchor_col_val)
            print("feats shape: ", feats.shape)
            print("anchor_feats shape: ", anchor_feats.shape)
            self.get_distance_matrix_wellwise_torch(feats, anchor_feats, case_name, self.device)


class DMSOBM(DistMapCalc):

    def __init__(self,
                 args,
                 ):
        super().__init__(
            args,
            compare_col="cell-line",
            anchor_col="cell-line",
            anchor_col_val=None, )

    def calculate(self, replicate_exp_ids, anchor_exp_id, anchor_cellline):
        # restricting to self.args.anchor_treatment which is dmso 99% of the time
        print("calculating distance maps for DMSO comparison across cell-lines... ")
        features = pd.concat([self.load_and_preprocess_features(it) for it in replicate_exp_ids], axis=0)
        features = features[features["treatment"] == self.args.anchor_treatment]
        assert len(features) > 1000, "anchor treatment has to be present " \
                                     "in all cell-lines and experiments with enough cells"
        print("features after restricting to dmso: ", features.shape)
        cell_lines = features["cell-line"].unique()
        densities = features["density"].unique()
        print(cell_lines, densities)

        features = self.drop_uninformative_feature_cols(features)
        if features.shape[1] <= self.min_num_cols:
            return
        features = self.normalize_features(features)
        anchor_features = self.get_anchor_features(features, anchor_exp_id, "cell-line", anchor_cellline)
        print("features shape: ", features.shape)
        print("anchor_features shape: ", anchor_features.shape)
        self.get_distance_matrix_wellwise_torch(
            features, anchor_features, f"DMSO_{anchor_cellline}_{anchor_exp_id}", self.device)


class DensityBM(DistMapCalc):

    def __init__(self,
                 args,
                 compare_col
                 ):
        # usually compare_col="cell-line" i guess.
        super().__init__(
            args,
            compare_col=compare_col,
            anchor_col="density",
            anchor_col_val=args.anchor_density, )

    def calculate(self, ):
        print("calculating distance maps for Density Benchmarking ... ")
        # restricting to self.args.anchor_treatment which is dmso 99% of the time
        features = self.load_and_preprocess_features(self.args.expid)
        densities = features["density"].unique()
        print("densities: ", densities)
        features = self.drop_uninformative_feature_cols(features)
        if features.shape[1] <= self.min_num_cols:
            return
        features = self.normalize_features(features)
        anchor_features = self.get_anchor_features(features, self.args.expid)
        print(f"features {features.shape}\n anchor features {anchor_features.shape}")
        well_ids, distrib_dist, median_dist, mean_dist = self.get_distance_matrix_wellwise_np(
            features, anchor_features)

        self.convert_and_save_to_csv(well_ids, distrib_dist, median_dist, mean_dist, features,
                                     self.args.anchor_treatment)





def stepIV_main_run_loop(args):
    """
    Main function for cellpaint step IV:
        It generates distribution, median, and mean distance-maps (for a SINGLE experiment),
        based on the following three scenarios so far:

        Note that, there are 6 sheets in the platemap excel file at the moment:
            Treatment, Cellline, Density, Dosage, Other, and Anchor.

        We can use the first 5 sheets to decide/switch to/indentify the type of experiment it is.
        We use the last sheet (Anchor) to decide what is the anchor condition (our 0/zero to compare against)

            Case 1) A dose-response-benchmarking experiment, when:
                There are multiple dosages found in the Dosage sheet, of the platemap excel file.

            Case 2) A (DMSO/Vehicle) Density-benchmarking experiment, when:
                2-1) There is a SINGLE dosage in the Dosage sheet, AND
                2-2) There is a SINGLE treatment/compound (DMSO/Vehicle) in the Treatment sheet, BUT
                    the are multiple densities in the Density sheet, of the platemap excel file

            Case 3) A Density-benchmarking experiment for a whole set of treatments/compounds, when:
                3-1) There exist a single dosage in the Dosage sheet, BUT
                3-2) There are multiple treatments/compounds in the Treatment sheet, And
                3-3) There are multiple densities in the Density sheet, of the platemap excel file.
        Finally,
        Also whenever there multiple cell-lines in the CellLine sheet of the platemap excel file,
        we always need to compare the (DMSO/vehicle) of different cell-lines against each other, given
        the Anchor cell-line provided the Anchor sheet, of the platemap excel-file.

        It saves the resulting feature maps into separate csv files:
            self.args.distancemaps_path / f"{save_name}_distrib-dist.csv"
            self.args.distancemaps_path / f"{save_name}_mean-dist.csv"
            self.args.distancemaps_path / f"{save_name}_median-dist.csv"

        where

        if args.mode.lower() == "debug":
            self.args.distancemaps_path = args.main_path / args.experiment / "Debug" / "DistanceMaps"
        elif args.mode.lower() == "test":
            self.args.distancemaps_path = args.main_path / args.experiment / "Test" / "DistanceMaps"
        elif args.mode.lower() == "full":
            self.args.distancemaps_path = args.main_path / args.experiment / "DistanceMaps"
    """

    # basically in CellPaintArgs.add_platemap_anchor_args, we read/got the following for the last sheet the platemap
    # excel file:
    #   1) anchor compound/treatment (==dmso   99.99% percent of the time)
    #   2) anchor cell-line (only needed when there are multiples celllines)
    #   3) anchor density (only needed for density experiments)
    #   4) anchor dosage (==0   99.9% of the time, needed for dose-response experiments.)
    #   5) anchor other (==0 90% of the time. Only needed for when the other sheet of the platemap is not empty!)

    s_time = time.time()
    print("Cellpaint Step IV ... Calculating distance maps")

    # if len(args.dosages) > 1:  # case 1
    #
    #     print("Detect multiple Dosages ...\n"
    #           "Creating Distance Maps for a Dosage Response Benchmarking ...")
    #     distmap = DRCBMCellLinesAcrossExperiments(args, )
    #     distmap.calculate(args.experiment_group, args.anchor_experiment)
    #
    # elif len(args.dosages) == 1 and len(args.celllines) == 1 and \
    #         len(args.densities) > 1 and len(args.treatments) > 1:  # case 2-2
    #
    #     print("Detected single dosage, but multiple densities as well as multiple treatments:\n"
    #           "Creating Distance Maps for Density Benchmarking ...")
    #     distmap = DensityBM(args, compare_col="treatment")
    #     distmap.calculate()
    #
    # elif len(args.dosages) == 1 and \
    #         len(args.celllines) == 1 and \
    #         len(args.treatments) == 1 and \
    #         len(args.densities) > 1:
    #
    #     print(f"Detected\nsingle dosage\nsingle cell-line\nsingle treatment: {args.anchor_treatment} "
    #           f"But there are multiple densities:\n"
    #           f"Creating Distance Maps for {args.anchor_treatment.upper()} Density Benchmarking ...")
    #     distmap = DensityBM(args, compare_col="density")  # case 2-1
    #     distmap.calculate()
    #
    # else:
    #     raise ValueError("args.dosage can't be empty")

    if len(args.celllines) > 1:  # comparing DMSO of multiple cell-lines when there is more than one cell-line
        print("Detected Multiple Cellines ... \n"
              f"Creating Distance Maps for comparing {args.anchor_treatment.upper()} of different Cell-lines ...")
        for anchor_cellline in args.anchor_celllines:
            args.anchor_cellline = anchor_cellline
            distmap = DMSOBM(args)
            distmap.calculate(args.experiment_group, args.anchor_experiment)
    print(f"Finished Cellpaint step IV in: {(time.time() - s_time) / 3600} hours\n")
