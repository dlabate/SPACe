import time
from tqdm import tqdm
from pathlib import WindowsPath

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

import string
from scipy import stats
from sklearn.preprocessing import minmax_scale, robust_scale
import multiprocessing as mp

pd.options.mode.chained_assignment = None


class DistMapCalc:
    """ """
    grouping_col = "well-id"
    nucleus_mean_intensity_thresh = 1500

    def __init__(self, args,
                 compare_col,
                 anchor_col,
                 anchor_col_val,
                 ):

        self.args = args

        self.compare_col = compare_col
        self.anchor_col = anchor_col
        self.anchor_col_val = anchor_col_val
        self.normalize_quartile_range = (2, 98)

        # these values can be over-ridden by the subclasses
        self.meta_cols = ["cell-line", "density", "treatment", "other", "dosage"]
        self.distmap_cols = ["well-id", "cell-count"] + self.meta_cols
        self.meta_cols_sort_ascending = [True, True, True, True, True]

    def get_anchor_features(self, features):
        """anchor_treatment: anchor treatment column value"""
        # print("treatment: ", np.unique(features["treatment"], return_counts=True))
        # print(f"{self.anchor_col}", np.unique(features[self.anchor_col], return_counts=True))
        # print("other: ", np.unique(features["other"], return_counts=True))
        # print("anchor treatment", self.args.anchor_treatment)
        # print("anchor col val", self.anchor_col_val)
        # print("other col anchor val", self.args.anchor_other)

        return features.loc[
            (features["treatment"] == self.args.anchor_treatment) &   # 99% of the time it is equal to DMSO
            (features[self.anchor_col] == self.anchor_col_val) &
            (features["other"] == self.args.anchor_other)]

    def load_and_preprocess_features(self):
        # TODO: Get number of features at each stage to get some sort of summary stats for quality control.
        w0_features = pd.read_csv(self.args.features_path / "w0_features.csv")
        w1_features = pd.read_csv(self.args.features_path / "w1_features.csv")
        w2_features = pd.read_csv(self.args.features_path / "w2_features.csv")
        w3_features = pd.read_csv(self.args.features_path / "w3_features.csv")
        w4_features = pd.read_csv(self.args.features_path / "w4_features.csv")
        misc_features = pd.read_csv(self.args.features_path / "misc_features.csv")
        metadata = pd.read_csv(self.args.features_path / "metadata_of_features.csv")
        not_dark = self.filter_dark_cells_fn(w0_features)
        # automatically calculates when meta_cols end and feature cols starts, i.e. self.start_index

        # The first 4 feature columns for each channel are bounding boxes.
        # They are not used for distance-map calculation, and have to be removed.
        # all_features contains metadata columns and also feature columns,
        # i.e. feature columns belonging to each channel
        all_features = pd.concat([
            metadata.loc[not_dark],
            misc_features.loc[not_dark],
            w0_features.loc[not_dark, w0_features.columns[4:]],
            w1_features.loc[not_dark, w1_features.columns[4:]],
            w2_features.loc[not_dark, w2_features.columns[4:]],
            w3_features.loc[not_dark, w3_features.columns[4:]],
            w4_features.loc[not_dark, w4_features.columns[4:]]],
            axis=1)
        all_features = all_features.loc[all_features["has-nucleoli"] == 1]
        all_features = self.remove_outer_wells_fn(all_features)
        print("shape of all_features after loading and some preprocessing: ", all_features.shape)
        ##################################################################################
        # Deprecated!!!
        # if self.args.experiment == "Bolt-MCF7-CellPaint_20220929_160725":
        #     # all_features.insert(0, "other", all_features["well-id"].apply(
        #     #     lambda x: "Treatment" if x['well-id'] in list("ABCDEFGH") else "Growth",axis=1))
        #     all_features["treatment"] = all_features[["treatment", "well-id"]].apply(
        #         lambda x: f"{x['treatment']}-t" if x['well-id'][0] in list("ABCDEFGH") else f"{x['treatment']}-g",
        #         axis=1)
        ######################################################################
        # self.meta_cols = metadata.columns
        self.start_index = metadata.shape[1]
        self.min_num_cols = self.start_index + 5 * 5

        return all_features

    def get_distance_matrix_wellwise(self, features, anchor_features):
        # get the list of features
        feat_cols = list(features.columns)[self.start_index:]
        # ensuring unique well-ids are taken from the specific col and not all the features
        anchor_features = anchor_features[feat_cols]
        # group them based on each well
        groups = features[["well-id", ] + feat_cols].groupby(["well-id", ], group_keys=False)
        print("started distance matrix calculations ...")
        print("features shape: ", features.shape)
        print("anchor_features shape: ", anchor_features.shape)

        # get median and mean of each feature
        mean_df = groups.mean(numeric_only=True)
        median_dist = groups.median(numeric_only=True).values
        well_ids = mean_df.index
        mean_dist = mean_df.values

        # get median and mean of each feature for dmso data frame
        anchor_median = anchor_features.median(axis=0, ).values
        anchor_mean = anchor_features.mean(axis=0, ).values
        anchor_features = anchor_features.values

        # get signed median and mean distances for each feature
        median_dist = np.subtract(median_dist, anchor_median)
        sign_mat = np.sign(median_dist)
        mean_dist = sign_mat * np.subtract(mean_dist, anchor_mean)

        # get signed distribution distances for each feature
        distrib_dist = groups.apply(lambda x: self.get_wass_dist(x, anchor_features))
        distrib_dist = sign_mat * np.vstack(distrib_dist)
        return well_ids, distrib_dist, median_dist, mean_dist

    def convert_and_save_to_csv(self, well_ids, distrib_dist, median_dist, mean_dist, features, save_name):
        N = len(well_ids)
        M = len(self.distmap_cols)
        meta = np.zeros((N, M), dtype=object)
        for ii, wid in tqdm(enumerate(well_ids), total=len(well_ids)):
            row = features.loc[features["well-id"] == wid, self.meta_cols].values
            cell_count = len(row)
            # treatment = self.create_dash_separated_entries(treatment)
            meta[ii, :] = (wid, cell_count) + tuple([row[0, jj] for jj in range(len(self.meta_cols))])
        meta = pd.DataFrame(meta, columns=self.distmap_cols)
        distrib_dist = pd.DataFrame(distrib_dist, columns=list(features.columns)[self.start_index:])
        mean_dist = pd.DataFrame(mean_dist, columns=list(features.columns)[self.start_index:])
        median_dist = pd.DataFrame(median_dist, columns=list(features.columns)[self.start_index:])
        distrib_dist = pd.concat([meta, distrib_dist], axis=1)
        mean_dist = pd.concat([meta, mean_dist], axis=1)
        median_dist = pd.concat([meta, median_dist], axis=1)

        # """https://stackoverflow.com/questions/50012525/how-to-sort-pandas-dataframe-by-custom-order-on-string-index"""
        # reorderrows = sorted(rows, key=self.sort_fn)
        # distrib_dist = distrib_dist.reindex(reorderrows)
        distrib_dist.sort_values(by=self.meta_cols, ascending=self.meta_cols_sort_ascending, inplace=True)
        mean_dist.sort_values(by=self.meta_cols, ascending=self.meta_cols_sort_ascending, inplace=True)
        median_dist.sort_values(by=self.meta_cols, ascending=self.meta_cols_sort_ascending, inplace=True)

        distrib_dist.to_csv(self.args.distancemaps_path / f"{save_name}_distrib-dist.csv", index=False)
        mean_dist.to_csv(self.args.distancemaps_path / f"{save_name}_mean-dist.csv", index=False)
        median_dist.to_csv(self.args.distancemaps_path / f"{save_name}_median-dist.csv", index=False)

    def normalize_features(self, features):
        """Normalizes the feature columns of the features dataframe."""
        # normalize each feature column (NOT metadata columns)
        feature_cols = list(features.columns[self.start_index:])
        features[feature_cols] = robust_scale(
            features[feature_cols].values, quantile_range=self.normalize_quartile_range)
        # clip outlier feature values to -1 and 1
        features[feature_cols] = features[feature_cols].clip(lower=-1, upper=1)
        return features

    def filter_dark_cells_fn(self, w0_features):
        """To take care of illumination issues in some of the experiments. Mainly, the ones with Griener
        plating protocol."""

        if self.args.filter_dark_cells:
            return w0_features['Nucleus_Intensities_mean'].values > self.nucleus_mean_intensity_thresh
        return np.ones((w0_features.shape[0],), dtype=bool)

    def remove_outer_wells_fn(self, all_features,):
        """To take care of illumination issues in some of the experiments. Mainly, the ones with Griener
        plating protocol."""
        if self.args.remove_outer_wells:
            rows = list(string.ascii_uppercase[:16])
            cols = [str(ii).zfill(2) for ii in np.arange(1, 25)]
            outer_wells = [row + col for row in ['A', 'P'] for col in cols] + \
                          [row + col for col in [cols[0], cols[-1]] for row in rows]
            all_features = all_features[~all_features['well-id'].isin(outer_wells)]
            # print(all_features.shape)
        return all_features

    def drop_uninformative_feature_cols(self, df):
        feature_cols = df.columns[self.start_index:]
        df.drop(
            df[feature_cols].columns[df[feature_cols].apply(lambda col: self.col_is_not_informative(col))],
            axis=1,
            inplace=True)
        return df


    @staticmethod
    def get_wass_dist(x, dmso_features):
        """
        x is an (N, num_features+1) pandas dataframe where the first column is the well_id,
        and the rest of the columns are feature columns. x contains info of all the cells belonging
        to a specific well.

        dmso_features is an (M, num_features)
        numpy array where the columns are the DMSO (our reference/zero compound/treatment) features.
        """
        feature_cols = list(x.columns)[1:]
        x = x[feature_cols].values
        N = len(feature_cols)
        dists = np.zeros((N,), dtype=np.float32)
        for ii in range(N):
            dists[ii] = stats.wasserstein_distance(x[:, ii], dmso_features[:, ii])
        return dists

    @staticmethod
    def col_is_informative(col):
        """Identifies low variation and unstable columns, for removal."""
        col = col.values
        median = np.median(col)
        mad = stats.median_abs_deviation(col)

        return (median >= 1e-4) & \
               (np.sum((-1e-6 < col) & (col < 1e-6)) / len(col) < .2) & \
               (np.abs(mad / median) >= 1e-4)

    @staticmethod
    def col_is_not_informative(col):
        """Identifies low variation and unstable columns, for removal."""
        col = col.values
        if np.sum((-1e-6 < col) & (col < 1e-6)) / len(col) > .2:
            return True

        median = np.median(col)
        if median < 1e-4:
            return True

        mad = stats.median_abs_deviation(col)
        if np.abs(mad / median) < 1e-4:
            return True
        return False


class DRCBMCellLinesIndividually(DistMapCalc):

    def __init__(self,
                 args,
                 ):
        super().__init__(
            args,
            compare_col="treatment",
            anchor_col="dosage",
            anchor_col_val=0)

    def calculate(self):
        all_features = self.load_and_preprocess_features()
        cell_lines = all_features["cell-line"].unique()
        for ii in range(len(cell_lines)):
            densities = all_features["density"].unique()
            for jj in range(len(densities)):  # lsit of tuples (meta_column, meta_column_anchor_value)
                save_name = f"{cell_lines[ii]}-d={densities[jj]}"
                features = all_features[
                    (all_features["cell-line"] == cell_lines[ii]) &
                    (all_features["density"] == densities[jj])]
                features = self.drop_uninformative_feature_cols(features)
                if features.shape[1] <= self.min_num_cols:
                    continue
                features = self.normalize_features(features)
                anchor_features = self.get_anchor_features(features)
                print(f"cell-line:   {cell_lines[ii]}    density:  {densities[jj]}")
                print("features shape: ", features.shape)
                print("anchor_features shape: ", anchor_features.shape)
                well_ids, distrib_dist, median_dist, mean_dist = self.get_distance_matrix_wellwise(
                    features, anchor_features)
                self.convert_and_save_to_csv(
                    well_ids, distrib_dist, median_dist, mean_dist, features, save_name)


class DRCBMCellLinesAllTogether(DistMapCalc):

    def __init__(self,
                 args,
                 ):
        super().__init__(
            args,
            compare_col="treatment",
            anchor_col="dosage",
            anchor_col_val=0)

    def exclude_celline(self, features):
        if self.args.cellline2exclude is not None:
            features = features[features["cell-line"].values != self.args.cellline2exclude]
        return features

    def calculate(self):
        print("calculating distance maps for DRC, all cell-lines together ... ")
        all_features = self.load_and_preprocess_features()
        all_features = self.exclude_celline(all_features)
        densities = all_features["density"].unique()

        for jj in range(len(densities)):  # lsit of tuples (meta_column, meta_column_anchor_value)
            save_name = f"d={densities[jj]}"
            features = all_features[all_features["density"] == densities[jj]]
            features = self.drop_uninformative_feature_cols(features)
            if features.shape[1] <= self.min_num_cols:
                continue
            features = self.normalize_features(features)
            anchor_features = self.get_anchor_features(features)
            print(f"density:  {densities[jj]}")
            print("features shape: ", features.shape)
            print("anchor_features shape: ", anchor_features.shape)
            well_ids, distrib_dist, median_dist, mean_dist = self.get_distance_matrix_wellwise(
                features, anchor_features)
            self.convert_and_save_to_csv(
                well_ids, distrib_dist, median_dist, mean_dist, features, save_name)


class DMSOBM(DistMapCalc):

    def __init__(self,
                 args,
                 ):
        super().__init__(
            args,
            compare_col="cell-line",
            anchor_col="cell-line",
            anchor_col_val=args.anchor_cellline,)

    def calculate(self, ):
        # restricting to self.args.anchor_treatment which is dmso 99% of the time
        print("calculating distance maps for DMSO comparison across cell-lines... ")
        features = self.load_and_preprocess_features()
        features = features[features["treatment"] == self.args.anchor_treatment]
        print("features after restricting to dmso: ", features.shape)
        cell_lines = features["cell-line"].unique()
        densities = features["density"].unique()
        print(cell_lines, densities)

        features = self.drop_uninformative_feature_cols(features)
        if features.shape[1] <= self.min_num_cols:
            return
        features = self.normalize_features(features)
        anchor_features = self.get_anchor_features(features)
        well_ids, distrib_dist, median_dist, mean_dist = self.get_distance_matrix_wellwise(
            features, anchor_features)

        self.convert_and_save_to_csv(well_ids, distrib_dist, median_dist, mean_dist, features,
                                     self.args.anchor_treatment)


class DensityBM(DistMapCalc):

    def __init__(self,
                 args,
                 compare_col
                 ):
        # usually compare_col="cell-line" i guess.
        super().__init__(
            args,
            compare_col=compare_col,
            anchor_col="density",
            anchor_col_val=args.anchor_density,)

    def calculate(self, ):
        print("calculating distance maps for Density Benchmarking ... ")
        # restricting to self.args.anchor_treatment which is dmso 99% of the time
        features = self.load_and_preprocess_features()
        densities = features["density"].unique()
        print("densities: ", densities)
        features = self.drop_uninformative_feature_cols(features)
        if features.shape[1] <= self.min_num_cols:
            return
        features = self.normalize_features(features)
        anchor_features = self.get_anchor_features(features)
        print(f"features {features.shape}\n anchor features {anchor_features.shape}")
        well_ids, distrib_dist, median_dist, mean_dist = self.get_distance_matrix_wellwise(
            features, anchor_features)

        self.convert_and_save_to_csv(well_ids, distrib_dist, median_dist, mean_dist, features,
                                     self.args.anchor_treatment)


def stepIV_main_run_loop(args):
    """
    Main function for cellpaint step IV:
        It generates distribution, median, and mean distance-maps (for a SINGLE experiment),
        based on the following three scenarios so far:

        Note that, there are 6 sheets in the platemap excel file at the moment:
            Treatment, Cellline, Density, Dosage, Other, and Anchor.

        We can use the first 5 sheets to decide/switch to/indentify the type of experiment it is.
        We use the last sheet (Anchor) to decide what is the anchor condition (our 0/zero to compare against)

            Case 1) A dose-response-benchmarking experiment, when:
                There are multiple dosages found in the Dosage sheet, of the platemap excel file.

            Case 2) A (DMSO/Vehicle) Density-benchmarking experiment, when:
                2-1) There is a SINGLE dosage in the Dosage sheet, AND
                2-2) There is a SINGLE treatment/compound (DMSO/Vehicle) in the Treatment sheet, BUT
                    the are multiple densities in the Density sheet, of the platemap excel file

            Case 3) A Density-benchmarking experiment for a whole set of treatments/compounds, when:
                3-1) There exist a single dosage in the Dosage sheet, BUT
                3-2) There are multiple treatments/compounds in the Treatment sheet, And
                3-3) There are multiple densities in the Density sheet, of the platemap excel file.
        Finally,
        Also whenever there multiple cell-lines in the CellLine sheet of the platemap excel file,
        we always need to compare the (DMSO/vehicle) of different cell-lines against each other, given
        the Anchor cell-line provided the Anchor sheet, of the platemap excel-file.

        It saves the resulting feature maps into separate csv files:
            self.args.distancemaps_path / f"{save_name}_distrib-dist.csv"
            self.args.distancemaps_path / f"{save_name}_mean-dist.csv"
            self.args.distancemaps_path / f"{save_name}_median-dist.csv"

        where

        if args.mode.lower() == "debug":
            self.args.distancemaps_path = args.main_path / args.experiment / "Debug" / "DistanceMaps"
        elif args.mode.lower() == "test":
            self.args.distancemaps_path = args.main_path / args.experiment / "Test" / "DistanceMaps"
        elif args.mode.lower() == "full":
            self.args.distancemaps_path = args.main_path / args.experiment / "DistanceMaps"
    """

    # basically in CellPaintArgs.add_platemap_anchor_args, we read/got the following for the last sheet the platemap
    # excel file:
    #   1) anchor compound/treatment (==dmso   99.99% percent of the time)
    #   2) anchor cell-line (only needed when there are multiples celllines)
    #   3) anchor density (only needed for density experiments)
    #   4) anchor dosage (==0   99.9% of the time, needed for dose-response experiments.)
    #   5) anchor other (==0 90% of the time. Only needed for when the other sheet of the platemap is not empty!)

    s_time = time.time()
    print("Cellpaint Step IV: \n Calculating distance maps")

    if len(args.dosages) > 1:   # case 1

        print("Detect multiple Dosages ...\n"
              "Creating Distance Maps for a Dosage Response Benchmarking ...")
        distmap = DRCBMCellLinesIndividually(args,)
        distmap.calculate()
        if len(args.celllines) > 1:
            distmap = DRCBMCellLinesAllTogether(args,)
            distmap.calculate()

    elif len(args.dosages) == 1 and len(args.celllines) == 1 and \
            len(args.densities) > 1 and len(args.treatments) > 1:  # case 2-2

        print("Detected single dosage, but multiple densities as well as multiple treatments:\n"
              "Creating Distance Maps for Density Benchmarking ...")
        distmap = DensityBM(args, compare_col="treatment")
        distmap.calculate()

    elif len(args.dosages) == 1 and \
            len(args.celllines) == 1 and \
            len(args.treatments) == 1 and \
            len(args.densities) > 1:

        print(f"Detected\nsingle dosage\nsingle cell-line\nsingle treatment: {args.anchor_treatment} "
              f"But there are multiple densities:\n"
              f"Creating Distance Maps for {args.anchor_treatment.upper()} Density Benchmarking ...")
        distmap = DensityBM(args, compare_col="density")  # case 2-1
        distmap.calculate()

    else:
        raise ValueError("args.dosage can't be empty")

    if len(args.celllines) > 1:  # comparing DMSO of multiple cell-lines when there is more than one cell-line
        print("Detected Multiple Cellines:\n"
              f"Creating Distance Maps for comparing {args.anchor_treatment.upper()} of different Cell-lines ...")

        distmap = DMSOBM(args)
        distmap.calculate()
    print(f"Finished Cellpaint step IV in: {(time.time()-s_time)/3600} hours\n")
