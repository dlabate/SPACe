import os
import time

import scipy.stats
from tqdm import tqdm

import numpy as np
import pandas as pd

from scipy import stats
from sklearn.preprocessing import minmax_scale, robust_scale

import seaborn as sns
import matplotlib.pyplot as plt

# from plotly import express as px
# from plotly.subplots import make_subplots
# import plotly.graph_objects as go

import multiprocessing as mp
from functools import partial

from utils.args import args, create_shared_multiprocessing_name_space_object


def get_counts(features):
    temp_df = features["well-id"].value_counts().to_frame(name="cell count")
    temp_df.insert(loc=0, column="well-id", value=temp_df.index)
    print(temp_df.head(5))
    print(temp_df.shape, type(temp_df))
    temp_df.insert(loc=0, column="density", value=temp_df["well-id"].apply(lambda x: args.wellid2density[x]))
    temp_df.insert(loc=0, column="treatment", value=temp_df["well-id"].apply(lambda x: args.wellid2treat[x]))
    temp_df.to_csv(args.main_path/args.experiment/"features_cell_counts.csv")
    return temp_df


def drop_nan_cols(features, start_index=5):
    channels = np.array([x.split("-")[0] for x in features.columns[start_index:]], dtype=str)
    channels = channels[np.sort(np.unique(channels, return_index=True)[1])]
    cols2drop = [f"{cin}-moments_normalized-{ii}-{jj}"
                 for cin in channels
                 for ii in range(0, 2) for jj in range(0, 2)]
    cols2drop = [it for it in cols2drop if "-1-1" not in it]
    features.drop(cols2drop, axis=1, inplace=True)
    return features


def drop_numerically_unstable_cols(features, start_index):
    # check for numerical stability
    cols2drop = []
    print(features.shape)
    for col in tqdm(features.columns[start_index:]):
        cond0 = (features[col].values > -1e-6)
        cond1 = (features[col].values < 1e-6)
        median = np.median(features[col].values)
        mad = scipy.stats.median_abs_deviation(features[col].values)
        # print(mad)
        if median < 1e-4:
            cols2drop.append(col)
        #     print(f"{col:50} {100*np.sum(cond)/len(features):.2f}")
        elif (100 * np.sum(cond0 & cond1) / len(features) > 10) or (np.abs(mad/median) < 1e-4):
            #         features.drop(col, axis=1, inplace=True)
            cols2drop.append(col)
        # else:
        #     features = features.loc[~(cond0 & cond1)]

    #     if np.sum(features[cond][col].values)>.1*len(features[col]):
    #         print(f"{col:50} {100*np.sum(cond)/len(features):.2f}")
    features.drop(cols2drop, axis=1, inplace=True)
    print(features.shape)
    # for col in cols2drop:
    #     print(col)
    return features


def load_features(start_index):
    features = pd.read_csv(args.main_path/args.experiment/"features.csv")
    # # well_ids = np.unique(features["well-id"])
    # if other_key not in list(features.columns):
    #     start_index = 6
    #     features.insert(loc=0, column=other_key, value=features["well-id"].apply(lambda x: args.wellid2density[x]))
    #     # features["density"] = features["well-id"].apply(lambda x: args.wellid2density[x])
    # features["treatment"] = features["well-id"].apply(lambda x: args.wellid2treat[x])

    # features = drop_nan_cols(features, start_index=start_index)
    features = drop_numerically_unstable_cols(features, start_index=start_index)
    # fig = px.histogram(features, x=["Actin+protein/ER-moments_normalized-2-3"])
    # fig.show()
    # features = normalize_features(features, lb=2, ub=98)
    # fig = px.histogram(features, x=["Actin+protein/ER-moments_normalized-2-3"])
    # fig.show()
    return features


def normalize_features(features, lb=2, ub=98, start_index=5):
    # normalize each feature
    feat_cols = list(features.columns[start_index:])
    features[feat_cols] = robust_scale(features[feat_cols].values, quantile_range=(lb, ub))
    # clip outlier values to -1 and 1
    features[feat_cols] = features[feat_cols].clip(lower=-1, upper=1)
    return features


def get_wass_dist(wid, features, dmso_df, start_index=6):

    dist_mat = np.zeros(len(features.columns[start_index:]))
    for jj, feat_col in enumerate(features.columns[start_index:]):
        x = features.loc[(features["well-id"] == wid)][feat_col].values
        y = dmso_df[feat_col].values
        # print(x, y)
        sign = np.sign(np.median(x, axis=0) - np.median(y, axis=0))
        dist_mat[jj] = sign * stats.wasserstein_distance(x, y)
    return dist_mat


def get_distance_matrix_wellwise_per_col(
        features, anchor, meta_col, meta_col_anchor_val, meta_col_non_anchor_val=None, start_index=7):
    # feat_cols = list(features.columns[start_index:])
    # TODO: ADD raise value error if both are not None
    if meta_col_non_anchor_val is not None:
        feats = features.loc[(features[meta_col] == meta_col_non_anchor_val)]
        dmso_df = features.loc[(features['treatment'] == anchor) & (features[meta_col] == meta_col_non_anchor_val)]
    elif meta_col_anchor_val is not None:
        feats = features
        dmso_df = features.loc[(features['treatment'] == anchor) & (features[meta_col] == meta_col_anchor_val)]
    else:
        raise ValueError("")
    # ensuring unique well-ids are taken from the specific col and not all the features
    wellids = np.unique(feats["well-id"])
    ncol = len(feats.columns) - start_index
    nrow = len(wellids)
    dist_mat = np.zeros((nrow, ncol), dtype=np.float32)
    my_func = partial(get_wass_dist, features=feats, dmso_df=dmso_df, start_index=start_index)
    with mp.Pool(processes=mp.cpu_count()) as pool:
        for jjj, out in tqdm(enumerate(pool.imap(my_func, wellids)), total=len(wellids)):
            dist_mat[jjj] = out
    # for jjj, wid in tqdm(enumerate(wellids), total=len(wellids)):
    #         dist_mat[jjj] = my_func(wid)
    return dist_mat


def get_distance_matrix_wellwise_all_col_values(
        features, meta_col, meta_col_values, start_index=6, anchor='DMSO'):
    # feat_cols = list(features.columns[start_index:])
    # ncol = len(features.columns) - start_index
    dist_mat = np.zeros((len(meta_col_values), ), dtype=object)
    for ii, meta_col_val in enumerate(meta_col_values):
        # features, anchor, meta_col, meta_col_anchor_val, meta_col_non_anchor_val = None, start_index = 7
        dist_mat[ii] = get_distance_matrix_wellwise_per_col(
            features, anchor=anchor, meta_col=meta_col, meta_col_anchor_val=None,
            meta_col_non_anchor_val=meta_col_val,
            start_index=start_index,)
    return dist_mat


def convert_dist_mat_to_df_per_col_value(dist_mat, features, meta_col, meta_col_val, start_index, sort_fn):
    if meta_col_val is not None:
        wellids = np.unique(features.loc[features[meta_col] == meta_col_val]["well-id"])
    else:
        wellids = np.unique(features["well-id"])

    rows = np.zeros_like(wellids)
    # counts = np.zeros_like(wellids)
    for ii, wid in tqdm(enumerate(wellids), total=len(wellids)):
        # if other_key is None:
        #     row = features.loc[features["well-id"] == wid][["treatment", ]].values[0]
        #     treatment = row[0]
        #     rows[ii] = f"{treatment}_{wid}"
        # else:
        rr = features.loc[features["well-id"] == wid][["treatment", meta_col]].values
        treatment, cond_val = rr[0][0], rr[0][1]
        rows[ii] = f"{treatment}_{cond_val}_{wid}_{len(rr)}"
        # counts[ii] = len(rows)
        # print(wid, rows.shape, len(treatment))
    dist_df = pd.DataFrame(dist_mat, index=rows, columns=features.columns[start_index:])
    # dist_df.insert(loc=0, column="cell count", value=counts)
    """https://stackoverflow.com/questions/50012525/how-to-sort-pandas-dataframe-by-custom-order-on-string-index"""

    reorderrows = sorted(rows, key=sort_fn)
    dist_df = dist_df.reindex(reorderrows)
    # print(dist_df.head(20))
    return dist_df


def sort_fn(x, meta_col):
    """x = f"{treatment}_{meta_col_val}_{wid}_{num_cells}" """
    if meta_col == "dosage":
        return x.split("_")[0], float(x.split("_")[1][0:-2]), x.split("_")[2]
    elif meta_col == "density":
        return x.split("_")[0], float(x.split("_")[1][0:-1]), x.split("_")[2]


def main():
    ######################################################################################
    # start_index = 6
    # args.experiment = "2022-0817-CP-benchmarking-density_20220817_120119"
    # meta_col = "density"
    # meta_col_anchor_val = "2.5k"
    # anchor = "veh"
    # densities = sorted(list(np.unique(features['density'])), key=lambda x: float(x[0:-1]))
    # print(densities)
    ########################################################################################
    # start_index = 7
    # args.experiment = "others"
    # meta_col = "dosage"
    # meta_col_anchor_val = "1.0uM"
    # anchor = 'negcon[dmso]'
    #######################################################################################
    start_index = 7
    args.experiment = "20220831-cellpainting-benchmarking-DRC_20220831_173200"
    meta_col = "dosage"
    meta_col_anchor_val = "0uM"
    anchor = "veh"
    ########################################################################################
    # CASE 0) NORMALIZE ALL FEATURES TOGETHER, THEN CALCULATE ALL FEATURE MAPS TOGETHER
    for cin in [0, 1, 2, 3, 4]:
        ##########################################################################################
        print(f"loading channel {cin} features ...")
        s_time = time.time()
        features = pd.read_csv(args.main_path/args.experiment/f"w{cin}_features.csv")
        print(f"w{cin}_features csv file loading time in seconds: {time.time()-s_time}")
        features = features.loc[features["has nucleoli"] == 1]
        # print(features == 0)
        # print(features.columns[(features == 0).all()])
        features = drop_numerically_unstable_cols(features, start_index=start_index)
        features = normalize_features(features, lb=2, ub=98, start_index=start_index)
        # only for DRC and others experiments
        features["dosage"] = features["dosage"].apply(lambda x: f"{x}uM" if x == 0 or x == "0" else x)
        ##########################################################################################
        s_time = time.time()
        print("calculating distribution distance map")
        dist_mat = get_distance_matrix_wellwise_per_col(
            features, anchor=anchor, meta_col=meta_col, meta_col_anchor_val=meta_col_anchor_val,
            meta_col_non_anchor_val=None,
            start_index=start_index)
        print(f"time took  in seconds: {time.time()-s_time}")
        print(features.shape)
        print(np.unique(features["dosage"].values))
        print(np.unique(features["treatment"].values))
        print(f"saving as numpy array ....")
        np.save(args.main_path/args.experiment/f"distribution-distance-w{cin}.npy", dist_mat)
        print(f"saving complete ....")
        ##########################################################################################
        # dist_mat = np.load(args.main_path/args.experiment/f"distribution-distance-w{cin}.npy",)
        print(f"converting distribution distance matrix to a pandas dataframe ....")
        dist_df = convert_dist_mat_to_df_per_col_value(
            dist_mat,
            features,
            meta_col,
            meta_col_val=None,
            start_index=start_index,
            sort_fn=lambda x: sort_fn(x, meta_col))
        # print(dist_df.head(10))
        print(f"saving as csv file ....")
        dist_df.to_csv(args.main_path/args.experiment/f"distribution-distance-w{cin}.csv")
        print(f"saving complete .... \n")
        #############################################################################################
        # # visualize
        # for thresh in [.05, .1, .15, .2]:
        #     fig = px.imshow(dist_df[(dist_df <= -thresh) | (dist_df >= thresh)], color_continuous_scale="jet")
        #     fig.write_html(args.main_path/args.experiment/f"features_{thresh}_case0.html")

    # #######################################################################################
    # # CASE 1) NORMALIZE ALL FEATURES TOGETHER, THEN CALCULATE FEATURE MAPS PER DENSITY, SEPARATELY
    # features = load_features(start_index)
    # features = normalize_features(features, lb=2, ub=98, start_index=start_index)
    # densities = sorted(list(np.unique(features['density'])), key=lambda x: float(x[0:-1]))
    # print(densities)
    # # a dist_mat is calculated per density
    # dist_mat = get_distance_matrix_wellwise_all_col_values(
    #     features, "density", densities, start_index=start_index, anchor="veh")
    # for mat, den in zip(dist_mat, densities):
    #     print("case1", den)
    #     dist_df = convert_dist_mat_to_df_per_col_value(mat, features, "density", den, start_index=start_index)
    #     # visualize
    #     fig = px.imshow(dist_df[(dist_df <= -thresh) | (dist_df >= thresh)], color_continuous_scale="jet")
    #     fig.write_html(args.main_path/args.experiment/f"features_{thresh}_case1_density={den}.html")
    # # ##########################################################################################


    #
    # # CASE 2) NORMALIZE FEATURES PER DENSITY, THEN CALCULATE FEATURE MAPS PER DENSITY, SEPARATELY
    # features = load_features(start_index)
    # densities = np.unique(features["density"])
    # for density in densities:
    #     features.iloc[features['density'] == density] = normalize_features(
    #         features.iloc[features['density'] == density], lb=2, ub=98, start_index=start_index)
    # # a dist_mat is calculated per density
    # dist_mat = get_distance_matrix_wellwise_all_col_values(
    #     features, "density", densities, start_index=start_index, anchor="veh")
    # for mat, den in zip(dist_mat, densities):
    #     print("case2", den)
    #     dist_df = convert_dist_mat_to_df_per_col_value(mat, features, "density", den, start_index=start_index)
    #     # visualize
    #     fig = px.imshow(dist_df[(dist_df <= -thresh) | (dist_df >= thresh)], color_continuous_scale="jet")
    #     fig.write_html(args.main_path/args.experiment/f"features_{thresh}_case2_density={den}.html")
    # ##########################################################################################
    #
    # # CASE 3) NORMALIZE FEATURES PER TREATMENT, THEN CALCULATE FEATURE MAPS PER TREATMENT, SEPARATELY
    # features = load_features(start_index)
    # treatments = np.unique(features["treatment"])
    # for treat in treatments:
    #     features.iloc[features['treatment'] == treat] = normalize_features(
    #         features.iloc[features['treatment'] == treat], lb=2, ub=98, start_index=start_index)
    #     # a dist_mat is calculated per treatment
    #     dist_mat = get_distance_matrix_wellwise_all_col_values(
    #         features.iloc[features['treatment'] == treat],
    #         "density", densities, start_index=start_index, anchor="veh")
    #     for mat, den in zip(dist_mat, densities):
    #         dist_df = convert_dist_mat_to_df_per_col_value(
    #             mat, features.iloc[features['treatment'] == treat],
    #             "density", den, start_index=start_index)
    #         # visualize
    #         fig = px.imshow(dist_df[(dist_df <= -thresh) | (dist_df >= thresh)], color_continuous_scale="jet")
    #         fig.write_html(args.main_path/args.experiment/f"features_{thresh}_case3_{treat}_{den}.html")


if __name__ == "__main__":
    args = create_shared_multiprocessing_name_space_object(args)
    main()
