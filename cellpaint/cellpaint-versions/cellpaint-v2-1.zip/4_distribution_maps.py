import os
from pathlib import WindowsPath
import time

import scipy.stats
from tqdm import tqdm

import numpy as np
import pandas as pd

from scipy import stats
from sklearn.preprocessing import minmax_scale, robust_scale

import seaborn as sns
import matplotlib.pyplot as plt

# from plotly import express as px
# from plotly.subplots import make_subplots
# import plotly.graph_objects as go

import multiprocessing as mp
from functools import partial


main_path = WindowsPath(r"F:\CellPainting")
# experiment = "2022-0817-CP-benchmarking-density_20220817_120119"
# experiment = "others"
experiment = "20220831-cellpainting-benchmarking-DRC_20220831_173200"
axis_font = {'fontname': 'Arial', 'size': '14'}

for cin, channel_name in zip([0, 1, 2, 3, 4], ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]):
    dist_df = pd.read_csv(main_path / experiment / f"distribution-distance-w{cin}.csv", index_col=0)
    # print(dist_df.head(10))
    for thresh in [.05, .1, .15, .2, .25, .3]:
        print(cin, thresh)
        df_plot = dist_df[(dist_df <= -thresh) | (dist_df >= thresh)]
        cols = list(dist_df.columns)
        c0 = df_plot[[it for it in cols if "bbox" not in it]]
        xlabels = c0.columns.tolist()
        xlabels = ["".join(it.split('-')[1:]) for it in xlabels]
        f, (ax1, axcb) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [1, 0.08]},)
        f.set_size_inches(21.3, 13.3)
        # f.set_size_inches(54.1, 33.8 )
        f.suptitle(f"{channel_name}", **axis_font)
        g1 = sns.heatmap(c0, cmap="jet", ax=ax1, cbar_ax=axcb)
        g1.set_xticks(np.arange(0, len(xlabels), 2))
        g1.set_xticklabels([it for ii, it in enumerate(xlabels) if ii % 2 == 0])

        # may be needed to rotate the ticklabels correctly:
        for ax in [g1]:
            tl = ax.get_xticklabels()
            ax.set_xticklabels(tl, rotation=90)
            tly = ax.get_yticklabels()
            ax.set_yticklabels(tly, rotation=0)

        plt.subplots_adjust(wspace=.05)
        # plt.tight_layout()
        plt.savefig(main_path/experiment/f"{channel_name}-{thresh}.png", bbox_inches='tight', dpi=300)
        # plt.show()