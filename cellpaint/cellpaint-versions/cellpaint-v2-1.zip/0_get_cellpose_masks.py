import sys, os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import time
from tqdm import tqdm
import numpy as np
import itertools
from cellpose import models
from skimage import io

import tifffile
import matplotlib.pyplot as plt
from skimage.exposure import rescale_intensity
from skimage.color import label2rgb
# from skimage.measure import label
# from skimage.segmentation import find_boundaries

from utils.args import args
from utils.image_and_mask_files import get_key_from_img_path, get_img_paths

# TODO: Add comments and functions and explanations


# def get_batches(X, Y, batch_size):
#     # batch generator
#     n_samples = len(X)
#     indices = np.arange(n_samples)
#     # # Shuffle at the start of epoch
#     # np.random.shuffle(indices)
#     for start in range(0, n_samples, batch_size):
#         end = np.minimum(start + batch_size, n_samples)
#         batch_idx = indices[start:end]
#         yield X[batch_idx], Y[batch_idx]

# # Disable
# def blockPrint():
#     sys.stdout = open(os.devnull, 'w')


def get_w0_and_w1_masks_single_img(MODEL, img_parg_group, key):
    # get nucleus mask
    w0_mask, _, _, _ = MODEL.eval(
        # tifffile.imread(img_paths[1]),
        tifffile.imread(img_parg_group[args.nucleus_idx]),
        diameter=args.cellpose_nucleus_diam,
        channels=[0, 0],
        batch_size=args.batch_size,
        z_axis=None,
        channel_axis=None,
        resample=False,
    )

    # get cyto mask
    w1_mask, _, _, _ = MODEL.eval(
        # tifffile.imread(img_paths[1]),
        tifffile.imread(img_parg_group[args.cyto_idx]),
        diameter=args.cellpose_nucleus_diam,
        channels=[0, 0],
        batch_size=args.batch_size,
        z_axis=None,
        channel_axis=None,
        resample=False,
    )
    # print(f"time to finish cyto image: {time.time() - s1_time} seconds")

    if args.testing:
        print(img_parg_group[0])
        print(img_parg_group[1])
        img0 = tifffile.imread(img_parg_group[0])
        img1 = tifffile.imread(img_parg_group[1])
        # img0 = rescale_intensity(img0, in_range=tuple(np.percentile(img0, (90, 99.99))))
        # img1 = rescale_intensity(img1, in_range=tuple(np.percentile(img1, (50, 99.9))))
        fig, axes = plt.subplots(2, 2, sharex=True, sharey=True)
        axes[0, 0].imshow(img0, cmap="gray")
        axes[0, 1].imshow(img1, cmap="gray")
        axes[1, 0].imshow(label2rgb(w0_mask, bg_label=0), cmap="gray")
        axes[1, 1].imshow(label2rgb(w1_mask, bg_label=0), cmap="gray")
        plt.show()

    # If the total number of segmented cells in both DAPI and CYTO channels is small then skip that image
    if (len(np.unique(w1_mask)) + len(np.unique(w0_mask))) / 2 <= args.min_cell_count + 1:
        return
    ####################################################################################################
    # Create a savename choosing a name for the experiment name, and also using the well_id, and fov.
    # ('2022-0817-CP-benchmarking-density_20220817_120119', 'H24', 'F009')
    exp_id, well_id, fov = key[0], key[1], key[2]
    save_name = f"{args.expid}_{well_id}_{fov}"
    ####################################################################################################
    # Save the masks into disk
    io.imsave(args.cellpose_masks_path / f"w0_{save_name}.png", w0_mask, check_contrast=False)
    io.imsave(args.cellpose_masks_path / f"w1_{save_name}.png", w1_mask, check_contrast=False)


def main():
    """Read all the image tif files for the experiment as a list and sort them, "img_paths".
    Then divide the files into groups each containing the 4/5 channels of a single image, "img_paths_groups".
    for example,
    [[args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A01Z01C01.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A02Z01C02.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A03Z01C03.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A04Z01C04.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A05Z01C05.tif,],

    [args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A01Z01C01.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A02Z01C02.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A03Z01C03.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A04Z01C04.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A05Z01C05.tif,]

    Note that if the number of cells segmented in an image is smaller than "MIN_CELLS",
    meaning the FOV/image is mostly empty, this function will NOT save the corresponding mask into disk!!!

    First, quality check those segmentation by setting TESTING = True.
    Once satisfied, set the TESTING= False and run the code again.

    In addition make sure to choose a proper unique key for your experiment.
    for example the master folder containing the images.
    At the moment it is set as either "EXPERIMENT" or EXPIDS[your_index]

    Enjoy!!!"""

    MODEL = models.Cellpose(gpu=True, model_type='cyto2', net_avg=False)
    print(MODEL.device)
    # f"{ASSAY}_A02_T0001F002L01A02Z01C01.tif"
    img_paths = get_img_paths(args.main_path, args.experiment, args.lab)
    # img = tifffile.imread(img_paths[1])
    # ################################################################
    # group files that are channels of the same image together.
    keys, img_paths_groups = [], []
    for item in itertools.groupby(
            img_paths, key=lambda x: get_key_from_img_path(x, args.lab, key_purpose="to_group_channels")):
        keys.append(item[0])
        img_paths_groups.append(list(item[1]))
    # args.num_channels = len(img_paths_groups[0])
    # print("num_channels: ", args.num_channels)
    # assert args.batch_size > args.num_channels
    keys = np.array(keys, dtype=object)
    img_paths_groups = np.array(img_paths_groups, dtype=object)
    N = len(img_paths_groups)
    # for key, item in tqdm(zip(keys, img_paths_groups)):

    s_time = time.time()
    # for ii in tqdm(range(N), total=N):
    for ii in range(N):
        # for item in img_paths_groups[ii]:
        #     print(item)
        # print(keys[ii], '\n', img_paths_groups[ii][0], '\n', img_paths_groups[ii][1], '\n')
        # s1_time = time.time()
        get_w0_and_w1_masks_single_img(MODEL, img_paths_groups[ii], keys[ii])
        # if ii == 20:
        #     break
    print(f"time taken to finish {2*(ii+1)} images: {(time.time()-s_time)/3600} hours")


if __name__ == "__main__":
    main()
