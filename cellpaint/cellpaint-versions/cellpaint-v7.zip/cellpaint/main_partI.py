import time
from cellpaint.utils.args import CellPaintArgs
from cellpaint.utils.step1_segmentation_p1 import stepI_main_run_loop
from cellpaint.utils.step2_segmentation_p2 import stepII_main_run_loop
from cellpaint.utils.step3_feature_extraction import stepIII_main_run_loop
from cellpaint.utils.step4_get_distance_maps import stepIV_main_run_loop
from cellpaint.utils.step5_plot_heatmaps import stepV_main_run_loop


def main_worker(args):
    """
    This program has three modes:

    1) args.mode="debug":
      It helps with debugging and making sure the logic
      of the code follows through all the steps without any errors or breaks,
      Use it, if you want to make changes/improvements in a small part of the code.
      It does not any multiprocess.

    2) args.mode="test":
        Always run main_worker using args.mode=="test" first.
        It makes sure the code/program runs from start to finish on a small number (args.num_test_images) of images
        in args.main_path / args.experiment / args.img_folder folder.
        It uses multiprocess in step II and III for speed-up.

    3) args.mode="full":
         Runs the main_worker on the entire set of tiff images in the
         args.main_path / args.experiment / args.img_folder folder.
         It uses multiprocess in step II and III for speed-up.
    """

    stepI_main_run_loop(args)
    # stepII_main_run_loop(args)
    # stepIII_main_run_loop(args)


if __name__ == "__main__":
    for experiment in [
        # "20220920-CP-Bolt-Seema",
        # "20220930-CP-Bolt-Seema",
        # "20221021-CP-Bolt-Seema",
        #
        # "20220607-CP-Fabio-U2OS-Density",

        # "20220912-CP-Bolt-MCF7",
        # "20220929-CP-Bolt-MCF7",
        # "20221024-CP-Bolt-MCF7",

        # "20220831-CP-Fabio-DRC-BM-R01",
        # "20220908-CP-Fabio-DRC-BM-R02",

        # "20221102-CP-Fabio-DRC-BM-P01",
        # "20221102-CP-Fabio-DRC-BM-P02",

        # "20221109-CP-Fabio-DRC-BM-P01",
        # "20221109-CP-Fabio-DRC-BM-P02",

        # "20221116-CP-Fabio-DRC-BM-P01",
        # "20221116-CP-Fabio-DRC-BM-P02",

        # "20221207-CP-CCandler-Exp2244-1",
        "20221208-CP-CCandler-Exp2244-2",

    ]:
        # entry point of the program is creating the necessary args
        start_time = time.time()
        args = CellPaintArgs(
            experiment=experiment,
            mode="full",
        ).args
        print(f"{args.experiment}")
        main_worker(args)
        print(f"prgogram finished analyzing experiment "
              f"{args.experiment} in {(time.time()-start_time)/3600} hours...")
        print('\n')