import torch
import pandas as pd
import numpy as np
import random

from scipy.integrate import simpson
from numpy import trapz

from cellpaint.utils.helpers import MyBaseManager, TestProxy, unique_with_preservered_order, find_first_occurance
from cellpaint.utils.args import CellPaintArgs
import matplotlib.pyplot as plt
import seaborn as sns


def get_df_unix(df, keys):
    unix = []
    grp = df.groupby(keys) if len(keys) > 1 else df.groupby(keys[0])
    for key, val in grp:
        # print(key)
        unix.append(key)
    # print(unix, keys, unix[0])
    # print(df[get_df_at_cond(df, keys, unix[0])])
    return unix


def get_df_at_cond(df, keys, vals):
    assert isinstance(vals, np.ndarray)
    N, M = len(df), len(keys)
    cond = np.ones((N,), dtype=bool)
    for ii in range(M):
        cond &= df[keys[ii]] == vals[ii]
    return cond


class DerivativeMaps:
    """ """
    start_index = 8
    # TODO: Fix these, so that they can be extracted from the distancemap csv file
    feature_types = ["Shapes", "Intensities", "Haralicks-Local"]
    channels = ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]
    distance_maps = ["mean", "median", "wasserstein"]

    distance_map_index = 2
    distance_map_name = "wasserstein"
    thresholds = np.linspace(0, 1, 100)
    dx = (1-0)/100
    N1, N2, M = len(channels), len(feature_types), len(thresholds)
    num_maps = 2
    auc_threshold = .1

    def __init__(self, args, cell_line="mcf7"):
        self.args = args
        # colors = ["black", "blue", "red", "green", "orange", "yellow", "brown", "pink", "purple"]
        self.density = np.unique(self.args.densities)[0]
        self.cell_line = cell_line
        self.xlabels = [f"{it0}_{it1}" for it0 in self.channels for it1 in self.feature_types]

    def plot_deriv_curves(self, derivative_map, min_, max_, meta_unix, colors, title, savename, plot_type):
        fig, axes = plt.subplots(self.N1, self.N2, sharex=True, sharey=True)
        fig.set_size_inches(21.3, 13.3)
        index = []
        for ii, it1 in enumerate(self.channels):
            axes[ii, 0].set_ylabel(it1, fontname="Courier New", fontsize=17)
            for jj, it2 in enumerate(self.feature_types):
                if ii == 0:
                    axes[0, jj].set_title(it2, **self.args.csfont)
                diff = (max_[ii, jj]-min_[ii, jj])
                for kk, (it3, it4) in enumerate(zip(meta_unix, colors)):
                    vals = (derivative_map[ii, jj, kk, :-1]-min_[ii, jj])/diff
                    # print(vals.shape, np.where(vals == 0))
                    zids = np.where(np.abs(vals) < 1e-6)[0]
                    if len(zids) > 0:
                        index.append(zids[0])
                    axes[ii, jj].plot(self.thresholds[:-1], vals,
                                      label=it3[1] if plot_type == "typeI" else it3,
                                      color=it4)
                    axes[ii, jj].set_ylim([0, 1])
        if len(index) > 1:
            x_max_id = np.amax(index)
        else:
            x_max_id = -1
        for ii, it1 in enumerate(self.channels):
            for jj, it2 in enumerate(self.feature_types):
                axes[ii, jj].set_xlim([0, self.thresholds[x_max_id]])

        plt.suptitle(title, fontname="Corbel", fontsize=18)
        plt.legend(loc="lower center",
                   bbox_to_anchor=(-.7, -1.1),
                   ncols=8 if len(meta_unix) > 20 else 4,
                   borderaxespad=0.1,
                   fancybox=False,
                   shadow=False,
                   prop={'size': 17, 'family': 'Consolas'})

        # fig.text(0.06, 0.5, f"# of none-zero entries", va='center', rotation='vertical', **args.csfont)
        # fig.text(0.5, 0.04, f"Thresholds used to zero out entries", ha='center', **args.csfont)
        # Create a big subplot
        ax = fig.add_subplot(111, frameon=False)
        # hide tick and tick label of the big axes
        ax.tick_params(labelcolor='none', top='off', bottom='off', left='off', right='off')
        # Use argument `labelpad` to move label downwards or leftward.
        ax.set_xlabel(f"Threshold used to zero out entries",
                      labelpad=9, fontname="Cambria", fontsize=18)
        ax.set_ylabel(f"# of none-zero entries from the {self.distance_map_name} distance map",
                      labelpad=40, rotation="vertical", fontname="Cambria", fontsize=18)
        save_dir = self.args.main_path / self.args.experiment / "DerivativeMaps"
        save_dir.mkdir(exist_ok=True, parents=True)
        plt.savefig(save_dir / f"{savename}.png", bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close(fig)
        plt.cla()

    def plot_auc_heatmap(self, auc_map, meta_unix, title, savename, plot_type):
        """
        auc_map.shape = (N3, self.N1, self.N2)
        """
        fig, (ax1, axcb) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [1, 0.08]}, )
        fig.set_size_inches(21.3, 13.3)
        # fig.set_size_inches(54.1, 33.8 )
        for ii in range(self.N1):
            for jj in range(self.N2):
                diff = (np.amax(auc_map[:, ii, jj]) - np.amin(auc_map[:, ii, jj]))
                auc_map[:, ii, jj] = (auc_map[:, ii, jj] - np.amin(auc_map[:, ii, jj])) / diff
        auc_map[auc_map <= self.auc_threshold] = np.nan
        fig.suptitle(title, fontname='Comic Sans MS', fontsize=18)
        hp = sns.heatmap(
            auc_map.reshape([auc_map.shape[0], -1]),
            # linewidths=.05,
            # linecolor='black',
            # cmap="jet",
            cmap="rocket_r",
            annot=True,
            # cmap="tab20",
            ax=ax1,
            cbar_ax=axcb,
            vmin=0, vmax=1,
            cbar_kws={"shrink": 0.4})

        ylabels = [f"{it[1]}-{it[2]}" for it in meta_unix] if plot_type == "typeI" else meta_unix
        hp.set_yticks(np.arange(.5, len(ylabels) + .5, 1))
        hp.set_yticklabels([it for ii, it in enumerate(ylabels)])
        hp.set_yticklabels(hp.get_ymajorticklabels(), rotation=0, fontsize=8)
        xlabels = [x if "Haralick" not in x else f"{x.split('_')[0]}-Haralick" for x in self.xlabels]

        hp.set_xticks(np.arange(.5, len(xlabels) + .5, 1))
        hp.set_xticklabels([it for ii, it in enumerate(xlabels)])
        hp.set_xticklabels(hp.get_xmajorticklabels(), rotation=90, fontsize=9)
        save_dir = self.args.main_path / self.args.experiment / "DerivativeMaps"
        save_dir.mkdir(exist_ok=True, parents=True)
        plt.savefig(save_dir/f"{savename}.png", bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close(fig)
        plt.cla()

    def load_map(self, plot_type, density, cellline):
        if plot_type == "typeI":
            filename = f"density={density}_" \
                       f"cellline={cellline}_" \
                       f"{self.distance_map_index}_" \
                       f"{self.distance_map_name}"
            if (self.args.distancemaps_path / f"{filename}.csv").is_file():
                distancemap = pd.read_csv(self.args.distancemaps_path/f"{filename}.csv")
            else:
                return None
        elif plot_type == "typeII":
            assert density is None and cellline is None
            filename = f"DMSO_" \
                       f"{self.args.anchor_cellline}_" \
                       f"{self.args.experiment}_" \
                       f"{self.distance_map_index}_" \
                       f"{self.distance_map_name}"
            if (self.args.distancemaps_path/f"{filename}.csv").is_file():
                distancemap = pd.read_csv(self.args.distancemaps_path/f"{filename}.csv")
            else:
                return None
        else:
            raise ValueError(f"{plot_type} not acceptable!!!")
        return distancemap

    def is_exp_dose_respose(self, meta_unix):
        """
        meta_unix is an (N, 3) numpy array where
        each row represents the summary data for a well/well-id,
        column 0 represents experiment id
        column 1 represents treatment name
        column 2 represents dosage
        """
        # print(np.unique(meta_unix[:, 1]), np.unique(meta_unix[:, 2]))
        treatments = np.setdiff1d(np.unique(meta_unix[:, 1]), "dmso")
        dosages = np.unique(meta_unix[meta_unix[:, 1] != "dmso", 2])
        tmp = np.unique(meta_unix[meta_unix[:, 1] == treatments[0], 2])
        is_drc = True if len(tmp) > 1 else False
        # print(is_drc)
        return is_drc, treatments, dosages

    def partI_get_graphs(self):
        # TODO: Change map_name as well
        meta_cols = ["exp-id", "treatment", "dosage"]
        pairs = get_df_unix(self.args.platemap, ["density", "cell-line"])
        for ii, (den, cl) in enumerate(pairs):
            print(ii, den, cl)
            title = f"{self.args.experiment}\ncase{ii}-Density={den} Cell-line={cl}"
            distancemap = self.load_map("typeI", den, cl)
            if distancemap is None:
                return
            meta_unix = np.array(get_df_unix(distancemap, meta_cols), dtype=object)
            print(meta_unix.shape)
            print(meta_unix)
            deriv_map, auc_map = self.compute_derivative_maps(distancemap, meta_cols, meta_unix)
            min_ = np.amin(deriv_map, axis=(3, 4), keepdims=False)
            max_ = np.amax(deriv_map, axis=(3, 4), keepdims=False)

            is_drc, treatment, dosages = self.is_exp_dose_respose(meta_unix)
            # print(type(meta_unix), meta_unix.shape, distancemap.shape, deriv_map.shape, auc_map.shape, is_drc)
            if is_drc:
                for jj, ds in enumerate(dosages):
                    print(ds)
                    cond = (meta_unix[:, 2] == ds) | (meta_unix[:, 1] == "dmso")
                    colors = self.get_colors(meta_unix[cond, :], "typeI")
                    for idx in [0, 1]:
                        title0 = f"l{idx}-Norm Derivative Map\nDose={ds}\n{title}"
                        savename0 = f"Deriv-Plot-l{idx}Norm-case{ii}-{jj}-" \
                                    f"Density={den}-Cellline={cl}-" \
                                    f"Dose={ds}"
                        self.plot_deriv_curves(
                            deriv_map[idx, :, :, cond, :].transpose((1, 2, 0, 3)),
                            min_[idx], max_[idx],
                            meta_unix[cond, :],
                            colors,
                            title0,
                            savename0,
                            plot_type="typeI")
            else:

                for idx in [0, 1]:
                    colors = self.get_colors(meta_unix, "typeI")
                    title0 = f"l{idx}-Norm Derivative Map\n{title}"
                    savename0 = f"Deriv-Plot-l{idx}Norm-case{ii}-" \
                                f"Density={den}-Cellline={cl}"
                    self.plot_deriv_curves(
                        deriv_map[idx, :, :, :, :],
                        min_[idx], max_[idx],
                        meta_unix[:, :],
                        colors, title0, savename0,
                        plot_type="typeI")
            savename1 = f"AUC-Heatmap-l1-Norm-case{ii}-Density={den}-Cellline={cl}"
            title1 = f"AUC Heatmap of l1-Norm Derivative:\n{title}"
            self.plot_auc_heatmap(auc_map[1], meta_unix, title1, savename1, plot_type="typeI")

    def partII_get_graphs(self):
        # TODO: Change map_name as well
        meta_cols = ["cell-line"]
        distancemap = self.load_map(plot_type="typeII", density=None, cellline=None)
        if distancemap is None:
            return
        meta_unix = np.array(get_df_unix(distancemap, meta_cols), dtype=object)
        deriv_map, auc_map = self.compute_derivative_maps(distancemap, meta_cols, meta_unix)
        min_ = np.amin(deriv_map, axis=(3, 4), keepdims=False)
        max_ = np.amax(deriv_map, axis=(3, 4), keepdims=False)

        colors = self.get_colors(meta_unix, "typeII")
        title = f"{self.args.experiment}: DMSO Comparison across Cell-lines"

        for idx in [0, 1]:
            title0 = f"l{idx}-Norm Derivative Map\n{title}"
            savename0 = f"DMSO-Derivative-Plot-l{idx}Norm"
            self.plot_deriv_curves(deriv_map[idx], min_[idx], max_[idx], meta_unix, colors, title0, savename0,
                                   plot_type="typeII")

        title1 = f"DMSO-AUC Heatmap of l{idx}-Norm Derivative:\n{title}"
        savename1 = f"DMSO-AUC-Heatmap-l1-Norm"
        self.plot_auc_heatmap(auc_map[1], meta_unix, title1, savename1, plot_type="typeII")

    def compute_derivative_maps(self, distancemap, meta_cols, meta_unix):
        N3 = len(meta_unix)
        derivative_map = np.zeros((self.num_maps, self.N1, self.N2, N3, self.M), dtype=np.float32)
        auc_map = np.zeros((self.num_maps, N3, self.N1, self.N2), dtype=np.float32)
        for ii, it1 in enumerate(self.channels):
            for jj, it2 in enumerate(self.feature_types):
                feat_cols = [cc for cc in distancemap.columns if it1 in cc and it2 in cc]
                # print(feat_cols)
                if len(feat_cols) == 0:
                    continue
                for kk in range(N3):  # restrict to a specific (exp-id, treatment, dosage) triplet
                    vals = meta_unix[kk] if isinstance(meta_unix[kk], np.ndarray) else \
                    np.array([meta_unix[kk]], dtype=object)
                    tmp = distancemap.loc[
                        get_df_at_cond(distancemap, meta_cols, vals),
                        feat_cols].values
                    if len(tmp) == 0:
                        continue
                    for ll, it4 in enumerate(self.thresholds):
                        tmp1 = tmp.copy()
                        tmp1[(-it4 <= tmp) & (tmp <= it4)] = 0
                        derivative_map[0, ii, jj, kk, ll] = np.sum((tmp1 != 0))/tmp1.size
                        derivative_map[1, ii, jj, kk, ll] = np.sum(np.abs(tmp1))/tmp1.shape[0]
                        # np.sum(np.abs(np.abs(tmp1)-np.abs(tmp)))/tmp1.shape[0]
                    auc_map[0, kk, ii, jj] = simpson(derivative_map[0, ii, jj, kk, :], dx=1)
                    auc_map[1, kk, ii, jj] = simpson(derivative_map[1, ii, jj, kk, :], dx=1)
                    # auc_map[kk, ii, jj] = simpson(derivative_map[1, ii, jj, kk, :], dx=1)
                    # print(kk, ii, jj, auc_map[0, kk, ii, jj], auc_map[1, kk, ii, jj])
        print('\n')
        return derivative_map, auc_map

    def get_colors(self, meta_unix, plot_type):
        # TODO: Choose better colormaps
        N1 = len(meta_unix)
        if N1 <= 8:
            colors = ["red", "green", "blue", "orange", "purple", "pink", "yellow", "gray"]
        else:
            M1 = int(N1/4)
            c1 = list(plt.cm.rainbow(np.linspace(.1, .5, M1)))
            c2 = list(plt.cm.magma(np.linspace(.5, 1, M1)))
            c3 = list(plt.cm.viridis(np.linspace(0, .4, M1)))
            c4 = list(plt.cm.inferno(np.linspace(.4, 1, N1-3*M1)))
            colors = c1+c2+c3+c4
            print("colors: ", len(colors))
            # random.shuffle(colors)

        # unix = list(np.unique(list(zip(*meta_unix))[1]))
        # print(meta_unix, unix)
        if plot_type == "typeI":
            unix = list(np.unique(meta_unix[:, 1]))
            colors[unix.index(self.args.anchor_treatment)] = "black"
        elif plot_type == "typeII":
            unix = list(np.unique(meta_unix[:, ]))
            colors[unix.index(self.args.anchor_cellline)] = "black"
        else:
            raise ValueError(f"{plot_type} not acceptable!!!")
        # print("# unix", N1)
        return colors

    def compare_direvative_maps(self, ):
        thresholds = np.linspace(0, 1, 50)
        diffs = np.zeros((3, self.M), dtype=np.float32)
        zeros = np.zeros((3, self.M), dtype=np.float32)
        for ii, it in enumerate(self.maps):
            distancemap = pd.read_csv(self.args.distancemaps_path /
                                  f"density={self.density}_cellline={self.cell_line}_{it}.csv")
            distancemap = distancemap[distancemap.columns[8:]].values
            for jj in range(len(thresholds) - 1):
                it1, it2 = thresholds[jj], thresholds[jj + 1]
                m1, m2 = distancemap.copy(), distancemap.copy()
                m1[(-it1 <= distancemap) & (distancemap <= it1)] = 0
                m2[(-it2 <= distancemap) & (distancemap <= it2)] = 0
                diffs[ii, jj] = np.sum((m2 - m1) ** 2)
                zeros[ii, jj] = np.sum((m1 == 0))

        fig, axes = plt.subplots(1, 2)
        for ii, it in enumerate(self.maps):
            axes[0].plot(thresholds[:-1], diffs[ii, :-1], label=it)
            axes[1].plot(thresholds[:-1], zeros[ii, :-1], label=it)
        plt.legend()
        plt.show()


def main():
    for experiment in [
        # "20220831-CP-Fabio-DRC-BM-R01",
        # "20220908-CP-Fabio-DRC-BM-R02",

        # "20221102-CP-Fabio-DRC-BM-P01",
        # "20221102-CP-Fabio-DRC-BM-P02",

        # "20221109-CP-Fabio-DRC-BM-P01",
        # "20221109-CP-Fabio-DRC-BM-P02",

        # "20221116-CP-Fabio-DRC-BM-P01",
        # "20221116-CP-Fabio-DRC-BM-P02",


        # "20220920-CP-Bolt-Seema",
        # "20220930-CP-Bolt-Seema",
        "20221021-CP-Bolt-Seema",

        # "20220912-CP-Bolt-MCF7",
        # "20220929-CP-Bolt-MCF7",
        # "20221024-CP-Bolt-MCF7",

        # "20221207-CP-CCandler-Exp2244-1",
        # "20221208-CP-CCandler-Exp2244-2",


    ]:
        args = CellPaintArgs(
            experiment=experiment,
            mode="full",
        ).args
        get_df_unix(args.platemap, ["density", "cell-line"])

        mymap = DerivativeMaps(args)
        mymap.partI_get_graphs()
        mymap.partII_get_graphs()


if __name__ == "__main__":
    # import matplotlib.font_manager
    # fpaths = matplotlib.font_manager.findSystemFonts()
    # for i in fpaths:
    #     f = matplotlib.font_manager.get_font(i)
    #     print(f.family_name)

    main()
