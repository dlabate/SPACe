import sys
from typing import Optional

import numpy as np
import torch
import torch.nn as nn


def get_tensor_size(mytensor, units="gb"):
    if units.lower() == "gb":
        divisor = 1024 * 1024 * 1024
    elif units.lower() == "mb":
        divisor = 1024 * 1024
    elif units.lower() == "kb":
        divisor = 1024
    else:
        raise ValueError("Not acceptable")
    return sys.getsizeof(mytensor.storage()) / divisor


def skewness(x, dim=1):
    """
    Taken from https://github.com/ExamDay/InfoTorch/blob/main/infotorch.py

    x is a 2d tensor of shape (num_features, num_cells),
    and we would like to average over the cell population
    to get a separate stats over each single feature column

    Calculates skewness of data "x" along dimension "dim"."""
    std, mean = torch.std_mean(x, dim)
    n = torch.Tensor([x.shape[dim]]).to(x.device)
    eps = 1e-6  # for stability

    sample_bias_adjustment = torch.sqrt(n * (n - 1)) / (n - 2)
    return sample_bias_adjustment * (
        (torch.sum((x.T - mean.unsqueeze(dim).T).T.pow(3), dim) / n)
        / std.pow(3).clamp(min=eps))


def kurtosis(x, dim=1):
    """
    Taken from https://github.com/ExamDay/InfoTorch/blob/main/infotorch.py

    x is a 2d tensor of shape (num_features, num_cells),
    and we would like to average over the cell population
    to get a separate stats over each single feature column

    Calculates kurtosis of data "x" along dimension "dim".
    """
    std, mean = torch.std_mean(x, dim)
    n = torch.Tensor([x.shape[dim]]).to(x.device)
    eps = 1e-6  # for stability

    sample_bias_adjustment = (n - 1) / ((n - 2) * (n - 3))
    return sample_bias_adjustment * (
        (n + 1)
        * (
            (torch.sum((x.T - mean.unsqueeze(dim).T).T.pow(4), dim) / n)
            / std.pow(4).clamp(min=eps)
        )
        - 3 * (n - 1))


def skewness_measures(x, dim=1):
    """
    Taken from https://github.com/ExamDay/InfoTorch/blob/main/infotorch.py

    x is a 2d tensor of shape (num_features, num_cells),
    and we would like to average over the cell population
    to get a separate stats over each single feature column


    Used to detect bimodality (or multimodality) of dataset(s) given a tensor "x" containing the
    data and a dimension "dim" along which to calculate.  The logic behind this index is that a
    bimodal (or multimodal) distribution with light tails will have very low kurtosis, an asymmetric
    character, or both – all of which increase this index.  The smaller this value is the more
    likely the data are to follow a unimodal distribution.  As a rule: if return value ≤ 0.555
    (bimodal index for uniform distribution), the data are considered to follow a unimodal
    distribution. Otherwise, they follow a bimodal or multimodal distribution.
    """
    eps = 1e-6  # for stability

    # # convert x to a probability vector
    # sum_ = torch.unsqueeze(torch.sum(x, dim), dim=1)
    # # print(x.shape, sum_.shape)
    # x = x/(sum_+eps*torch.sign(sum_))

    # calculate standard deviation and mean of dataset(s)
    std, mean = torch.std_mean(x, dim)
    # get number of samples in dataset(s)
    n = torch.Tensor([x.shape[dim]]).to(x.device)

    # calculate skewness:
    # repeating most of the skewness function here to avoid recomputation of standard devation and mean
    sample_bias_adjustment = torch.sqrt(n * (n - 1)) / (n - 2)
    skew = sample_bias_adjustment * ((torch.sum((x.T - mean.unsqueeze(dim).T).T.pow(3), dim) / n)/
                                     std.pow(3).clamp(min=eps))
    # calculate kurtosis:
    sample_bias_adjustment = (n - 1) / ((n - 2) * (n - 3))
    kurt = sample_bias_adjustment * (
        (n + 1) * ((torch.sum((x.T - mean.unsqueeze(dim).T).T.pow(4), dim) / n) / std.pow(4).clamp(min=eps))
        - 3 * (n - 1))
    # calculate bimodality index:
    bi_index = (skew.pow(2) + 1) / (kurt + 3 * ((n - 2).pow(2) / ((n - 2) * (n - 3))))

    return bi_index


def get_cdfs(u_values, v_values):
    """
    Put the two sets of values in the same basket/scale so that they have the same length.

    Adapted from https://github.com/scipy/scipy/blob/v1.9.3/scipy/stats/_stats_py.py#L8675-L8749
    pytorch implementation of the wassertein distance between two distributions.

    u_values: MxN1 tensor
    where M is the number of columns/features and N1 is the number of rows/cells

    v_values: MxN2 anchor tensor where
    M is the number of columns/features and N2 is the number of rows/cells in the
    anchor condition
    """
    all_values = torch.cat((u_values, v_values), dim=1)
    all_values, _ = torch.sort(all_values, dim=1)

    u_sorted, _ = torch.sort(u_values, dim=1)
    v_sorted, _ = torch.sort(v_values, dim=1)

    # Compute the differences between pairs of successive values of u and v.
    deltas = torch.diff(all_values, dim=1)
    # Get the respective positions of the values of u and v among the values of
    # both distributions.
    # all_values = all_values[:, :-1].contiguous()
    u_cdf_indices = torch.searchsorted(u_sorted, all_values[:, :-1], right=True)
    v_cdf_indices = torch.searchsorted(v_sorted, all_values[:, :-1], right=True)
    # Calculate the CDFs of u and v using their weights, if specified.
    u_cdf = u_cdf_indices / u_values.size(1)
    v_cdf = v_cdf_indices / v_values.size(1)
    return u_cdf, v_cdf, deltas


def wassertein_distance_2d(u_values, v_values):
    """
    Adapted from https://github.com/scipy/scipy/blob/v1.9.3/scipy/stats/_stats_py.py#L8675-L8749
    pytorch implementation of the wassertein distance between two distributions.

    u_values: MxN1 tensor
    where M is the number of columns/features and N1 is the number of rows/cells

    v_values: MxN2 anchor tensor where
    M is the number of columns/features and N2 is the number of rows/cells in the
    anchor condition
    """
    u_cdf, v_cdf, deltas = get_cdfs(u_values, v_values)

    # Compute the value of the integral based on the CDFs.
    # If p = 1 or p = 2, we avoid using np.power, which introduces an overhead
    # of about 15%.
    return torch.sum(torch.mul(torch.abs(u_cdf - v_cdf), deltas), dim=1)


def alpha_geodesic(
    a: torch.Tensor,
    b: torch.Tensor,
    alpha: float,
    lmd: float
) -> torch.Tensor:
    r"""
    Taken from the official implementation of "α-Geodesical Skew Divergence".
    https://github.com/nocotan/geodesical_skew_divergence/blob/main/gs_divergence/geodesical_skew_divergence.py
    $\alpha$-geodesic between two probability distributions
    """

    a_ = a + 1e-12
    b_ = b + 1e-12
    if alpha == 1:
        return torch.exp((1 - lmd) * torch.log(a_) + lmd * torch.log(b_))
    elif alpha >= 1e+9:
        return torch.min(a_, b_)
    elif alpha <= -1e+9:
        return torch.max(a_, b_)
    else:
        p = (1 - alpha) / 2
        lhs = a_ ** p
        rhs = b_ ** p
        g = ((1 - lmd) * lhs + lmd * rhs) ** (1/p)

        if alpha > 0 and (g == 0).sum() > 0:
            return torch.min(a_, b_)

        return g


class GSDivLoss(nn.Module):
    r"""
    Taken from the official implementation of "α-Geodesical Skew Divergence":
    https://github.com/nocotan/geodesical_skew_divergence/blob/main/gs_divergence/geodesical_skew_divergence.py


    The alpha-geodesical skew divergence loss measure
    `alpha-geodesical skew divergence`_ is a useful distance measure for continuous
    distributions and is approximation of the 'Kullback-Leibler divergence`.
    This criterion expects a `target` `Tensor` of the same size as the
    `input` `Tensor`.
    """
    def __init__(
        self,
        alpha: float = -1,
        lmd: float = 0.5,
        dim: int = 0,
        reduction: Optional[str] = 'sum') -> None:

        self.alpha = alpha
        self.lmd = lmd
        self.reduction = reduction

    def forward(
        self,
        input: torch.Tensor,
        target: torch.Tensor) -> torch.Tensor:

        return gs_div(input, target, self.alpha, self.lmd, self.dim, self.reduction)


def gs_div(
    input: torch.Tensor,
    target: torch.Tensor,
    alpha: float = -1,
    lmd: float = 0.5,
    dim: int = 0,
    reduction: Optional[str] = 'sum',
) -> torch.Tensor:
    r"""
    Taken from the official implementation of "α-Geodesical Skew Divergence":
    https://github.com/nocotan/geodesical_skew_divergence/blob/main/gs_divergence/geodesical_skew_divergence.py


    The $\alpha$-geodesical skew divergence.
    Args:
        input: Tensor of arbitrary shape
        target: Tensor of the same shape as input
        alpha: Specifies the coordinate systems which equiped the geodesical skew divergence
        lmd: Specifies the position on the geodesic
        reduction (string, optional): Specifies the reduction to apply to the output:
            ``'none'`` | ``'batchmean'`` | ``'sum'`` | ``'mean'``.
            ``'none'``: no reduction will be applied
            ``'batchmean``': the sum of the output will be divided by the batchsize
            ``'sum'``: the output will be summed
            ``'mean'``: the output will be divided by the number of elements in the output
            Default: ``'sum'``
    """

    assert lmd >= 0 and lmd <= 1

    skew_target = alpha_geodesic(input, target, alpha=alpha, lmd=lmd)
    div = input * torch.log(input / skew_target + 1e-12)
    if reduction == 'batchmean':
        div = torch.sum(div, dim=dim) / input.size()[0]
    elif reduction == 'sum':
        div = torch.sum(div, dim=dim)
    elif reduction == 'mean':
        div = torch.mean(div, dim=dim)

    return div


def apply_along_axis(function, x, axis):
    """https://discuss.pytorch.org/t/apply-a-function-along-an-axis/130440"""
    # print("x in apply_along_...: ", x.device)
    return torch.stack([function(x_i) for x_i in torch.unbind(x, dim=axis)], dim=axis)


def get_densities(xs, bins=25, device="cuda:0"):
    """get the probability density function of xs,
    Let's figure out whether to use samples from probability density or
     probability vectors later.


    """
    # TODO: Fix the device parameter
    # Like torch.histogram, but works with cuda
    min, max = xs.min(), xs.max()
    counts = torch.histc(xs, bins=bins, min=min, max=max)
    # boundaries = torch.linspace(min, max, bins+1).to(device)
    # hist = counts/torch.diff(boundaries)/torch.sum(counts)
    # return counts/torch.diff(boundaries)/torch.sum(counts)
    # hist_np, bin_edges = np.histogram(xs.cpu().numpy(), bins=bins, density=True)
    # print(torch.sum(hist), np.sum(hist_np), np.sum(hist_np*np.diff(bin_edges)))

    # counts = torch.histc(xs, bins=25, min=-1, max=1)
    return counts / torch.sum(counts)


def alpha_geodesical_divergence_symmetric(first, second, alpha=-1, lmd=0.5):
    r"""
    adapted from the official implementation of "α-Geodesical Skew Divergence":
    https://github.com/nocotan/geodesical_skew_divergence/blob/main/gs_divergence/geodesical_skew_divergence.py
    https://github.com/scipy/scipy/blob/v1.9.3/scipy/stats/_stats_py.py#L8675-L8749

    The $\alpha$-geodesical skew divergence.
    Args:
        first: Tensor of arbitrary shape (M, N) where M is the number of features, and N is the number of datapoints
        second: Tensor of the same shape as first
        alpha: Specifies the coordinate systems which equiped the geodesical skew divergence
        lmd: Specifies the position on the geodesic
    """
    assert lmd >= 0 and lmd <= 1
    first_density = apply_along_axis(lambda x: get_densities(x), first, axis=0)
    second_density = apply_along_axis(lambda x: get_densities(x), second, axis=0)

    # first_density = torch.histogramdd(first, bins=20, density=True)[0]
    # second_density = torch.histogramdd(second, bins=20, density=True)[0]
    # print(first_density.shape, second_density.shape)
    skew_first_density = alpha_geodesic(second_density, first_density, alpha=alpha, lmd=lmd)
    skew_second_density = alpha_geodesic(first_density, second_density, alpha=alpha, lmd=lmd)
    div = .5 * torch.abs(first_density * torch.log(first_density / skew_second_density + 1e-12)) + \
          .5 * torch.abs(second_density * torch.log(second_density / skew_first_density + 1e-12))
    div = torch.mean(div, dim=1)
    # div *= torch.log(div + 1e-12)
    return div
