import numpy as np
from PIL import Image
import tifffile
import matplotlib.pyplot as plt
from cellpaint.utils.helpers import move_figure, get_overlay
from skimage.exposure import rescale_intensity

csfont = {'fontname': 'Comic Sans MS', 'fontsize': 18}

colors = ["red", "green", "blue", "orange", "purple", "lightgreen", "yellow", "pink",
          "khaki", "lime", "olivedrab", "azure", "orchid",
          "peru", "tan"]
img_path = r"F:\CellPainting\20220908-CP-Fabio-DRC-BM-R02\AssayPlate_PerkinElmer_CellCarrier-384"
mask_path = r"F:\CellPainting\20220908-CP-Fabio-DRC-BM-R02\MasksP2"
img_filenames = [
    "AssayPlate_PerkinElmer_CellCarrier-384_E04_T0001F007L01A05Z01C01.tif",
    "AssayPlate_PerkinElmer_CellCarrier-384_E04_T0001F007L01A04Z01C02.tif",
    "AssayPlate_PerkinElmer_CellCarrier-384_E04_T0001F007L01A03Z01C03.tif",
    "AssayPlate_PerkinElmer_CellCarrier-384_E04_T0001F007L01A02Z01C04.tif",
    "AssayPlate_PerkinElmer_CellCarrier-384_E04_T0001F007L01A01Z01C05.tif",
]
mask_filenames = [f"w{ii}_E04_F007.png" for ii in [0, 1, 2, 4]]


w0_mask = np.array(Image.open(f"{mask_path}/{mask_filenames[0]}"))


def find_object_point(_pi, _regions, _array,_max_label, _ii):
    _rank = np.ndim(_array)
    _sindex =_pi - 1
    if 0 <= _sindex < _max_label:
        if _rank > 0:
            _sindex *= 2 * _rank
            if _regions[_sindex] < 0:
                for _kk in range(0, _rank):
                    _cc = _ii.coordinates[_kk]
                    _regions[_sindex + _kk] = _cc
                    _regions[_sindex + _kk + _rank] = _cc + 1
            else:
                for _kk in range(0, _rank):
                    _cc = _ii.coordinates[_kk]
                    if _cc < _regions[_sindex + _kk]:
                        _regions[_sindex + _kk] = _cc
                    if _cc + 1 > _regions[_sindex + _kk + _rank]:
                        _regions[_sindex + _kk + _rank] = _cc + 1
        else:
            _regions[_sindex] = 1


def my_find_objects(mask):
    max_label = np.amax(mask)
    # / *get input data, size and iterator: * /
    pi = 0
    size = np.size(mask)
    ndim = np.ndim(mask)
    for jj in range(0, 2 * ndim * max_label):
        regions[jj] = -1

    # / *iterate over all points: * /
    for jj in range(0, size):
        find_object_point(pi, regions, mask, max_label, ii)