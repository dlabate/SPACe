import argparse
import warnings
from sys import platform
from typing import Union
from pathlib import WindowsPath, PosixPath, Path

import math
import numbers
import numpy as np
import pandas as pd
from tifffile import imread


class CellPaintArgs():
    """
    creates an args namespace that takes in all the constants necessary to perform the cell-paint analysis
    """
    # TODO: remove dependency on the OS for pathlib path objects.
    def __init__(
            self,
            experiment,
            main_path=r"F:\CellPainting",  # r"E:\\tmp\\pankaj"
            mode="test",
            filter_dark_cells=True,
            remove_outer_wells=False,
            cellline_excluded_in_celllines_comparison=None,

    ):
        """
        experiment:
            The name of the experiment folder to perform cellpaint analysis on

        main_path:
            The name of the mother folder where the experiment data (images and platemap) are located

        filter_dark_cells:
            whether or not to filter the nuclei with mean_intensity less than a pre-specified threshold
            before starting to calculate/create the distance-maps in step 4.

        remove_outer_wells:
            whether or not to remove outer_wells (wells around the 4 edges of the platemap)
            before starting to calculate/create the distance-maps in step 4.

        mode:
            whether to run the analysis steps (.py files) in debug mode, test mode,
            or full mode.
            args.mode=test or args.mode=ful should be used when the code is already debugged
            and we can use the multiproccessing pool during segmentation/step2
             and feature extraction/step3 for speed up
        """

        # for all the steps
        self.args = self.init_namespace()
        self.args = self.add_path_object(self.args)

        self.args.main_path = self.args.path_object(main_path) if isinstance(main_path, str) else main_path
        self.args.experiment = self.args.path_object(experiment) if isinstance(main_path, str) else main_path
        self.args.mode = mode
        self.args.show_masks = False
        self.args.filter_dark_cells = filter_dark_cells
        self.args.remove_outer_wells = remove_outer_wells

        self.args = self.add_experiment_args(self.args)
        self.args = self.add_save_path_args(self.args)
        # for Step 3) feature extraction
        self.args = self.add_platemap_args(self.args)
        self.args = self.add_feature_args(self.args)
        # for Step 4) Distance-map calculation
        self.args = self.add_platemap_anchor_args(self.args)

        self.args = self.add_other_args(self.args)
        self.args.num_debug_images = 3
        self.args.cellline2exclude = cellline_excluded_in_celllines_comparison

    @staticmethod
    def add_path_object(args):
        # linux or mac machine
        if platform == "linux" or platform == "darwin":
            args.path_object = PosixPath

        elif platform == "win32":
            args.path_object = WindowsPath
        return args

    @staticmethod
    def init_namespace():
        parser = argparse.ArgumentParser(description='Cell-paint')
        # the order of the channel for images taken by fabio at baylor is as follows:
        # w1: Nucleus channel, w2: cyto channel, w3: nucleoli channel, w4: actin channel, w5: mito channel
        parser.add_argument("--min_cell_count", type=int, default=5,
                            help="minimum # of segmented cells to not skip image")
        parser.add_argument("--nucleus_idx", type=int, default=0,
                            help="Nucleus channel index in the tif image(~w1)")
        parser.add_argument("--cyto_idx", type=int, default=1, help="Cyto channel index in the tif image(~w2)")
        parser.add_argument("--nucleoli_idx", type=int, default=2,
                            help="Nucleoli channel index in the tif image(~w3)")
        parser.add_argument("--actin_idx", type=int, default=3, help="Actin channel index in the tif image(~w4)")
        parser.add_argument("--mito_idx", type=int, default=4, help="Mito channel index in the tif image(~w5)")
        parser.add_argument("--name_cut_off_index", type=int, default=8,
                            help="treatment name cut-off index when treatment name is too long!")
        args = parser.parse_args()
        return args

    @staticmethod
    def add_experiment_args(args):
        args.img_folder = list(filter(
            lambda x: "AssayPlate" in str(x),
            (args.main_path / args.experiment).iterdir()))[0].stem
        args.plate_protocol = args.img_folder.split("_")[1].lower()
        # Get generic width and height dimensions of the image, in the specific experiment.
        # We assume height and width are the same for every single images, in the same experiment!!!
        args.height, args.width = imread(
            list((args.main_path / args.experiment / args.img_folder).rglob(f'{args.img_folder}_*.tif'))[0]).shape
        args.channel_dies = {
            "C1": "DAPI",  # nucleus
            "C2": "Concanavalin A",  # cyto
            "C3": "Syto14",  # nucleoli
            "C4": "WGA+Phalloidin",  # actin
            "C5": "MitoTracker",  # mito
        }
        return args

    @staticmethod
    def add_save_path_args(args):
        """Create a saving folder for the results obtained at each step of the Cellpaint process."""
        if args.mode.lower() == "debug":
            # args.analysis_save_path = args.main_path / args.experiment / "Debug"
            args.analysis_save_path = args.main_path / args.experiment
        elif args.mode.lower() == "test":
            args.analysis_save_path = args.main_path / args.experiment / "Test"
        elif args.mode.lower() == "full":
            args.analysis_save_path = args.main_path / args.experiment
        else:
            raise ValueError("""args.mode value is not acceptable!!! Use one of the following:
            debug \n
            test \n
            full 
            """)
        # define save folders
        args.masks_path_p1 = args.analysis_save_path / "MasksP1"
        args.masks_path_p2 = args.analysis_save_path / "MasksP2"
        args.features_path = args.analysis_save_path / "Features"
        args.distancemaps_path = args.analysis_save_path / "DistanceMaps"
        args.heatmaps_path = args.analysis_save_path / "HeatMaps"
        args.derivativemaps_path = args.analysis_save_path / "DerivativeMaps"

        # create the save folders if they do not already exist
        args.masks_path_p1.mkdir(exist_ok=True, parents=True)
        args.masks_path_p2.mkdir(exist_ok=True, parents=True)
        args.features_path.mkdir(exist_ok=True, parents=True)
        args.distancemaps_path.mkdir(exist_ok=True, parents=True)
        args.heatmaps_path.mkdir(exist_ok=True, parents=True)
        args.derivativemaps_path.mkdir(exist_ok=True, parents=True)
        return args

    def add_platemap_args(self, args):
        """
        This step is a must for the analysis to work.
        It extracts all the necessary metadata args from all the sheets of the platemap excel file, except the last one.
        """
        if args.experiment in ["2021-CP007",
                               "2021-CP008",
                               "20220607-CP-Fabio-U2OS-density-10x",
                               "20220623-CP-Fabio-Seema-Transfected",
                               "20220810-CP-Fabio-WGA-Restain",
                               "others"]:
            raise ValueError("Experiment not implemented or is in discard pile!")

        args.wellid2treatment = self.get_wellid2meta(args, sheetname="Treatment")
        args.wellid2cellline = self.get_wellid2meta(args, sheetname="CellLine")
        args.wellid2dosage = self.get_wellid2meta(args, sheetname="Dosage")
        args.wellid2density = self.get_wellid2meta(args, sheetname="Density")
        args.wellid2other = self.get_wellid2meta(args, sheetname="Other")

        args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
        args.treatments = list(np.unique(list(args.wellid2treatment.values())))
        args.celllines = list(np.unique(list(args.wellid2cellline.values())))

        if args.wellid2dosage is None:
            args.wellid2dosage = {key: 0 for key in args.wellid2treatment.keys()}
            args.dosages = [0]
        else:
            args.dosages = list(np.unique(list(args.wellid2dosage.values())))

        if args.wellid2density is None:
            args.wellid2density = {key: 0 for key in args.wellid2treatment.keys()}
            args.densities = [0]
        else:
            args.densities = list(np.unique(list(args.wellid2density.values())))

        if args.wellid2other is None:
            args.wellid2other = {key: 0 for key in args.wellid2treatment.keys()}
            args.other = [0]
        else:
            args.other = list(np.unique(list(args.wellid2other.values())))

        print("treatments: ", args.treatments)
        print("cell-lines: ", args.celllines)
        print("densities: ", args.densities)
        print("dosages: ", args.dosages)

        N = len(self.args.wellids)
        args.platemap = np.zeros((N, 6), dtype=object)
        for ii in range(N):
            args.platemap[ii, 0] = self.args.wellids[ii]
            args.platemap[ii, 1] = self.args.wellid2treatment[self.args.wellids[ii]]
            args.platemap[ii, 2] = self.args.wellid2cellline[self.args.wellids[ii]]
            args.platemap[ii, 3] = self.args.wellid2density[self.args.wellids[ii]]
            args.platemap[ii, 4] = self.args.wellid2dosage[self.args.wellids[ii]]
            args.platemap[ii, 5] = self.args.wellid2other[self.args.wellids[ii]]
        args.platemap = pd.DataFrame(
            args.platemap,
            columns=["well-id", "treatment", "cell-line", "density", "dosage", "other"])
        return args

    def add_platemap_anchor_args(self, args):
        """This step is necessary to automate step IV of the cellpaint Analysis"""
        # anchors
        platemap_filepath = list((args.main_path / args.experiment).rglob("platemap-*.xlsx"))[0]
        meta = pd.read_excel(platemap_filepath, sheet_name="Anchor")
        args.anchor_treatment = meta["Treatment"].values[0]
        args.anchor_cellline = meta["CellLine"].values[0]
        args.anchor_density = meta["Density"].values[0]
        args.anchor_dosage = meta["Dosage"].values[0]
        args.anchor_other = meta["Other"].values[0]

        # fix the entries of the 5 columns in the "Anchor" sheet
        if args.anchor_treatment == np.nan:
            raise ValueError("args.anchor_treatment value cannot be Nan. Please specify a value for it.")
        elif args.anchor_treatment.lower() != "dmso":
            warnings.warn("args.anchor_treatment is not set to DMSO. If it is set correctly, ignore this warning!")
        assert isinstance(args.anchor_treatment, str), "Anchor treatment must be a string!"
        args.anchor_treatment = args.anchor_treatment.lower()
        args.anchor_cellline = self.fix_anchor_val(args.anchor_cellline, "CellLine")
        args.anchor_density = self.fix_anchor_val(args.anchor_density, "Density")
        args.anchor_dosage = self.fix_anchor_val(args.anchor_dosage, "Dosage")
        args.anchor_other = self.fix_anchor_val(args.anchor_other, "Other")
        print(
            f"anchor treatment: {args.anchor_treatment}\n"
            f"anchor cell-line: {args.anchor_cellline}\n"
            f"anchor density: {args.anchor_density}\n"
            f"anchor dosage: {args.anchor_dosage}\n"
            f"anchor other: {args.anchor_other}\n")

        return args

    @staticmethod
    def add_feature_args(args):
        """
        This step is mainly used in feature extraction/step3 of the cellpaint analysis.

        Create names, with certain rules, for all the extracted features columns, that going to be saved
        to the following csv files in "Features" folder:
        metadata_of_features.csv, misc_features.csv
        w0_features.csv, w1_features.csv, w2_features.csv, w3_features.csv, and w4_features.csv

        Also, we use median and mad statistics to summarize the haralick and moment features.
        This helps shrink the size/width of the feature-heatmap.
        """
        ################################################################################################
        # CSV Files column name
        # metadata_of_features.csv column anme
        args.metadata_cols = ["well-id", "fov", "treatment", "cell-line", "density", "dosage", "other", "has-nucleoli"]
        #############################################################################################
        # feature name compartments in order of appearance in the final heatmap
        args.heatmap_feature_groups = []
        #####################################################################################################
        # misc_feature.csv file column names (misc stands for miscellaneous and is used here because
        # these features do not belong to a specific channel
        args.misc_cols = ["nucleoli-count", "nucleus-area-TO-cyto-area", "mito-area-TO-cyto-area",
                          "nucleoli-area-TO-nucleus-area"]
        args.misc_cols = [f"All_Miscs_{it}" for it in args.misc_cols]
        args.heatmap_feature_groups += ["Miscs"]
        #################################################################################################
        # features used in each w*_features.csv file in order of appearance
        # 0) bounding-box -> feature cols  (These 4 will be removed during distancemap and heatmap creation)
        args.bbox_cols = ["y0", "x0", "y1", "x1"]
        args.bbox_cols = [f"Bbox_{it}" for it in args.bbox_cols]
        # having these bounding-box columns helps going back to the images and putting feature numbers
        # as text over images for explainability. Without them, we do not know which cell resides where in each image.
        ####################################################################################################
        # 1) Shape -> feature cols
        args.shape_cols = \
            ["area", "convex-area", "perimeter", "perimeter-crofton", "eccentricity", "equivalent-diam",
             "extent", "feret-diam-max", "solidity", ]
        args.shape_cols = [f"Shapes_{it}" for it in args.shape_cols]
        args.heatmap_feature_groups += ["Shapes"]
        ###################################################################################################
        # 2) Intensity --> feature cols
        args.intensity_percentiles = [10, 25, 40, 60, 75, 80, 90, 93, 95, 97, 99, 99.9, 99.99]
        args.intensity_cols = [f"{prc}%" for prc in args.intensity_percentiles] + ["median", "mad", "mean", "std"]
        args.intensity_cols = [f"Intensities_{it}" for it in args.intensity_cols]
        args.heatmap_feature_groups += ["Intensities"]
        ###################################################################################################
        # 3) Haralick -> feature cols
        args.haralick_names = ['contrast', 'dissimilarity', 'homogeneity', 'asm', 'correlation']

        # args.intensity_thresh_lb, args.intensity_thresh_ub, args.step = 0, 40000, 500
        # args.intensity_level_thresholds = np.arange(args.intensity_thresh_lb, args.intensity_thresh_ub + 1, args.step)
        args.num_discrete_levels = 8
        a1 = np.iinfo(np.uint16).min
        a2 = np.iinfo(np.uint16).max
        args.intensity_level_thresholds = np.linspace(a1, a2, args.num_discrete_levels)
        # args.thresh_lb, args.thresh_ub = 0, 40000
        # args.intensity_level_thresholds = \
        #     np.concatenate(np.linspace(args.thresh_lb, args.thresh_ub, args.num_discrete_levels-1),
        #                    np.array([np.iinfo(np.uint16).max, ]))
        print(args.intensity_level_thresholds)
        print(len(args.intensity_level_thresholds))
        args.angles = np.array([0, np.pi/2], dtype=np.float32)
        args.angles_name = ["0", "pi/2"]  # TODO: Use symbolic to get string values for np.pi and np.pi/2
        args.stat_summaries = ["median", 'mad']
        args.distances = np.arange(1, 21, 1)
        args.haralick_cols = [
            f"{it1}-{it2}-{it3}"
            for it1 in args.haralick_names
            for it2 in  args.stat_summaries
            for it3 in args.angles_name]
        args.haralick_cols_set1 = [f"Haralicks-Global_{it}" for it in args.haralick_cols]
        args.haralick_cols_set2 = [f"Haralicks-Local_{it}" for it in args.haralick_cols]
        args.heatmap_feature_groups += ["Haralicks-Global"]
        args.heatmap_feature_groups += ["Haralicks-Local"]
        # args.haralick_cols = [
        #     f'{mm}-{ii}-{jj}' for mm in args.haralick_names for jj in args.distances for ii in args.angles_name]
        #################################################################################################
        # 4) Moment feature cols
        args.moment_cols = \
            [f'{mm}-{ii}' for mm in ['local_cent', 'w-local-cent', ] for ii in [0, 1]] + \
            [f"{mm}-{st}" for mm in ["normalized", "w-normalized", "hue", "w-hue"] for st in ["median", "mad"]]
        args.moment_cols = [f"Moments_{it}" for it in args.moment_cols]
        args.heatmap_feature_groups += ["Moments"]
        args.mn_ids = [2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        # args.moment_cols = \
        #     [f'moments_{mm}-{ii}' for mm in ['local_cent', 'w-local-cent', ] for ii in [0, 1]] + \
        #     [f"moments_n-{ii}" for ii in args.mn_ids] + \
        #     [f"moments_w-n-{ii}" for ii in args.mn_ids] + \
        #     [f"moments_hue-{ii}" for ii in range(0, 7)] + \
        #     [f"moments_w-hue-{ii}" for ii in range(0, 7)]
        ##########################################################################################################
        # w*_features.csv columns names
        args.organelles = ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]
        args.feature_cols = args.bbox_cols + \
                            args.shape_cols + \
                            args.intensity_cols + \
                            args.haralick_cols_set1 + \
                            args.haralick_cols_set2 + \
                            args.moment_cols
        args.organelle_cols = [[f"{it1}_{it2}" for it2 in args.feature_cols] for it1 in args.organelles]
        #####################################################################################################
        # These constants help with initializing our zeros-numpy-array/feature-accumulators with current dimensions,
        # inside the self.get_features function as wells as outside of it, when it is called over and over
        # in the self.run_loop function.
        args.num_organelles = len(args.organelles)
        args.num_metadata_cols = len(args.metadata_cols)
        args.num_feat_cols = len(args.feature_cols)
        args.num_misc_cols = len(args.misc_cols)
        # starting feature column index for each column group in w*_feature
        args.n1 = len(args.bbox_cols)
        args.n2 = args.n1 + len(args.shape_cols)
        args.n3 = args.n2 + len(args.intensity_cols)
        args.n4 = args.n3 + len(args.haralick_cols_set1)
        args.n5 = args.n4 + len(args.haralick_cols_set2)
        args.n6 = args.n5 + len(args.moment_cols)
        return args

    @staticmethod
    def add_other_args(args):
        args.colors = [
            "red", "green", "blue", "orange", "purple", "lightgreen", "yellow", "pink",
            # "gray",
            "khaki", "lime", "olivedrab", "azure", "orchid", "darkslategray",
            "peru",
            # "lightgray",
            "tan"]
        args.csfont = {'fontname': 'Comic Sans MS', 'fontsize': 16}
        return args

    def get_wellid2meta(self, args, sheetname):
        platemap_filepath = list((args.main_path / args.experiment).rglob("platemap-*.xlsx"))[0]
        meta = pd.read_excel(platemap_filepath, sheet_name=sheetname)
        meta.index = meta["Unnamed: 0"]
        meta.index.name = "row_id"
        meta.drop(["Unnamed: 0", ], axis=1, inplace=True)
        if meta.isnull().values.all():
            return None
        meta = meta.loc[~np.all(meta.isna(), axis=1), ~np.all(meta.isna(), axis=0)]
        wellid2meta = {}
        for row_id in meta.index:
            for col_id in meta.columns:
                wellid2meta[f"{row_id}{str(col_id).zfill(2)}"] = \
                    self.fix_entry(meta.loc[row_id, col_id], sheetname)
        return wellid2meta

    @staticmethod
    def fix_entry(entry, belongs_to):
        # print("fix_entry", entry)
        if belongs_to == "Dosage":
            assert isinstance(entry, numbers.Number), "Must be int or float"
            return entry
        elif belongs_to == "Density":
            assert isinstance(entry, numbers.Number), "Must be int or float"
            return np.uint64(entry)

        elif belongs_to in ["Treatment", "CellLine", "Other"]:
            assert isinstance(entry, str), "Must be a string"
            entry = entry.lstrip().strip()
            entry = entry.replace(" + ", '+')
            entry = entry.replace(' ', '-').replace('_', '-')
            return entry.lower()

    def fix_anchor_val(self, val, belongs_to):
        return 0 if isinstance(val, numbers.Number) and math.isnan(val) else \
                self.fix_entry(val, belongs_to)



