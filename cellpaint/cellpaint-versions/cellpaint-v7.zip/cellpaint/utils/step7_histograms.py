import torch
import numpy as np
import pandas as pd
from cellpaint.utils.args import CellPaintArgs
from cellpaint.utils.step4_get_distance_maps import DistMapCalc
from cellpaint.utils.torch_functions import wassertein_distance_2d
import matplotlib.pyplot as plt


class HistCellpaint(DistMapCalc):
    """Comparing each Cell-line Across different experiments.
    To See How stable the features are across replicates."""

    def __init__(self,
                 args,
                 ):
        # investigate this bullshit problem later
        # args.anchor_dosage = 0 if np.isin(0, args.anchor_dosage) else 0.01
        # anchor_dosage = np.amin(args.anchor_dosage)
        super().__init__(
            args,
            compare_col="treatment",
            anchor_col="dosage",
            anchor_col_val=args.anchor_dosage, )
        self.columns = [
            "Nucleus_Shapes_area",
            "Nucleus_Shapes_convex-area",
            "Nucleus_Shapes_perimeter"]

    # TODO: figure out a better way to handle more than 1 replicate
    def calculate(self, dmso_wellid, treatment_wellid):
        # feats = self.load_and_preprocess_features(args.experiment)
        # print(f"all_features after combining:  shape={feats.shape}  #cols={len(feats.columns)}")
        # feats = self.normalize_features(feats)
        # feats.fillna(0, inplace=True)
        # feats.drop([it for it in feats.columns if "Haralicks-Global" in it], axis=1, inplace=True)
        # anchor_feats = self.get_anchor_features(feats, args.experiment, self.anchor_col, self.anchor_col_val)
        # anchor_feats = anchor_feats.loc[anchor_feats["well-id"] == dmso_wellid, self.columns]
        # feats = feats.loc[feats["well-id"] == treatment_wellid, self.columns]
        # feats.to_csv("taxol.csv")
        # anchor_feats.to_csv("dmso.csv")

        feats = pd.read_csv("taxol.csv", index_col=0)
        anchor_feats = pd.read_csv("dmso.csv", index_col=0)

        feats = torch.as_tensor(np.float32(feats.T)).contiguous().to("cuda:0")
        anchor_feats = torch.as_tensor(np.float32(anchor_feats.T)).contiguous().to("cuda:0")

        mean_feats = torch.mean(feats, dim=1)
        median_feats = torch.median(feats, dim=1)[0]
        mean_anchor = torch.mean(anchor_feats, dim=1)
        median_anchor = torch.median(anchor_feats, dim=1)[0]

        median_distance = median_feats - median_anchor
        median_sign = torch.sign(median_distance)
        mean_distance = torch.mul(mean_feats - mean_anchor, median_sign)
        wasserstein_distance = torch.mul(wassertein_distance_2d(feats, anchor_feats), median_sign)

        feats = feats.cpu().numpy().T
        anchor_feats = anchor_feats.cpu().numpy().T

        mean_feats = mean_feats.cpu().numpy()
        median_feats = median_feats.cpu().numpy()

        mean_anchor = mean_anchor.cpu().numpy()
        median_anchor = median_anchor.cpu().numpy()

        median_distance = median_distance.cpu().numpy()
        mean_distance = mean_distance.cpu().numpy()
        wasserstein_distance = wasserstein_distance.cpu().numpy()
        print(mean_distance, '\n', wasserstein_distance, '\n', median_distance)

        return feats, anchor_feats, \
               mean_feats, median_feats, mean_anchor, median_anchor,\
               median_distance, mean_distance, wasserstein_distance


def main_worker(args):
    myclass = HistCellpaint(args)
    taxol, dmso, \
    mean_vals, median_vals, mean_anchor, median_anchor,\
    median_distance, mean_distance, wasserstein_distance = \
        myclass.calculate(dmso_wellid="E04", treatment_wellid="I21")

    idx = 2
    fig, ax = plt.subplots(1, 1)
    plt.suptitle(f"Nucleus Perimeter",
                 fontname='Comic Sans MS',
                 fontsize=30)
    # ax.set_xlabel("Normalized Feature Values", fontname='Comic Sans MS', fontsize=25)
    # ax.set_ylabel("Counts", fontname='Comic Sans MS', fontsize=25)
    ax.set_xlim([-1, 1])

    yticks = np.arange(0, 900, 50)
    ax.set_yticks(yticks)
    ax.set_yticklabels(yticks)
    ax.set_yticklabels(ax.get_ymajorticklabels(), fontsize=18)

    xticks = np.arange(-1, 1.01, .25)
    ax.set_xticks(xticks)
    ax.set_xticklabels(xticks)
    ax.set_xticklabels(ax.get_xmajorticklabels(), fontsize=18)

    ax.hist(taxol[:, idx], label="Taxol", color="blue", bins=40, alpha=.2)
    plt.axvline(mean_vals[idx], color='blue', linestyle='solid', linewidth=2)
    plt.axvline(median_vals[idx], color='blue', linestyle='dashed', linewidth=2)

    ax.hist(dmso[:, idx], label="DMSO", color="red", bins=40, alpha=.2)
    plt.axvline(mean_anchor[idx], color='red', linestyle='solid', linewidth=2)
    plt.axvline(median_anchor[idx], color='red', linestyle='dashed', linewidth=2)

    plt.text(.5, 510, f"Dashed: Median, Solid: Mean",
             fontname='Comic Sans MS', fontsize=18, color='blue')
    plt.text(.5, 470, f"Abs Mean Difference = {np.abs(mean_distance[idx]):.3f}",
             fontname='Comic Sans MS', fontsize=18)
    plt.text(.5, 430, f"Abs  Distribution  Difference = {np.abs(wasserstein_distance[idx]):.3f}",
             fontname='Comic Sans MS', fontsize=18, color='orange')
    plt.text(.5, 390, f"Abs Median Difference = {np.abs(median_distance[idx]):.3f}",
             fontname='Comic Sans MS', fontsize=18)

    plt.legend(fontsize=30)
    plt.show()


if __name__ == "__main__":
    experiment = "20220831-CP-Fabio-DRC-BM-R01"
    args = CellPaintArgs(
        experiment=experiment,
        mode="full",
    ).args
    main_worker(args)
