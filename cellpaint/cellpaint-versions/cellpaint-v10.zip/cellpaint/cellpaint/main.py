import time
import multiprocessing as mp

from cellpaint.utils.img_files import get_all_file_paths

from cellpaint.steps.step0_args import Args
from cellpaint.steps.step1_segmentation_p1 import step1_main_run_loop
from cellpaint.steps.step2_segmentation_p2 import step2_main_run_loop
from cellpaint.steps.step3_feature_extraction import step3_main_run_loop
from cellpaint.steps.step4_quality_control import step4_run_for_loop
from cellpaint.steps.step5_distance_maps import FeatureDistMap
from cellpaint.steps.step6_heatmaps import step6_main_run_loop
from cellpaint.steps.step7_rocauc import ROCAUCAnalysis
from cellpaint.utils.post_feature_extraction import FeaturePreprocessing


def fix_metadata(args):
    import numpy as np
    import pandas as pd
    metadata = pd.read_csv(args.feats_path / "metadata_of_features.csv")
    ##############################################################################################################
    # fix the DMSO Inner dosage for Mike Bolt Flav-Screen
    # TODO: Fix it using the plate-map itself and save/overwrite the fixed platemap,
    #  for mike bolt flav-screen experiments
    for it in ["dmso", "dmso-inner", "dmso-outer", "outer", "media"]:
        if np.isin(it, metadata["treatment"].to_list()):
            metadata.loc[metadata["treatment"] == it, "dosage"] = 0
            print(it, np.unique(metadata.loc[metadata["treatment"] == it]["dosage"]))
    metadata.to_csv(args.feats_path / "metadata_of_features.csv", index=False, float_format="%.2f")
    metadata["exp-id"] = args.experiment
    metadata.to_csv(args.feats_path / "metadata_of_features.csv", index=False, float_format="%.2f")


def main_worker(args):
    """
    This program has three modes:

    1) args.mode="debug":
      It helps with debugging and making sure the logic
      of the code follows through all the steps without any errors or breaks,
      Use it, if you want to make changes/improvements in a small part of the code.
      It does not any multiprocess.

    2) args.mode="test":
        Always run main_worker using args.mode=="test" first.
        It makes sure the code/program runs from start to finish on a small number (args.num_test_images) of images
        in args.main_path / args.experiment / args.img_folder folder.
        It uses multiprocess in step II and III for speed-up.

    3) args.mode="full":
         Runs the main_worker on the entire set of tiff images in the
         args.main_path / args.experiment / args.img_folder folder.
         It uses multiprocess in step II and III for speed-up.
    """
    # # segmentation and feature extraction
    # step1_main_run_loop(args)
    # step2_main_run_loop(args)
    # step3_main_run_loop(args)

    # # computes quality control
    # step4_run_for_loop(args)

    # # generates DistMaps
    # step5 = FeatureDistMap(args)
    # step5.main_run_loop()

    # # generate HeatMaps from DistMaps in Step5
    # step6_main_run_loop(args)

    # generates ROC-Curves and ROC-AUC from DistMaps in Step5
    step7 = ROCAUCAnalysis(args)
    N1 = len(step7.args.treatments)
    N2 = len(step7.args.control_treatments)
    print(f"# treatments: {N1}    # control treatments: {N2}")
    assert N1 >= N2
    if N1 > N2:
        # # to check on control treatments separately to see if they have worked!!!
        # print('Controls Only ...')
        # step7.partI_get_graphs(controls_only=True)
        print('All Treatments ...')
        step7.partI_get_graphs(controls_only=False)
        print('\n')

    else:
        step7.partI_get_graphs(controls_only=True)
    step7.partII_get_graphs()

    # TODO Top Priority (part I):
    #  0) Completely Reworked and update step 7  ✓✓✓
    #  1) Finish Hit calling code (redo the function for multi-dose cases, multi-condition cases) ✓✓✓
    #  2) Bring the control treatments to top in heatmap display (step 6)   ✓✓✓
    #  3) Fix Pankaj's PC to be able to run shit on it
    #  (Tell IT to clear his C drive and transfer his Microsoft rights)
    #  4) Write a new torch API for Distance-Map calculation with Data-API, Model-API  ✓✓✓
    #  4b) Smart Batch size selection function base on number of cells per well and feature chunk sizes.
    #  5) Inherit Args class in all classes (in all steps) and Fix and rework all class inheritances
    #  6) Divide utils into 3 Separate Folders:  ✓✓✓
    #               ###############
    #               1-Helpers and 2-Analysis-steps and 3-Others and Input_Error_Fixes Folders
    #               #################
    #  7) Use a different legend color for outlier wells in QC (step 4) ✓✓✓
    #  7b) Use a different legend color for outlier wells and control compounds in Heatmap (step6) ✓✓✓
    #  7c) Adjust y-lables right and y-labels left font size based on the number of rows in Heatmap (Step6) ✓✓✓
    #  7d) all cell-count to misc-features during feature extraction to display in Heatmap (step6) [Maybe!!!]
    #  8) Add assert/check error message if the folder is empty before the analysis starts (empty folder check!!!)

    # TODO Top Priority (part II):
    #  8) Change Haralick Features (from summary-stats back to their initial/original values)
    #  9) Bring outlier wells to the front  ✓✓✓
    #  10) Adjust min and max (use top3 or top5 instead based on the number of plots)
    #       or use log for better visibility in all deriv-plots
    #  11) Add (AVG_Mean-AVG_Median well average) before and after QC for control compounds
    #  12) Fix Mike Bolt plates manually using openpyxl for DMSO, DMSO INNER, and OUTER Dosage
    #      Dosage has to equal zero for these treatments
    #  13) Remove font and color related classes by fitting a curve to num_curves different values
    """https://stackoverflow.com/questions/18909696/how-to-change-the-text-color-of-font-in-legend"""

    # TODO Dr Labate and Paper:
    #  Write a small skeleton for the method and add some pictures to the Docx for
    #  Change DerivMap to ROCCurve (Receiving Operator Characteristic Curve) and
    #  AUC_map to ROCAUC to fullfil Dr Labate's Wishes ✓✓✓

    # TODO Before Leaving:
    #  1) Fix mask files, add the missing ones as zeros
    #  2) Adjust all fonts and legend positions
    #  3) Fix all files names in all the different hard drives
    #  4) Add a small message to all the errors for users to understand their mistakes
    #  5) Add more error messages for user mistake

    # TODO: My own wish-list:
    #  12) Add projection-maps to the end of the analysis
    #  13) Add multiple nucleus cell percentage as a new misc feature
    #       (To tout why we have a great segmentation !!!)
    #  14) Add number of objects count to the segmentation step to speed-up the feature extraction step slightly!!!
    #  15) Add the figures + summary stat example images as a new feature
    #  16) Add the scattering features together with Michela!!!
    #  17) Make Haralick-features Cuda Implementation
    #  18) Implement the speed-up of Cellpose Segmentation
    #  19) Implement the Neural-Network for Segmentation of all channels Simultaneously!!!


if __name__ == "__main__":
    pairs = \
        [
            # ######## ("20220607-CP-FStossi-Density-BM-U20S", 'F'),
            # ####### ("20220817-CP-FStossi-Density-BM_20220817_120119", 'I'),
            # ###### ####### ########### ("20220831-CP-FStossi-DRC-BM-R01_20220831_173200", 'G'),

            ##############################################################
            # ("20220831-CP-FStossi-DRC-BM-R01_20220831_173200", 'F'),
            # ("20220908-CP-FStossi-DRC-BM-R02-20220908_142836", 'F'),

            ("20221102-CP-FStossi-DRC-BM-celllines-P01_20221102_144836", 'F'),
            ("20221102-CP-FStossi-DRC-BM-celllines-P02_20221103_143400", 'F'),

            ("20221109-CP-FStossi-DRC-BM-P01", 'F'),
            ("20221109-CP-FStossi-DRC-BM-P02", 'F'),

            ("20221116-CP-FStossi-DRC-BM-P01", 'F'),
            ("20221116-CP-FStossi-DRC-BM-P02", 'F'),

            ("20230111-CP-FStossi-compoundscelllines-P01", 'F'),
            ("20230111-CP-FStossi-compoundscelllines-P02", 'F'),

            ("20230119-CP-FStossi-QCcelllines-EXP01", 'F'),
            ("20230124-CP-FStossi-QCcelllines-EXP02", 'F'),
            ####################################################################
            ("20230112-CP-MBolt-Seema", 'F'),
            ("20230116-CP-MBolt-Seema", 'F'),
            ("20230120-CP-MBolt-Seema", 'F'),
            ("20230124-CP-MBolt-Seema", 'F'),
            ("20230210-CP-MBolt-Seema_100617", 'F'),   # ran out of memory
            ("20230127-CP-MBolt-Seema_20230127_152035", 'F'),
            ("20230203-CP-MBolt-Seema_20230203_174509", 'F'),
            ("20230216-CP-MBolt-Seema_20230223_091810", 'F'),
            ########################################################################
            # ##### on F drive
            ("20230119-CP-MBolt-Bladder", 'F'),
            ("20230203-CP-MBolt-Bladder_20230202_131118", 'F'),
            ###########################################################################
            # # ###### Mike Bolt FlavScreen ######
            ("20230218-CP-MBolt-FlavScreen-5637_20230222_154337", 'F'),
            ("20230219-CP-MBolt-FlavScreen-UMUC3_20230222_092057", 'F'),

            # # ##### on E drive
            ("20230228-CP-MBolt-FlavScreen-5637_20230302_170729", 'E'),
            ("20230229-CP-MBolt-FlavScreen-RT4_20230303_103000", 'E'),
            ("20230302-CP-MBolt-FlavScreen-5637-Rerun_20230309_170739", 'E'),
            ("20230303-CP-MBolt-FlavScreen-RT4_20230308_102430", 'E'),  # bad images

            # ##### on G drive
            ("20230221-CP-MBolt-FlavScreen-RT4_20230227_111543", 'G'),
            ("20230223-CP-MBolt-FlavScreen-5637_20230227_163911", 'G'),
            ("20230224-CP-MBolt-FlavScreen-RT4_20230228_130627", 'G'),

            # ##### on I drive
            ("20230314-CP-MBolt-FlavScreen-UMUC3_20230314_164600", 'I'),
            ("20230315-CP-MBolt-FlavScreen-UMUC3_20230315_111942", 'I'),

            # ##### on H drive
            ("20230316-CP-MBolt-FlavScreen-UMUC3-1-2_20230316_155210", 'H'),
            ("20230317-CP-MBolt-FlavScreen-UMUC3-2-2_20230317_091741", 'H'),
            #######################################################################################
        ]
    for exp_fold, drive in pairs:
        # entry point of the program is creating the necessary args
        print("*********************************************************"
              "*********************************************************"
              "*********************************************************"
              "*********************************************************")
        print(exp_fold, drive)
        start_time = time.time()

        args = Args(experiment=exp_fold, hard_drive=drive, cellpaint_folder="CellPainting",).args
        import shutil
        shutil.rmtree(str(args.main_path/args.experiment/args.derivmaps_path), ignore_errors=True)

        args = Args(experiment=exp_fold, hard_drive=drive, cellpaint_folder="CellPainting", ).args
        main_worker(args)
        print(f"prgogram finished analyzing experiment   "
              f"{args.experiment} in {(time.time()-start_time)/3600} hours...")
        print("*********************************************************"
              "*********************************************************"
              "*********************************************************"
              "*********************************************************")
