#!/usr/bin/env python
from setuptools import setup, find_packages
from os import path

here = path.abspath(path.dirname(__file__))

setup(
    name='cellpaint',
    version='7.0.0',
    description='Implementation of the cellpainting project',
    author='Kazem Safari',
    author_email='mkazem.safari@gmail.com',
    url='https://github.com/kazemSafari/cellpaint',
    packages=find_packages(exclude=[]),
    install_requires=[
        'cellpose',
        'torch', 'torchvision',
        'tifffile',
        'numpy', 'scipy', 'scikit-image', 'scikit-learn',
        'SimpleITK',
        'pandas',
        'matplotlib', 'seaborn', 'plotly', 'openpyxl', 'xlrd',
        'pathlib', 'tqdm', 'typing',
        'pynvml', 'cmcrameri']
)
