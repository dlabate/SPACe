import os
from pathlib import WindowsPath
import time

import scipy.stats
from tqdm import tqdm

import numpy as np
import pandas as pd

from scipy import stats
from sklearn.preprocessing import minmax_scale, robust_scale

import seaborn as sns
import matplotlib.pyplot as plt

# from plotly import express as px
# from plotly.subplots import make_subplots
# import plotly.graph_objects as go

import multiprocessing as mp
from functools import partial

from utils.args import args

"""https://stackoverflow.com/questions/73380537/
how-to-add-multiple-labels-for-multiple-groups-of-rows-in-sns-heatmap-on-right-s"""


class FoundItem(Exception):
    pass


plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
plt.rcParams['mathtext.default'] = 'regular'
# bad_wellids = ["c02", "m02", "o02", "e02", "i02", "g02", "k02",
#                "i03", "c03", "g03", "e03",
#                "c04"]
# def filter_index(indices):
#     return [it for it in indices if it.split("_")[2].lower() not in bad_wellids]


def plot_heatmap(key, cin, thresh=.1):
    dist_df = pd.read_csv(
        args.main_path / args.experiment / "results" / f"df_{key}_dist-w{cin}.csv",
        index_col=0)
    ########################################################
    # from bounding-box cols
    cols = list(dist_df.columns)
    cols = [it for it in cols if "bbox" not in it]
    # print(cols)
    dist_df = dist_df[cols]
    #############################################################
    # apply the upper and lower thresholds for better visualization
    df_plot = dist_df[(dist_df <= -thresh) | (dist_df >= thresh)]
    ##################################################################
    # # remove bad wells
    # valids = filter_index(list(df_plot.index))
    # df_plot = df_plot[df_plot.index.isin(valids)]
    ##################################################################
    # predefine/preset x axis and yaxis labels
    xlabels = dist_df.columns.tolist()
    xlabels = ["".join(it.split('-')[1:]) for it in xlabels]

    ylabels = list(dist_df.index)
    ylabels = [it.replace(" ", "-") for it in ylabels]

    ylabels_left = [f"well-id={it.split('_')[2]}_#cells={it.split('_')[3]}" for it in ylabels]
    tmp_right = [f"{it.split('_')[0]}_{it.split('_')[1]}" for it in ylabels]
    ###################################################################################
    # create the matplotlib/sns figure object
    fig, (ax1, axcb) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [1, 0.08]}, )
    fig.set_size_inches(21.3, 13.3)
    # fig.set_size_inches(54.1, 33.8 )
    fig.suptitle(
        f"experiment={args.experiment}   channel={channel_name}   map={key}-map",
        # fontname='Comic Sans MS',
        fontsize=18)
    #######################################################################
    # create the heatmap
    # set lower and upper thresholds for heatmap values for better display
    # ymin = np.percentile(df_plot.values, 5)
    # ymax = np.percentile(df_plot.values, 95)
    g1 = sns.heatmap(
        df_plot,
        # linewidths=.05,
        # linecolor='black',
        cmap="jet",
        ax=ax1,
        cbar_ax=axcb,
        # vmin=ymin, vmax=ymax,
        cbar_kws={"shrink": 0.4})
    ##########################################################################
    # set x ticks positions and values
    g1.set_xticks(np.arange(.5, len(xlabels) + .5, 1))
    g1.set_xticklabels([it for ii, it in enumerate(xlabels) if ii % 1 == 0])
    g1.set_xticklabels(g1.get_xmajorticklabels(), fontsize=5)
    # set y ticks positions and values
    g1.set_yticks(np.arange(.5, len(ylabels_left) + .5, 1))
    g1.set_yticklabels([it.lower() for ii, it in enumerate(ylabels_left) if ii % 1 == 0])
    g1.set_yticklabels(g1.get_ymajorticklabels(), fontsize=3)
    ##########################################################################
    # set treatment label on right side of the plot for better readability
    #######################################################################
    # TODO: Add cell count
    # labels for the bands, list of places where the bands start and stop
    unix = list(set(tmp_right))
    unix = sorted(unix, key=lambda x: (x.split("_")[0], float(x.split("_")[1][0:-2])))
    ylabels_right = {it: 0 for it in unix}
    # Warning: the order of items in tmp_right and ylabels should match in order for this for loop to be accurate!!!
    for ii in range(len(ylabels)):
        ylabels_right[tmp_right[ii]] += int(ylabels[ii].split("_")[-1])
    ylabels_right = [f"{k}_{v}" for k, v in ylabels_right.items()]
    # for key, it in ylabels_right.items():
    #     print(f"{key:20}: {it}")
    stops = [tmp_right.index(it) for it in unix] + [len(tmp_right)]
    # create a loop using the begin and end of each band, the colors and the labels
    for beg, end, label in zip(stops[:-1], stops[1:], ylabels_right):
        # add some text to the center right of this band
        g1.text(1.01, (beg + end) / 2,
                # '\n'.join(label.split())
                label,
                ha='left', va='center',
                transform=g1.get_yaxis_transform(), size=9)
    # sns.set_context(font_scale=0.7)  # scale factor for all fonts
    ##############################################################################
    # customize horizontal and vertical gridlines
    ww = list(np.arange(0, len(xlabels), 1))
    hh = list(np.arange(0, len(ylabels_left), 1))
    for it in stops[1:-1]:
        g1.hlines(y=it, xmin=0, xmax=len(ww), linestyle='dashed', linewidth=.4, color="black")
    x = [0]
    # get the first intensity key column index
    try:
        for cc in args.intensity_keys:
            for it in cols:
                if cc in it:
                    x.append(cols.index(it))
                    raise FoundItem
    except:
        pass
    # get haralick keys column index
    for cc in args.haralick_keys:
        for it in cols:
            if cc in it:
                x.append(cols.index(it))
                break
    for it in x:
        g1.vlines(x=it, ymin=0, ymax=len(hh), linestyle='dashed', linewidth=.4, color="black")
    # add text for sub-categories of features as well
    x.append(len(cols))
    for beg, end, label in zip(x[:-1], x[1:], ["Shape", "Intensity"]+args.haralick_keys):
        # add some text to the center right of this band
        g1.text((beg + end) / 2, 1.05,
                # '\n'.join(label.split())
                label,
                va='top', ha='center',
                transform=g1.get_xaxis_transform(), size=14,)
    ############################################################################################################
    # rotate the tick labels correctly
    tl = g1.get_xticklabels()
    g1.set_xticklabels(tl, rotation=90)
    tly = g1.get_yticklabels()
    g1.set_yticklabels(tly, rotation=0)
    ###############################################################################
    plt.subplots_adjust(wspace=.25)
    # plt.tight_layout()
    plt.savefig(args.main_path / args.experiment / "results" / f"{cin}-{channel_name}-{key}-{thresh}.png",
                bbox_inches='tight', dpi=300)
    # plt.show()


thresh = .1
axis_font = {'fontname': 'sans-serif', 'size': 20}
for key in ["distrib", "median", "mean"]:
    for cin, channel_name in zip([0, 1, 2, 3, 4], ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]):
        print(key, cin, )
        plot_heatmap(key, cin, thresh=thresh)
