import time
# from functools import lru_cache
# import numba as nb
# import matplotlib.pyplot as plt
from tqdm import tqdm

from scipy import ndimage as ndi
from scipy.stats import median_abs_deviation

from skimage.measure import _moments
from skimage.measure._regionprops import RegionProperties, _cached, only2d
from skimage.feature import graycomatrix

from PIL.Image import open
from utils.image_and_mask_files import *

np.set_printoptions(linewidth=500)


# @nb.njit(nogil=True, cache=True)
def discretize_intensity(img, intensity_level_thresholds):
    # discrete_img = np.zeros(img.shape, dtype=np.uint8)
    discrete_img = np.clip(img, None, intensity_level_thresholds[-1]).astype(np.uint8)
    N = len(intensity_level_thresholds)
    for ii in range(1, N):
        i0 = intensity_level_thresholds[ii - 1]
        i2 = intensity_level_thresholds[ii]
        # chop clipping the image
        # discrete_img[(i0 <= img) & (img < i1)] = ii
        # discrete_img += ((i0 <= img) * (img < i1) * (ii - 1)).astype(np.uint8)
        #########################################################################
        # round clipping the image
        i1 = i0 + (i2 - i0) // 2
        discrete_img[(i0 <= img) & (img < i1)] = ii - 1
        discrete_img[(i1 <= img) & (img < i2)] = ii
    return discrete_img


def safe_log_10_v0(value):
    """https://stackoverflow.com/questions/21610198/runtimewarning-divide-by-zero-encountered-in-log"""
    value = np.abs(value)
    result = np.where(value > 1e-12, value, -12)
    # print(result)
    res = np.log10(result, out=result, where=result > 1e-12)
    return res


def safe_log_10_v1(value):
    """Pankaj"""
    return np.log(1+np.abs(value))


class RegionPropertiesExtension(RegionProperties):
    """Please refer to `skimage.measure.regionprops` for more information
    on the available region properties.
    """
    ndim = 2

    def __init__(self, slice, label, label_image,
                 intensity_image, intensity_image_discrete,
                 intensity_percentiles, distances, angles,
                 cache_active=True, ):
        super().__init__(slice, label, label_image, intensity_image, cache_active)

        self.intensity_percentiles = intensity_percentiles

        self._intensity_image_discrete = intensity_image_discrete
        self.num_levels = np.amax(self._intensity_image_discrete) + 1
        self.distances = distances
        self.angles = angles

    def __getattr__(self, attr):
        getattr(self, attr)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)

    @property
    @_cached
    def image_intensity_discrete(self):
        if self._intensity_image_discrete is None:
            raise AttributeError('No intensity image specified.')
        return self._intensity_image_discrete[self.slice] * self.image

    @property
    @only2d
    @_cached
    def moments_hu(self):
        mh = _moments.moments_hu(self.moments_normalized)
        # mh = -1 * np.sign(mh) * np.log(np.abs(mh))
        # print("mh")
        # print(mh)
        # print("Stackoverflow", -1 * np.sign(mh) * safe_log_10_v0(mh))
        # print('\n')
        # print('\n')
        mh = -1 * np.sign(mh) * safe_log_10_v0(mh)
        return mh

    @property
    @only2d
    @_cached
    def moments_weighted_hu(self):
        nu = self.moments_weighted_normalized
        if self._multichannel:
            nchannels = self._intensity_image.shape[-1]
            # return np.stack(
            #     [_moments.moments_hu(nu[..., i]) for i in range(nchannels)],
            #     axis=-1,)
            mhw = np.stack([_moments.moments_hu(nu[..., i]) for i in range(nchannels)], axis=-1, )
            mhw = -1 * np.sign(mhw) * safe_log_10_v0(mhw)
            return mhw
        else:
            mhw = _moments.moments_hu(nu)
            # print("mhw")
            # print(mhw)
            # print("Stackoverflow", -1 * np.sign(mhw) * safe_log_10_v0(mhw))
            # print('\n')
            mhw = -1 * np.sign(mhw) * safe_log_10_v0(mhw)
            return mhw

    @property
    @_cached
    def moments_weighted_normalized(self):
        mu = self.moments_weighted_central
        if self._multichannel:
            nchannels = self._intensity_image.shape[-1]
            mwn = np.stack(
                [_moments.moments_normalized(mu[..., i], order=3) for i in range(nchannels)], axis=-1, )
            mwn = -1 * np.sign(mwn) * safe_log_10_v0(mwn)
            return mwn
        else:
            mwn = _moments.moments_normalized(mu, order=3)

            # print("mwn")
            # print(mwn)
            # print("Stackoverflow", -1 * np.sign(mwn) * safe_log_10_v0(mwn))
            # print('\n')

            mwn = -1 * np.sign(mwn) * safe_log_10_v0(mwn)
            return mwn

    @property
    @_cached
    def image_intensity_vec(self):
        return self.image_intensity[self.image_intensity > 0]

    @property
    @_cached
    def intensity_statistics(self, ):
        percentiles = np.percentile(self.image_intensity_vec, self.intensity_percentiles)
        intensity_median, intensity_mad, intensity_mean, intensity_std = \
            np.median(self.image_intensity_vec), median_abs_deviation(self.image_intensity_vec), \
            np.mean(self.image_intensity_vec), np.std(self.image_intensity_vec)
        return tuple(percentiles) + (intensity_median, intensity_mad, intensity_mean, intensity_std,)

    @property
    @_cached
    def P(self):  # gray-comatrix
        # remove level-zero (pixels with value zero are background and have to be removed from analysis)
        P = graycomatrix(
            self.image_intensity_discrete,
            distances=self.distances,
            angles=self.angles,
            levels=self.num_levels,
            symmetric=False, normed=False)[1:, 1:]
        # normalize each GLCM
        P = P.astype(np.float32)
        glcm_sums = np.sum(P, axis=(0, 1), keepdims=True)
        glcm_sums[glcm_sums == 0] = 1
        P /= glcm_sums
        return P

    @property
    @_cached
    def haralick_features(self, ):
        """Calculate texture properties of a GLCM.
        Compute a feature of a gray level co-occurrence matrix to serve as
        a compact summary of the matrix. The properties are computed as
        follows:
        - 'contrast': :math:`\\sum_{i,j=0}^{levels-1} P_{i,j}(i-j)^2`
        - 'dissimilarity': :math:`\\sum_{i,j=0}^{levels-1}P_{i,j}|i-j|`
        - 'homogeneity': :math:`\\sum_{i,j=0}^{levels-1}\\frac{P_{i,j}}{1+(i-j)^2}`
        - 'ASM': :math:`\\sum_{i,j=0}^{levels-1} P_{i,j}^2`
        - 'energy': :math:`\\sqrt{ASM}`
        - 'correlation':
            .. math:: \\sum_{i,j=0}^{levels-1} P_{i,j}\\left[\\frac{(i-\\mu_i) \\
                      (j-\\mu_j)}{\\sqrt{(\\sigma_i^2)(\\sigma_j^2)}}\\right]
        Each GLCM is normalized to have a sum of 1 before the computation of
        texture properties.
        .. versionchanged:: 0.19
               `greycoprops` was renamed to `graycoprops` in 0.19.
        Parameters
        ----------
        P : ndarray
            Input array. `P` is the gray-level co-occurrence histogram
            for which to compute the specified property. The value
            `P[i,j,d,theta]` is the number of times that gray-level j
            occurs at a distance d and at an angle theta from
            gray-level i.
        prop : {'contrast', 'dissimilarity', 'homogeneity', 'energy', \
                'correlation', 'ASM'}, optional
            The property of the GLCM to compute. The default is 'contrast'.
        Returns
        -------
        results : 2-D ndarray
            2-dimensional array. `results[d, a]` is the property 'prop' for
            the d'th distance and the a'th angle.
        References
        ----------
        .. [1] M. Hall-Beyer, 2007. GLCM Texture: A Tutorial v. 1.0 through 3.0.
               The GLCM Tutorial Home Page,
               https://prism.ucalgary.ca/handle/1880/51900
               DOI:`10.11575/PRISM/33280`
        Examples
        --------
        Compute the contrast for GLCMs with distances [1, 2] and angles
        [0 degrees, 90 degrees]
        >>> image = np.array([[0, 0, 1, 1],
        ...                   [0, 0, 1, 1],
        ...                   [0, 2, 2, 2],
        ...                   [2, 2, 3, 3]], dtype=np.uint8)
        >>> g = graycomatrix(image, [1, 2], [0, np.pi/2], levels=4,
        ...                  normed=True, symmetric=True)
        """
        # print(P.shape)
        (num_level, num_level2, num_dist, num_angle) = self.P.shape
        if num_level != num_level2:
            raise ValueError('num_level and num_level2 must be equal.')
        if num_dist <= 0:
            raise ValueError('num_dist must be positive.')
        if num_angle <= 0:
            raise ValueError('num_angle must be positive.')
        ##############################################
        ####################################
        # create weights for specified property
        I, J = np.ogrid[0:num_level, 0:num_level]
        ###############################
        # contrast
        weights0 = (I - J) ** 2
        weights0 = weights0.reshape((num_level, num_level, 1, 1))
        contrast = np.sum(self.P * weights0, axis=(0, 1))
        # dissimilarity
        weights1 = np.abs(I - J)
        weights1 = weights1.reshape((num_level, num_level, 1, 1))
        dissimilarity = np.sum(self.P * weights1, axis=(0, 1))
        # homogeneity
        weights2 = 1. / (1. + (I - J) ** 2)
        weights2 = weights2.reshape((num_level, num_level, 1, 1))
        homogeneity = np.sum(self.P * weights2, axis=(0, 1))
        ###################################################
        # asm and energy
        asm = np.sum(self.P ** 2, axis=(0, 1))
        # energy = np.sqrt(asm)
        ##############################################
        # correlation
        correlation = np.zeros((num_dist, num_angle), dtype=np.float64)
        I = np.array(range(num_level)).reshape((num_level, 1, 1, 1))
        J = np.array(range(num_level)).reshape((1, num_level, 1, 1))
        diff_i = I - np.sum(I * self.P, axis=(0, 1))
        diff_j = J - np.sum(J * self.P, axis=(0, 1))
        std_i = np.sqrt(np.sum(self.P * (diff_i ** 2), axis=(0, 1)))
        std_j = np.sqrt(np.sum(self.P * (diff_j ** 2), axis=(0, 1)))
        cov = np.sum(self.P * (diff_i * diff_j), axis=(0, 1))
        # handle the special case of standard deviations near zero
        mask_0 = std_i < 1e-15
        mask_0[std_j < 1e-15] = True
        correlation[mask_0] = 1
        # handle the standard case
        mask_1 = ~mask_0
        correlation[mask_1] = cov[mask_1] / (std_i[mask_1] * std_j[mask_1])
        ###############################################
        haralick_features = np.vstack((contrast, dissimilarity, homogeneity, asm, correlation)).reshape(-1)
        return haralick_features


def regionprops(w0_mask, w1_mask, w2_mask, w4_mask, img,
                intensity_percentiles, distances, angles, intensity_level_thresholds):
    N = len(np.unique(w0_mask)) - 1
    regions = np.zeros((5, N), dtype=object)
    has_nucleoli = np.zeros((N, 1), dtype=np.uint8)

    max_ = np.amax(w0_mask)
    img_discrete = discretize_intensity(img, intensity_level_thresholds)
    w0_objects = ndi.find_objects(w0_mask, max_label=max_)
    w1_objects = ndi.find_objects(w1_mask, max_label=max_)
    w2_objects = ndi.find_objects(w2_mask, max_label=max_)
    w4_objects = ndi.find_objects(w4_mask, max_label=max_)
    cnt = 0
    for ii in range(max_):
        if w0_objects[ii] is None:
            continue
        label = ii + 1
        w0_props = RegionPropertiesExtension(
            w0_objects[ii], label, w0_mask, img[0], img_discrete[0],
            intensity_percentiles, distances, angles, )
        w1_props = RegionPropertiesExtension(
            w1_objects[ii], label, w1_mask, img[1], img_discrete[1],
            intensity_percentiles, distances, angles, )
        w3_props = RegionPropertiesExtension(
            w1_objects[ii], label, w1_mask, img[3], img_discrete[3],
            intensity_percentiles, distances, angles, )
        w4_props = RegionPropertiesExtension(
            w4_objects[ii], label, w4_mask, img[4], img_discrete[4],
            intensity_percentiles, distances, angles, )
        if w2_objects[ii] is not None:
            w2_props = RegionPropertiesExtension(
                w2_objects[ii], label, w2_mask, img[2], img_discrete[2],
                intensity_percentiles, distances, angles, )
            has_nucleoli[cnt] = 1
        else:
            w2_props = None
            has_nucleoli[cnt] = 0

        regions[0, cnt] = w0_props
        regions[1, cnt] = w1_props
        regions[2, cnt] = w2_props
        regions[3, cnt] = w3_props
        regions[4, cnt] = w4_props

        cnt += 1

    return regions, has_nucleoli


def get_features(index,
                 args,
                 img_path_groups,
                 w0_mask_paths,
                 w1_mask_paths,
                 w2_mask_paths,
                 w4_mask_paths,
                 ):
    """
        w0_mask_path = .../w0_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
        w1_mask_path = .../w1_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
        w2_mask_path = .../w2_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
        w4_mask_path = .../w4_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
        img_channels_group:
        [
        .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w1DCEB3369-8F24-4915-B0F6-B543ADD85297.tif,
        .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w2C3AF00C2-E9F2-406A-953F-2ACCF649F58B.tif,
        .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w3524F4D75-8D83-4DDC-828F-136E6A520E5D.tif,
        .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w4568AFB8E-781D-4841-8BC8-8FD870A3147F.tif,
        .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w5D9A405BD-1C0C-45E4-A335-CEE88A9AD244.tif,
        ]
        """
    # print(w0_mask_paths[index].stem)
    # read the masks and image from hard drive
    w0_mask = np.array(open(w0_mask_paths[index])).astype(np.uint16)  # nuclei mask
    if len(np.unique(w0_mask)[1:]) < args.min_cell_count:
        return None
    w1_mask = np.array(open(w1_mask_paths[index])).astype(np.uint16)  # w1 mask
    w2_mask = np.array(open(w2_mask_paths[index])).astype(np.uint16)  # w2 mask
    w4_mask = np.array(open(w4_mask_paths[index])).astype(np.uint16)  # w4 mask
    # img of the fov with 4 channels: (DAPI, CYTOPLASM, WGA, MITOCONDRIA)
    # img of the fov with 5 channels: (DAPI, CYTO, w2, actin, MITO)
    img = load_img(img_path_groups[index], args.num_channels, args.height, args.width)
    if args.experiment == "others":
        # others = [nucleus, mito, actin, nucleoli, cyto]
        # ours = ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]
        img = img[[args.nucleus_idx, args.cyto_idx, args.nucleoli_idx, args.actin_idx, args.mito_idx]]
    # ts = time.time()
    img_discrete = discretize_intensity(img, args.intensity_level_thresholds)
    # print(f"creating discrete image takes {time.time() - ts} seconds ...")
    ####################################################################################
    # TODO: Check if there is any speed up, using product instead of broadcasting.
    # remove the w0 from the w1plasm mask
    # relabel w2_mask with the nuclei/w1plasm masks (already matching) labels
    w1_mask[w0_mask > 0] = 0
    # w2_mask[w2_mask > 0] = w0_mask[w2_mask > 0]
    w2_mask = w0_mask * (w2_mask > 0).astype(np.uint8)

    # cell_mask = w0_mask + w1_mask  # actin mask
    # assert np.array_equal(cell_mask * (w0_mask > 0), w0_mask)
    ####################################################################################################
    N = len(np.unique(w0_mask)) - 1
    #################################################################################################
    max_ = np.amax(w0_mask)
    w0_objects = ndi.find_objects(w0_mask, max_label=max_)
    w1_objects = ndi.find_objects(w1_mask, max_label=max_)
    w2_objects = ndi.find_objects(w2_mask, max_label=max_)
    w4_objects = ndi.find_objects(w4_mask, max_label=max_)
    ##########################################################
    objects = [w0_objects, w1_objects, w2_objects, w1_objects, w4_objects]
    masks = np.concatenate([
        w0_mask[np.newaxis],
        w1_mask[np.newaxis],
        w2_mask[np.newaxis],
        w1_mask[np.newaxis],
        w4_mask[np.newaxis],
    ], axis=0)
    #################################################################
    cnt = 0
    m1 = 57
    m2 = m1 + args.num_intensity_keys
    m3 = m2 + args.num_haralick_keys
    features = np.zeros(shape=(5, N, m3), dtype=np.float32)
    has_nucleoli = np.zeros(shape=(N, 1), dtype=bool)
    range_ = tqdm(range(max_), total=max_) if args.testing else range(max_)
    for ii in range_:  # loops over each region/bounding box
        if w0_objects[ii] is None:  # if there is no cell skip it (the cell must've been removed in preprocessing).
            continue
        label = ii + 1

        for jj in range(0, 5):  # loops over the 5 channels

            if jj == 2 and objects[2][ii] is None:  # if there is no nucleoli skip it.
                has_nucleoli[cnt] = 0
                continue

            has_nucleoli[cnt] = 1
            props = RegionPropertiesExtension(
                objects[jj][ii], label, masks[jj], img[jj], img_discrete[jj],
                args.intensity_percentiles, args.distances, args.angles, )
            #####################
            # bounding box
            features[jj, cnt, 0:4] = props.bbox
            #####################
            # shape features
            features[jj, cnt, 4] = props.area
            features[jj, cnt, 5] = props.area_convex
            features[jj, cnt, 6] = props.perimeter
            features[jj, cnt, 7] = props.perimeter_crofton
            features[jj, cnt, 8] = props.eccentricity
            features[jj, cnt, 9] = props.equivalent_diameter_area
            features[jj, cnt, 10] = props.extent
            features[jj, cnt, 11] = props.feret_diameter_max
            features[jj, cnt, 12] = props.solidity
            ##################
            # moments features
            features[jj, cnt, 13:15] = props.centroid_local
            features[jj, cnt, 15:17] = props.centroid_weighted_local
            features[jj, cnt, 17:30] = props.moments_normalized.reshape(-1, order='C')[args.mnids]
            features[jj, cnt, 30:43] = props.moments_weighted_normalized.reshape(-1, order='C')[args.mnids]
            features[jj, cnt, 43:50] = props.moments_hu.reshape(-1, order='C')
            features[jj, cnt, 50:m1] = props.moments_weighted_hu.reshape(-1, order='C')
            #################################
            # intensity features
            features[jj, cnt, m1:m2] = props.intensity_statistics
            ################################
            # haralick features
            features[jj, cnt, m2:m3] = props.haralick_features
        cnt += 1
    return features, has_nucleoli


if __name__ == "__main__":
    print(args.experiment)
    img_path_groups, w0_mask_paths, w1_mask_paths, args.num_channels = \
        get_matching_img_group_nuc_mask_cyto_mask(
            args.main_path, args.experiment, args.plate_protocol, mask_folder="Masks")
    w2_mask_paths = [it.parents[0] / f"w2_{'_'.join(it.stem.split('_')[1:])}.png" for it in w0_mask_paths]
    w4_mask_paths = [it.parents[0] / f"w4_{'_'.join(it.stem.split('_')[1:])}.png" for it in w0_mask_paths]

    for ii in range(10):
        get_features(ii,
                     args,
                     img_path_groups,
                     w0_mask_paths,
                     w1_mask_paths,
                     w2_mask_paths,
                     w4_mask_paths,)
