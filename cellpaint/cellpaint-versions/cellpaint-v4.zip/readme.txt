The latest experiment is in the "2022-0817-CP-benchmarking-density_20220817_120119" folder of the drive I gave michela and is roughly 60GB.
The platemap is in the same folder and is called "2022_0820_CP_benchmarking_plate map2.xlsx".

Each image has 5 channels:
w0 (dapi) / w1(cyto) /  w2 (nucleoli) / w3 (actin) / w4 (mito)

for example from the folder in my computer, F:\CellPainting\2022-0817-CP-benchmarking-density_20220817_120119\AssayPlate_PerkinElmer_CellCarrier-384:

AssayPlate_PerkinElmer_CellCarrier-384_A01_T0001F001L01A05Z01C01.tif
AssayPlate_PerkinElmer_CellCarrier-384_A01_T0001F001L01A04Z01C02.tif
AssayPlate_PerkinElmer_CellCarrier-384_A01_T0001F001L01A03Z01C03.tif
AssayPlate_PerkinElmer_CellCarrier-384_A01_T0001F001L01A02Z01C04.tif
AssayPlate_PerkinElmer_CellCarrier-384_A01_T0001F001L01A01Z01C05.tif

These 5 files corresponding to 5 channels beloging the same image (the channel indicator is C01/C02/C03/C04/C05.
The image belongs to Well-id, A01, and FOV, F001,  in the platemap.
Therefore it is taken from the "veh" treatment/condition, the "U2OS" cell-line, at "10K" density, based on reading the corresponding info about
 A01 cell in the "Compound"/"CellLine"/"Density" sheets of the .



At the moment, the analysis has 4 steps:

"0_get_cellpose_masks.py"   (Takes roughly 2-4 hours to run on the entire folder/half-plate)
extracts the nucleus and cytoplasm masks from the w0 and w1 channels of batches of images using the cellpose library.

"1_get_masks.py"  (Takes roughly 20 minutes ...)
Post-processes the w0 and w1 masks as well as creating the w2 mask (for nucleoli channel).

"2_get_features.py"  (Takes roughly 2 and half hours ...)
Extracts the features from all the 5 channels.

"3_vis_features.py"  (Takes roughly 5 minutes ....)
Visualizes those features.


To run any step of the analysis, you need first assign the fullpath to the folder where your dataset is stored to the "main_path" argument in the utils/args,py file, e.g. in my pc args.main_path default value is "F:\CellPainting".
Afterwards, simply type python, the associated step_name.py in the terminal as follows. For example for step 0 type:

(to debug and visualize) 
>>> python 0_get_cellpose_masks.py --experiment="2022-0817-CP-benchmarking-density_20220817_120119" 

(to actually run the code and get the result)
>>> python 0_get_cellpose_masks.py --experiment="2022-0817-CP-benchmarking-density_20220817_120119" --testing=""


(when setting the arg testing to "" or False, all the python files except the step 0 file use the multiprocessing python
package for speedup.


Here is the list of the python packages you need to install in order for this code to work:

tifffile, tqdm, pathlib,
cellpose, torch, torchvision
numpy, pandas, skimage, sklearn, scipy, SimpleITK
matplotlib, plotly, seaborn, jupyter-notebook