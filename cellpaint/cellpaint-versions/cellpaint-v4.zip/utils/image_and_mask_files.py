import itertools

import tifffile
import numpy as np
import SimpleITK as sitk
from skimage.exposure import rescale_intensity
from skimage.segmentation import find_boundaries
from skimage.color import label2rgb
from utils.args import args


def containsLetterAndNumber(input):
    """https://stackoverflow.com/questions/64862663/how-to-check-if-a-string-is-strictly-
    contains-both-letters-and-numbers"""
    return input.isalnum() and not input.isalpha() and not input.isdigit()


def sort_fn(file_path, plate_protocol, sort_purpose):
    """
    Sort image filenames for a specific experiment taken with a specific plate_protocol.
    """
    # plate_protocol = plate_protocol.lower()
    if plate_protocol == "Greiner" or plate_protocol == "PerkinElmer":
        """img filename example:
        .../AssayPlate_PerkinElmer_CellCarrier-384/AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif
        .../AssayPlate_Greiner_#781896/AssayPlate_Greiner_#781896_A04_T0001F001L01A01Z01C01.tif
        """
        # def get_image_path_key(img_path):
        #     split = img_path.stem.split("_")
        #     well_id = split[-2]
        #     # fov = str(int(split[-1][6:9])).zfill(2)
        #     fov = split[-1][5:9]
        #     return f"{well_id}_{fov}"

        folder = file_path.parents[1].stem  # "AssayPlate_PerkinElmer_CellCarrier-384"
        filename = file_path.stem  # AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif
        split = filename.split("_")
        well_id = split[-2]  # A02
        fkey = split[-1]  # T0001F001L01A01Z01C02
        inds = [fkey.index(ll, 0, len(fkey)) for ll in fkey if ll.isalpha()]
        inds.append(None)
        # print(inds)
        id1, fov, id2, x1, p1, channel = \
            [fkey[inds[ii]:inds[ii+1]] for ii in range(len(inds)-1)]
        # print(well_id, parts)

    elif plate_protocol == "combchem":
        """img filename example:
        .../P000025-combchem-v3-U2OS-24h-L1-copy1/
        P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s5_w3C00578CF-AD4A-4A29-88AE-D2A2024F9A92.tif"""
        folder = file_path.parents[1].stem
        filename = file_path.stem
        split = filename.split("_")
        well_id = split[1]
        fov = split[2][1]
        channel = split[3][1]
        # print(well_id, parts)
    else:
        raise ValueError(f"{plate_protocol} is not implemented")

    if sort_purpose == "to_sort_channels":
        return folder, well_id, fov, channel
    elif sort_purpose == "to_group_channels":
        # print(folder, well_id, fov)
        return folder, well_id, fov
    elif sort_purpose == "to_match_it_with_mask_path":
        return f"{well_id}_{fov}"
    elif sort_purpose == "to_get_well_id":
        return well_id
    else:
        raise ValueError(f"sort purpose {sort_purpose} does not exist!!!")


def get_img_paths(main_path, experiment, plate_protocol):
    # plate_protocol = plate_protocol.lower()
    if plate_protocol in ['Greiner', 'PerkinElmer']:
        """AssayPlate_Greiner_#781896_A04_T0001F001L01A01Z01C01"""
        """AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif"""
        img_paths = list((main_path/experiment).rglob("*.tif"))
        img_paths = [item for item in img_paths if item.stem.split("_")[-1][0:5] == "T0001"]
        img_paths = sorted(img_paths, key=lambda x: sort_fn(
            x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))
        return img_paths

    else:
        """P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s5_w3C00578CF-AD4A-4A29-88AE-D2A2024F9A92.tif"""
        return sorted(list((main_path/experiment).rglob("*.tif")),
                      key=lambda x: sort_fn(
                          x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))


def get_mask_path_key(mask_path):
    """example: .../w0_2021-CP007_A02_F001.png"""
    split = mask_path.stem.split("_")
    well_id = split[-2]
    fov = split[-1]
    return f"{well_id}_{fov}"


def sort_mask_filepaths_for_single_experiment(filepath):
    """example: when mask_path is .../w0_2021-CP007_A02_F001.png
    the key for sorting is: (A02, F001)
    """
    return tuple(filepath.stem.split("_")[1:])


def get_matching_img_group_nuc_mask_cyto_mask(
        main_path, experiement, plate_protocol="PerkinElmer", mask_folder="Masks_Cellpose"):
    img_paths = get_img_paths(main_path, experiement, plate_protocol)
    mask0_paths = list((main_path/experiement/mask_folder).rglob("w0_*.png"))  # Nucleus Masks
    mask1_paths = list((main_path/experiement/mask_folder).rglob("w1_*.png"))  # Cytoplasm Masks
    # img_paths_keys = np.unique([get_image_path_key(it) for it in img_paths])
    mask_paths_keys = np.unique([get_mask_path_key(it) for it in mask0_paths])
    # # through away image paths for which is no mask path file.
    img_paths = [it for it in img_paths if sort_fn(it, plate_protocol, "to_match_it_with_mask_path") in
                 mask_paths_keys]
    img_paths = sorted(img_paths, key=lambda x: sort_fn(
        x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))
    mask0_paths = sorted(mask0_paths, key=sort_mask_filepaths_for_single_experiment)
    mask1_paths = sorted(mask1_paths, key=sort_mask_filepaths_for_single_experiment)

    keys, img_path_groups = [], []
    for item in itertools.groupby(
            img_paths, key=lambda x: sort_fn(
                x, plate_protocol=plate_protocol, sort_purpose="to_group_channels")):
        keys.append(item[0])
        img_path_groups.append(list(item[1]))
    num_channels = len(img_path_groups[0])

    for it0, it1, it2 in zip(mask0_paths, mask1_paths, keys):
        split0, split1 = it0.stem.split("_"), it1.stem.split("_")
        assert "_".join(split0[-2:]) == "_".join(split0[-2:]) == "_".join(it2[1:])
    # img_path_groups = np.vstack(img_path_groups)
    return img_path_groups, mask0_paths, mask1_paths, num_channels


def load_img(file_path_group, num_channels, height, width):
    """load channel tiff files belonging to a single image into a single tiff file.
    file_path_group: list of channel tiff files
    example:
    [.../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C01.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C03.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C04.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C05.tiff,]
     num_channels: The number of channels contained in the image,
     height: height of each image (It is always fixed for a single experiment.),
     width: width of each image (It is always fixed for a single experiment.),
    """
    img = np.zeros((num_channels, height, width), dtype=np.float32)
    for jj in range(num_channels):
        img[jj] = tifffile.imread(file_path_group[jj])
    # for jj, fp in enumerate(file_path_group):
    #     img[jj] = tifffile.imread(fp)
    return img


def set_sitk_filter_bounds(filter, lb=0, ub=1):
    filter.SetInsideValue(lb)
    filter.SetOutsideValue(ub)
    return filter


def get_sitk_img_thresholding_mask_v0(img, myfilter):
    tmp1 = img.copy()
    tmp1 = sitk.GetImageFromArray(tmp1)
    tmp1 = myfilter.Execute(tmp1)
    tmp1 = sitk.GetArrayFromImage(tmp1)
    return tmp1


def get_sitk_img_thresholding_mask_v1(img, myfilter):
    tmp = img.copy()
    # tmp = (tmp - np.amin(tmp)) / (np.amax(tmp) - np.amin(tmp) + 1e-6)
    tmp1 = tmp[tmp > 0]
    tmp1 = tmp1.reshape((-1, 1))
    size = tmp1.shape[0]
    tmp1 = sitk.GetImageFromArray(tmp1)
    try:
        tmp1 = myfilter.Execute(tmp1)
        tmp1 = sitk.GetArrayFromImage(tmp1)
    except:
        tmp1 = np.zeros(size, dtype=np.uint16)
    tmp1 = tmp1.reshape(-1)
    tmp[tmp > 0] = tmp1
    return tmp


def get_overlay(img, labeled_mask, colors):
    mask_bd = find_boundaries(
        labeled_mask,
        connectivity=2,
        mode="inner").astype(np.uint16)
    mask_bd[mask_bd != 0] = labeled_mask[mask_bd != 0]
    mask_bd = label2rgb(mask_bd, colors=colors, bg_label=0)

    img = img.copy()
    img = (img - np.amin(img)) / (np.amax(img) - np.amin(img) + 1e-6)
    img = np.repeat(img[:, :, np.newaxis], 3, axis=2)
    # print(mask_bd.shape, img.shape)
    img[mask_bd != 0] = mask_bd[mask_bd != 0]
    return img


def move_figure(f, x, y):
    import matplotlib
    # Bottom vertical alignment for more space, size=14)
    """Move figure's upper left corner to pixel (x, y)"""
    backend = matplotlib.get_backend()
    if backend == 'TkAgg':
        f.canvas.manager.window.wm_geometry("+%d+%d" % (x, y))
    elif backend == 'WXAgg':
        f.canvas.manager.window.SetPosition((x, y))
    else:
        # This works for QT and GTK
        # You can also use window.setGeometry
        f.canvas.manager.window.move(x, y)


def creat_segmentation_example_fig(img, mask0, mask1, mask2, mask_path):
    import matplotlib.pyplot as plt
    well_id = mask_path.stem.split("_")[2]
    fov = mask_path.stem.split("_")[3]
    treat = args.wellid2treat[well_id]
    celline = args.wellid2celline[well_id]

    fig, axes = plt.subplots(2, 2, sharex=True, sharey=True)
    fig.suptitle(f"{celline:15}{treat:12}{well_id:8}{fov}", **args.csfont)
    fig.set_size_inches(12, 13)
    move_figure(fig, 30, 30)
    #############################################################################
    # Enhance the contrast in case the images look too dim.
    # for shelton2 these values seem to work
    if args.rescale_image:
        img[0] = rescale_intensity(img[0], in_range=tuple(np.percentile(img[0], (40, 99))))
        img[1] = rescale_intensity(img[1], in_range=tuple(np.percentile(img[1], (50, 95))))
        img[2] = rescale_intensity(img[2], in_range=tuple(np.percentile(img[2], (50, 95))))
        img[3] = rescale_intensity(img[3], in_range=tuple(np.percentile(img[3], (50, 95))))
    ############################################################################
    # img1 = np.abs(img[3]-img[1])
    for idx, (it, ax) in enumerate(zip(["Nucleus", "Cyto", "Nucleoli", "Actin"], axes.flatten())):
        ax.set_ylabel(it, **args.csfont)
        ax.set_title(f"Channel {idx+1}", **args.csfont)
        ax.set_xticks([])
        ax.set_yticks([])
    axes[0, 0].imshow(get_overlay(img[0], mask0, args.colors), cmap="gray")
    axes[0, 1].imshow(get_overlay(img[1], mask1, args.colors), cmap="gray")
    axes[1, 0].imshow(get_overlay(img[2], mask2, args.colors), cmap="gray")
    axes[1, 1].imshow(get_overlay(img[3], mask2, args.colors), cmap="gray")
    plt.subplots_adjust(hspace=0.1, wspace=.02)
    plt.show()