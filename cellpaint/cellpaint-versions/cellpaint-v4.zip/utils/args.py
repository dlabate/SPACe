import argparse
from typing import Union, Optional, List, Tuple
from pathlib import PosixPath, WindowsPath, Path

import numpy as np
import pandas as pd

import tifffile
import multiprocessing as mp


def get_wellid2meta(platemap_excel_filename, sheetname):
    meta = pd.read_excel(
        args.main_path / args.experiment / platemap_excel_filename, sheet_name=sheetname)
    meta.index = meta['Unnamed: 0']
    meta.index.name = "row_id"
    meta.drop(['Unnamed: 0', ], axis=1, inplace=True)

    if meta.isnull().values.all():
        return None
    meta = meta.loc[~np.all(meta.isna(), axis=1), ~np.all(meta.isna(), axis=0)]
    wellid2meta = {}
    for row_id in meta.index:
        for col_id in meta.columns:
            wellid2meta[f"{row_id}{str(col_id).zfill(2)}"] = \
                str(meta.loc[row_id, col_id]).lstrip().rstrip()
    return wellid2meta


def ignore_imgaeio_warning():
    import warnings
    import imageio.core.util

    def ignore_warnings(*args, **kwargs):
        pass

    warnings.filterwarnings('ignore')
    imageio.core.util._precision_warn = ignore_warnings


def shared_to_numpy(shared_arr, dtype, shape):
    """Get a NumPy array from a shared memory buffer, with a given dtype and shape.
    No copy is involved, the array reflects the underlying shared buffer."""
    return np.frombuffer(shared_arr, dtype=dtype).reshape(shape)


def create_shared_array(data, dtype, shape):
    """Create a new shared array. Return the shared array pointer, and a NumPy array view to it.
    Note that the buffer values are not initialized.
    """
    dtype = np.dtype(dtype)
    # Get a ctype type from the NumPy dtype.
    cdtype = np.ctypeslib.as_ctypes_type(dtype)
    # Create the RawArray instance.
    shared_arr = mp.RawArray(cdtype, int(np.prod(shape)))
    # Get a NumPy array view.
    np_arr = shared_to_numpy(shared_arr, dtype, shape)
    # Copy data to our shared array.
    np.copyto(np_arr, data)
    # np_arr.flat[:] = data
    return shared_arr


def create_shared_multiprocessing_name_space_object(args):
    """https://github.com/prickly-pythons/prickly-pythons/issues/14
    [HowTo] Shared data in multiprocessing with Manager.Namespace()

    https://stackoverflow.com/questions/2597278/python-load-variables-in-a-dict-into-namespace
    https://www.programiz.com/python-programming/methods/built-in/setattr
    """
    # Create manager object in module-level namespace
    mgr = mp.Manager()
    # Then create a container of things that you want to share to processes as Manager.Namespace() object.
    config = mgr.Namespace()
    # fill in the config shared-namespace object with normal name space object keys and values using a for loop
    args = vars(args)
    for key, value in args.items():
        setattr(config, key, value)
    return config


parser = argparse.ArgumentParser(description='Cell-paint')
parser.add_argument('--testing', type=bool, default=True,
                    help='whether the any .py file is to be executed in test mode for debugging,'
                         'or is already debugged and can be run using multiproccessing pool for speed up.')
parser.add_argument('--show_intermediate_steps', type=bool, default=True,
                    help='whether to visualize intermediate steps for debugging purposes.')
parser.add_argument('--rescale_image', type=bool, default=False,
                    help='whether to rescale the image for better visualization.')
parser.add_argument('--main_path', type=Union[WindowsPath, PosixPath, str],
                    default=WindowsPath(r"F:\CellPainting"),
                    # default=WindowsPath(r"P:\\tmp\\pankaj"),
                    help="full path to the folder where all the experiment images and metadata are stored.")
parser.add_argument('--experiment', type=str, help='name of the experiment folder')
parser.add_argument('--lab', type=str, help='name of the lab that took the images: ibt or baylor or other')
# these indices change depending on the lab that took the images:
# the order of the channel for images taken by fabio at baylor is as follows:
# w1: Nucleus channel, w2: cyto channel, w3: nucleoli channel, w4: actin channel, w5: mito channel
parser.add_argument('--nucleus_idx', type=int, default=0, help='Nucleus channel index in the tif image(~w1)')
parser.add_argument('--cyto_idx', type=int, default=1, help='Cyto channel index in the tif image(~w2)')
parser.add_argument('--nucleoli_idx', type=int, default=2, help='Nucleoli channel index in the tif image(~w3)')
parser.add_argument('--actin_idx', type=int, default=3, help='Actin channel index in the tif image(~w4)')
parser.add_argument('--mito_idx', type=int, default=4, help='Mito channel index in the tif image(~w5)')
parser.add_argument('--name_cut_off_index', type=int, default=8,
                    help='treatment name cut-off index when treatment name is too long!')
############################################################################################################
# cellpose segmentation hyperparameters
parser.add_argument('--batch_size', type=int, default=64,
                    help='# of 224x224 blocks used to learn/extract the mask from nuclues/cyto using cellpose')
parser.add_argument('--cellpose_nucleus_diam', type=int, default=100, help='estimated nucleus diam for cellpose')
parser.add_argument('--cellpose_cyto_diam', type=int, default=100, help='estimated cyto diam for cellpose')
###############################################################################################################
# nucleoli segmentation hyperparameters
parser.add_argument('--min_cell_count', type=int, default=4,
                    help='minimum number of cells detected by (cellpose) segmentation, otherwise skip the image!')
parser.add_argument('--min_nucleus_size', type=int, default=1500,
                    help='minimum nucleus mask area (number of segmented pixels) '
                         'to keep it for the feature extraction stage'
                         ', otherwise we remove that cell from the analysis.')
parser.add_argument('--min_cyto_size', type=int, default=2200,
                    help='minimum cytoplasm mask area to keep it for the feature extraction stage'
                         ', otherwise we remove that cell from the analysis.')
# parser.add_argument('--min_nucleoli_size', type=int, default=50,
#                     help='minimum number of nucleoli pixels detected by the segmentation to consider a nucleoli,'
#                          'otherwise we remove that cells nucleoli! segmentation and consider having no nucleoli.')
parser.add_argument('--nucleoli_channel_rescale_intensity_percentile_ub', type=float, default=99,
                    help='minimum number of nucleoli pixels detected by the segmentation to consider a nucleoli,'
                         'otherwise we remove that cells nucleoli! segmentation and consider having no nucleoli.')
parser.add_argument('--nucleoli_bd_area_to_nucleoli_area_threshold', type=float, default=.2,
                    help='minimum number of nucleoli pixels detected by the segmentation to consider a nucleoli,'
                         'otherwise we remove that cells nucleoli! segmentation and consider having no nucleoli.')
parser.add_argument('--min_nucleoli_size_multiplier', type=float, default=.005,
                    help='minimum number of nucleoli pixels detected by the segmentation to consider a nucleoli,'
                         'otherwise we remove that cells nucleoli! segmentation and consider having no nucleoli.')
parser.add_argument('--max_nucleoli_size_multiplier', type=float, default=.3,
                    help='minimum number of nucleoli pixels detected by the segmentation to consider a nucleoli,'
                         'otherwise we remove that cells nucleoli! segmentation and consider having no nucleoli.')
args = parser.parse_args()
if isinstance(args.main_path, str):
    args.main_path = WindowsPath(args.main_path)
###########################################################
# # Choose the CELLPAINT experiment
#######################################################################
# args.experiment = "others"
# args.experiment = "20220831-cellpainting-benchmarking-DRC_20220831_173200"
# args.experiment = "2022-0817-CP-benchmarking-density_20220817_120119"
# args.experiment = "20220714-Shelton-Exp03_20220714_132321"
############################################################################
if args.experiment == "2021-CP007" or args.experiment == "2021-CP008":
    args.channel_dies = {
        "C1": "DAPI",
        "C2": "ConA+Syto14",
        "C3": "WGA+Phalloidin",
        "C4": "MitoTracker"}
elif args.experiment == "others":
    "paper title: Morphological profiling of environmental chemicals enables efficient and"
    "untargeted exploration of combination effects"
    "paper journal: Science of the Total Environment"
    "Department of Pharmaceutical Biosciences and Science for Life Laboratory, Uppsala University, Sweden"
    # Fluorescence microscopy was conducted using a high throughput ImageXpressMicro XLS(Molecular Devices)
    # microscope with a 20×objective with laser - based autofocus.
    args.nucleus_idx = 0
    args.cyto_idx = 4
    args.nucleoli_idx = 3
    args.actin_idx = 2
    args.mito_idx = 1
    args.channel_dies = {
        "C1": "Hoechst",
        "C2": "MitoTracker",
        "C3": "WGA+Phalloidin",
        "C4": "Syto14",
        "C5": "Concanavalin A", }
    args.cellpose_nucleus_diam = 80
    args.nucleoli_channel_rescale_intensity_percentile_ub = 99.8
    args.nucleoli_bd_area_to_nucleoli_area_threshold = .21
    args.min_nucleoli_size_multiplier = .001
    args.max_nucleoli_size_multiplier = .5
else:
    args.channel_dies = {
        "C1": "DAPI",  # nucleus
        "C2": "Concanavalin A",  # cyto
        "C3": "Syto14", # nucleoli
        "C4": "WGA+Phalloidin",  # actin
        "C5": "MitoTracker"}  # mito
######################################################################
# fullpath to the folder where cellpose masks are saved
args.cellpose_masks_path = args.main_path / args.experiment / "Masks_Cellpose"
# fullpath to the folder where, after refining the initial cellpose masks,
# the final dapi, cyto, nucleoli, and mito masks are saved
args.final_masks_path = LOAD_PATH = args.main_path / args.experiment / "Masks"
args.cellpose_masks_path.mkdir(exist_ok=True, parents=True)
args.final_masks_path.mkdir(exist_ok=True, parents=True)
##############################################################################################
args.colors = [
    "red", "green", "blue", "orange", "purple", "lightgreen", "yellow", "pink", "gray",
    "khaki", "lime", "olivedrab", "azure", "orchid", "darkslategray",
    "peru", "lightgray", "tan"]
args.csfont = {'fontname': 'Comic Sans MS', 'fontsize': 16}
####################################################################################################################
# get metadata info from plate_map
if args.experiment in \
        [
            "20220912-CP-Bolt_20220912_153142",
            "20220909-CP-231-PANC1-epigenetic-benchmarks_20220909_114050",
            "20220908-CP-benchmark-DRC-replicate2_20220908_142836",
            "20220831-cellpainting-benchmarking-DRC_20220831_173200",
            "2022-0817-CP-benchmarking-density_20220817_120119",
            "2022-0810-CP-benchmarking-WGArestain_20220810_121628",
        ]:
    if args.experiment == "20220912-CP-Bolt_20220912_153142":
        args.expid = "2022-09-12-CP-Bolt"
    if args.experiment == "20220908-CP-benchmark-DRC-replicate2_20220908_142836":
        args.expid = "2022-09-09-CP-PNC1-EPI"
    elif args.experiment == "20220908-CP-benchmark-DRC-replicate2_20220908_142836":
        args.expid = "2022-09-08-CP-BM-DRC2"
    elif args.experiment == "20220831-cellpainting-benchmarking-DRC_20220831_173200":
        args.expid = "2022-08-31-CP-BM-DRC"
    elif args.experiment == "2022-0817-CP-benchmarking-density_20220817_120119":
        args.expid = "2022-08-17-CP-BM-density"
    elif args.experiment == "2022-0810-CP-benchmarking-WGArestain_20220810_121628":
        args.expid = "2022-08-10-CP-BM-WGA-restain"

    if args.experiment == "20220912-CP-Bolt_20220912_153142":
        args.lab = "ibt"
        args.img_folder = "AssayPlate_Greiner_#781896"
        args.plate_protocol = "Greiner"
    else:
        args.lab = "baylor"
        args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
        args.plate_protocol = "PerkinElmer"

    args.wellid2treatment = get_wellid2meta("platemap.xlsx", sheetname="Compound")
    args.wellid2cellline = get_wellid2meta("platemap.xlsx", sheetname="CellLine")
    args.wellid2density = get_wellid2meta("platemap.xlsx", sheetname="Density")
    args.wellid2dosage = get_wellid2meta("platemap.xlsx", sheetname="Dosage")
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = list(np.unique(list(args.wellid2treatment.values())))
    args.celllines = list(np.unique(list(args.wellid2cellline.values())))
    if args.wellid2density is None:
        args.wellid2density = {key: 0 for key in args.wellid2treatment.keys()}
        args.densities = [0]
    else:
        args.densities = list(np.unique(list(args.wellid2density.values())))
    if args.wellid2dosage is None:
        args.wellid2dosage = {key: 0 for key in args.wellid2treatment.keys()}
        args.dosages = [0]
    else:
        args.dosages = list(np.unique(list(args.wellid2dosage.values())))
    # print(args.densities)
    # print(args.dosages)
    # print(args.celllines)

elif args.experiment == "20220607-U2OS-density-5channel_20220607_135315":
    def get_wellid2treatment():
        platemap = pd.read_excel(
            args.main_path / args.experiment / "U2OS_Cell_Density-CellPaint-5channel-imaging.xlsx",
            sheet_name="Sheet1")
        wellid2treat = {}
        for ii in range(2, 12):
            row_id = platemap.iloc[ii]["Cell Density:"]
            for jj, item in enumerate(platemap.iloc[ii][1:]):
                if str(item) != "nan":
                    wellid2treat[f"{row_id}{str(jj + 1).zfill(2)}"] = str(item).rstrip(".0")
        return wellid2treat
    args.lab = "baylor"
    args.expid = "2022-06-07-U2OS-Density-BM"
    args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
    args.plate_protocol = "PerkinElmer"

    args.wellid2treatment = get_wellid2treatment()
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = list(np.unique(list(args.wellid2treatment.values())))
    args.celllines = ["U2OS"]
    args.wellid2cellline = {key: "U2OS" for key in args.wellid2treatment.keys()}
    args.wellid2dosage = {key: "N/A" for key in args.wellid2treatment.keys()}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))

elif args.experiment == "20220603-Shelton-PC3-CP_20220603_151615":
    def get_wellid2treatment():
        platemap = pd.read_excel(
            args.main_path / args.experiment / "Shelton_platemaps.xlsx", sheet_name="060122")
        wellid2treat = {}
        for ii in range(2, len(platemap) - 4):
            row_id = platemap.iloc[ii]["Shelton Boyd/Damien Young"]
            for jj, item in enumerate(platemap.iloc[ii][2:]):
                if str(item) != "nan":
                    wellid2treat[f"{row_id}{str(jj + 1).zfill(2)}"] = str(item).lstrip().rstrip()
        return wellid2treat

    args.lab = "baylor"
    args.expid = "2022-06-03-Shelton-PC3"
    args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
    args.plate_protocol = "PerkinElmer"

    args.wellid2treatment = get_wellid2treatment()
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = list(np.unique(list(args.wellid2treatment.values())))
    args.celllines = ["PC3"]
    args.wellid2cellline = {key: "PC3" for key in args.wellid2treatment.keys()}
    args.wellid2dosage = {key: "N/A" for key in args.wellid2treatment.keys()}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))

elif args.experiment == "20220617-Shelton-exp2_20220617_110944":
    def get_wellid2treatment():
        platemap = pd.read_excel(
            args.main_path / args.experiment / "Shelton_platemaps.xlsx", sheet_name="061422")
        wellid2treat = {}
        for ii in range(2, len(platemap) - 4):
            row_id = platemap.iloc[ii]["Shelton Boyd/Damien Young"]
            for jj, item in enumerate(platemap.iloc[ii][2:]):
                if str(item) != "nan":
                    wellid2treat[f"{row_id}{str(jj + 1).zfill(2)}"] = str(item).lstrip().rstrip()
        return wellid2treat

    args.lab = "baylor"
    args.expid = "2022-06-17-Shelton-PC3-2"
    args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
    args.plate_protocol = "PerkinElmer"

    args.wellid2treatment = get_wellid2treatment()
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = list(np.unique(list(args.wellid2treatment.values())))
    args.celllines = ["PC3"]
    args.wellid2cellline = {key: "PC3" for key in args.wellid2treatment.keys()}
    args.wellid2dosage = {
        "A01": "10uM", "B01": "10uM", "C01": "10uM", "D01": "10uM", "E01": "10uM", "F01": "10uM",
        "A02": "1uM", "B02": "1uM", "C02": "1uM", "D02": "1uM", "E02": "1uM", "F02": "1uM",
        "A03": "100nM", "B03": "100nM", "C03": "100nM", "D03": "100nM", "E03": "100nM", "F03": "100nM",

        "A04": "10uM", "B04": "10uM", "C04": "10uM", "D04": "10uM", "E04": "10uM", "F04": "10uM",
        "A05": "1uM", "B05": "1uM", "C05": "1uM", "D05": "1uM", "E05": "1uM", "F05": "1uM",
        "A06": "100nM", "B06": "100nM", "C06": "100nM", "D06": "100nM", "E06": "100nM", "F06": "100nM",

        "A07": "10uM", "B07": "10uM", "C07": "10uM", "D07": "10uM", "E07": "10uM", "F07": "10uM",
        "A08": "1uM", "B08": "1uM", "C08": "1uM", "D08": "1uM", "E08": "1uM", "F08": "1uM",
        "A09": "100nM", "B09": "100nM", "C09": "100nM", "D09": "100nM", "E09": "100nM", "F09": "100nM",

        "A10": "10uM", "B10": "10uM", "C10": "10uM", "D10": "10uM", "E10": "10uM", "F10": "10uM",
        "A11": "1uM", "B11": "1uM", "C11": "1uM", "D11": "1uM", "E11": "1uM", "F11": "1uM",
        "A12": "100nM", "B12": "100nM", "C12": "100nM", "D12": "100nM", "E12": "100nM", "F12": "100nM",
        "G01": "N/A"}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))


elif args.experiment == "20220714-Shelton-Exp03_20220714_132321":
    def get_wellid2treatment():
        platemap = pd.read_excel(
            args.main_path / args.experiment / "Shelton_platemaps.xlsx", sheet_name="061422")
        wellid2treat = {}
        for ii in range(2, len(platemap) - 4):
            row_id = platemap.iloc[ii]["Shelton Boyd/Damien Young"]
            for jj, item in enumerate(platemap.iloc[ii][2:]):
                if str(item) != "nan":
                    wellid2treat[f"{row_id}{str(jj + 1).zfill(2)}"] = str(item).lstrip().rstrip()
        return wellid2treat

    args.lab = "baylor"
    args.expid = "2022-07-14-Shelton-PC3-3"
    args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
    args.plate_protocol = "PerkinElmer"

    args.cellpose_nucleus_diam = 80
    args.wellid2treatment = get_wellid2treatment()
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = list(np.unique(list(args.wellid2treatment.values())))
    args.celllines = ["PC3"]
    args.wellid2cellline = {key: "PC3" for key in args.wellid2treatment.keys()}
    args.wellid2dosage = {
        "A01": "10uM", "B01": "10uM", "C01": "10uM", "D01": "10uM", "E01": "10uM", "F01": "10uM",
        "A02": "1uM", "B02": "1uM", "C02": "1uM", "D02": "1uM", "E02": "1uM", "F02": "1uM",
        "A03": "100nM", "B03": "100nM", "C03": "100nM", "D03": "100nM", "E03": "100nM", "F03": "100nM",

        "A04": "10uM", "B04": "10uM", "C04": "10uM", "D04": "10uM", "E04": "10uM", "F04": "10uM",
        "A05": "1uM", "B05": "1uM", "C05": "1uM", "D05": "1uM", "E05": "1uM", "F05": "1uM",
        "A06": "100nM", "B06": "100nM", "C06": "100nM", "D06": "100nM", "E06": "100nM", "F06": "100nM",

        "A07": "10uM", "B07": "10uM", "C07": "10uM", "D07": "10uM", "E07": "10uM", "F07": "10uM",
        "A08": "1uM", "B08": "1uM", "C08": "1uM", "D08": "1uM", "E08": "1uM", "F08": "1uM",
        "A09": "100nM", "B09": "100nM", "C09": "100nM", "D09": "100nM", "E09": "100nM", "F09": "100nM",

        "A10": "10uM", "B10": "10uM", "C10": "10uM", "D10": "10uM", "E10": "10uM", "F10": "10uM",
        "A11": "1uM", "B11": "1uM", "C11": "1uM", "D11": "1uM", "E11": "1uM", "F11": "1uM",
        "A12": "100nM", "B12": "100nM", "C12": "100nM", "D12": "100nM", "E12": "100nM", "F12": "100nM",
        "G01": "N/A"}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))
elif args.experiment == "others":
    platemap = pd.read_csv(args.main_path / args.experiment / "platemap.csv")
    # for now we work only with U2OS
    platemap = platemap.loc[platemap["cellLine"] == "U2OS"]

    args.lab = "others"
    args.expid = "P000025-combchem-v3-U2OS-24h-L1-copy1"
    args.img_folder = "P000025-combchem-v3-U2OS-24h-L1-copy1"
    args.plate_protocol = "combchem"

    args.celllines = ["U2OS", ]
    args.wellids = np.unique(platemap["well_id"])

    platemap.loc[pd.isnull(platemap["treat_id"]), "treat_id"] = ""
    platemap.loc[platemap["pert_type"] == "blank", "pert_type"] = "media"

    platemap.loc[pd.isnull(platemap["cmpd_conc_uM"]), "cmpd_conc_uM"] = 0
    platemap["cmpd_conc_uM"] = platemap["cmpd_conc_uM"].astype(str)
    platemap.loc[pd.isnull(platemap["conc_units"]), "conc_units"] = "uM"

    platemap["all_treatments"] = platemap["pert_type"] + platemap["treat_id"]
    platemap["all_dosages"] = platemap["cmpd_conc_uM"] + platemap["conc_units"]
    args.treatments = np.unique(platemap["all_treatments"])
    args.treatments = ['media'] + list(np.unique([it.split("_")[0] for it in args.treatments[1:]]))
    args.dosages = np.unique(platemap["all_dosages"])
    args.densities = [0]

    args.wellid2treatment = {
        it: platemap.loc[platemap["well_id"] == it, "all_treatments"].values[0].split("_")[0]
        for it in platemap["well_id"]}
    args.wellid2dosage = {
        it: platemap.loc[platemap["well_id"] == it, "all_dosages"].values[0].split("_")[0]
        for it in platemap["well_id"]}
    args.wellid2cellline = {
        it: platemap.loc[platemap["well_id"] == it, "cellLine"].values[0].split("_")[0]
        for it in platemap["well_id"]}
    args.wellid2density = {it: 0 for it in platemap['well_id']}
    # for key, val in args.wellid2cellline.items():
    #     print(key, val)
    # print(args.wellid2treatment)

elif args.experiment == "2021-CP007":
    def get_wellid2treatment():
        platemap = pd.read_excel(args.main_path / args.experiment / "Compound_whole_Plate_Layout.xlsx",
                                 sheet_name="Sheet1")
        wellid2treat = {}
        for ii in range(2, len(platemap) - 2):
            row_id = platemap.iloc[ii]["Compound:"]
            for jj, item in enumerate(platemap.iloc[ii][1:]):
                wellid2treat[f"{row_id}{str(jj + 1).zfill(2)}"] = item.lstrip().rstrip()
        return wellid2treat

    args.lab = "baylor"
    args.expid = "2021-CP007"
    args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
    args.plate_protocol = "PerkinElmer"

    args.wellid2treatment = get_wellid2treatment()
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = np.unique(list(args.wellid2treatment.values()))
    # args.treatments = sorted([item[0:SHORT_INDEX] for item in np.unique(list(args.wellid2treatment.values()))])
    args.celllines = ["A549", "HELA", "JEG3", "SKBR-3"]
    CP007 = {"A": "SKBR-3", "B": "SKBR-3", "C": "SKBR-3", "D": "SKBR-3",
             "E": "A549", "F": "A549", "G": "A549", "H": "A549",
             "I": "HELA", "J": "HELA", "K": "HELA", "L": "HELA",
             "M": "JEG3", "N": "JEG3", "O": "JEG3", "P": "JEG3"}
    args.wellid2cellline = {key: CP007[key[0]] for key in args.wellid2treatment.keys()}
    args.wellid2dosage = {key: "N/A" for key in args.wellid2treatment.keys()}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))
elif args.experiment == "2021-CP008":
    def get_wellid2treatment():
        platemap = pd.read_excel(args.main_path / args.experiment / "Compound_whole_Plate_Layout.xlsx",
                                 sheet_name="Sheet1")
        wellid2treat = {}
        for ii in range(2, len(platemap) - 2):
            row_id = platemap.iloc[ii]["Compound:"]
            for jj, item in enumerate(platemap.iloc[ii][1:]):
                wellid2treat[f"{row_id}{str(jj + 1).zfill(2)}"] = item.lstrip().rstrip()
        return wellid2treat

    args.lab = "baylor"
    args.expid = "2021-CP008"
    args.img_folder = "AssayPlate_PerkinElmer_CellCarrier-384"
    args.plate_protocol = "PerkinElmer"

    args.wellid2treatment = get_wellid2treatment()
    args.wellids = list(np.unique(list(args.wellid2treatment.keys())))
    args.treatments = np.unique(list(args.wellid2treatment.values()))
    # args.treatments = sorted([item[0:SHORT_INDEX] for item in np.unique(list(args.wellid2treatment.values()))])
    args.celllines = ["HepG2", "PC3", "RT4", "U2OS"]
    CP008 = {"A": "HepG2", "B": "HepG2", "C": "HepG2", "D": "HepG2",
             "E": "PC3", "F": "PC3", "G": "PC3", "H": "PC3",
             "I": "RT4", "J": "RT4", "K": "RT4", "L": "RT4",
             "M": "U2OS", "N": "U2OS", "O": "U2OS", "P": "U2OS"}
    args.wellid2cellline = {key: CP008[key[0]] for key in args.wellid2treatment.keys()}
    args.wellid2dosage = {key: "N/A" for key in args.wellid2treatment.keys()}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))
elif args.experiment == "20220623-CAMII-Seema-cellpainting_20220623_101847":
    def get_wellid2treatment():
        platemap = pd.read_excel(
            args.main_path / args.experiment / "220621_HT29_Cellpaint_platelayout.xlsx", sheet_name="Sheet1")
        wellid2treat = {}
        wellid2celline = {}
        for it1, it2, it3, it4 in zip(platemap['Row'], platemap['Col'], platemap['Cell Line'], platemap['Treatment']):
            wellid2treat[f"{it1}{str(it2).zfill(2)}"] = str(it4).lstrip().rstrip()
            wellid2celline[f"{it1}{str(it2).zfill(2)}"] = str(it3).lstrip().rstrip()

        cellines = np.unique(list(wellid2celline.values()))
        treatments = np.unique(list(wellid2treat.values()))
        wellids = np.unique(list(wellid2treat.keys()))
        return wellid2treat, wellids, treatments, cellines, wellid2celline

    args.lab = "ibt"
    args.expid = "20220623-CAMII-Seema"
    args.img_folder = "AssayPlate_Greiner_#781091"
    args.plate_protocol = "Greiner"

    args.wellid2treatment, args.wellids, args.treatments, args.celllines, args.wellid2cellline = get_wellid2treatment()
    args.wellid2dosage = {key: "N/A" for key in args.wellid2treatment.keys()}
    args.dosages = list(np.unique(list(args.wellid2dosage.values())))
else:
    raise ValueError("Experiment not implemented!")
###################################################################################################################
# Get generic width and height dimensions of the image in the specific experiment
"""We assume args.height and args.width is the same for every single images, in the same experiment!!!"""
args.height, args.width = \
    tifffile.imread(list((args.main_path / args.experiment / args.img_folder).rglob('*.tif'))[0]).shape
########################################################################################################################
# bounding box feature names
args.bbox = ["bbox-y0", "bbox-x0", "bbox-y1", "bbox-x1"]
###################
# shape feature names
args.shape_keys = \
    ['area', 'convex_area', 'perimeter', 'perimeter-crofton', 'eccentricity', 'equivalent-diam',
     'extent', 'feret-diam-max', 'solidity', ]
#####################################################################################
# moment feature names
args.mnids = [2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
args.moment_keys = \
    [f'{mm}-{ii}' for mm in ['local_cent', 'w-local-cent', ] for ii in [0, 1]] + \
    [f"moments-n-{ii}" for ii in args.mnids] + \
    [f"moments-w-n-{ii}" for ii in args.mnids] + \
    [f"moments-hue-{ii}" for ii in range(0, 7)] + \
    [f"moments-w-hue-{ii}" for ii in range(0, 7)]
# "moments"
# "moments_central"
# "weighted_moments_central"
#########################################################################################################
# haralick feature names
args.haralick_keys = ['contrast', 'dissimilarity', 'homogeneity', 'asm', 'correlation']
args.intensity_thresh_lb = 0
args.intensity_thresh_ub = 30000
args.step = 500
args.intensity_level_thresholds = np.arange(args.intensity_thresh_lb, args.intensity_thresh_ub + 1, args.step)
# TODO: Use symbolic to get string values for np.pi and np.pi/2
args.angles = np.array([0, np.pi / 2], dtype=np.float32)
args.angles_name = ["0", "pi/2", ]
args.distances = np.arange(1, 20 + 1, 2)
args.haralick_keys = [
    f'{mm}-{ii}-{jj}' for mm in args.haralick_keys for jj in args.distances for ii in args.angles_name]
#################################################################################################
# extra intensity properties for skimage
args.intensity_percentiles = [25, 75, 90, 93, 95, 97, 99, 99.9]
args.intensity_keys = [f"{prc}%-intensity" for prc in args.intensity_percentiles] + \
                      ["median-intensity", "mad-intensity", "mean-intensity", "std-intensity"]
############################################################################################
# Column Names
args.metadata_cols = ["well-id", "treatment", "cell-line", "density", "dosage", "fov", ]
args.organelles = ["Nucleus", "Cyto", "Nucleoli", "Actin", "Mito"]

args.has_nucleoli = ["has_nucleoli"]
args.feature_cols = \
    args.bbox + \
    args.shape_keys + \
    args.moment_keys + \
    args.intensity_keys + \
    args.haralick_keys

args.num_organelles = len(args.organelles)
args.num_metadata_cols = len(args.metadata_cols)
args.num_feat_cols = len(args.feature_cols)

args.num_intensity_keys = len(args.intensity_keys)
args.num_haralick_keys = len(args.haralick_keys)
