import os
import time

import scipy.stats
from tqdm import tqdm

import numpy as np
import pandas as pd

from scipy import stats
from sklearn.preprocessing import minmax_scale, robust_scale

import seaborn as sns
import matplotlib.pyplot as plt

# from plotly import express as px
# from plotly.subplots import make_subplots
# import plotly.graph_objects as go

import multiprocessing as mp
from functools import partial

from utils.args import args, create_shared_multiprocessing_name_space_object

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
plt.rcParams['mathtext.default'] = 'regular'


def get_counts(features):
    temp_df = features["well-id"].value_counts().to_frame(name="cell count")
    temp_df.insert(loc=0, column="well-id", value=temp_df.index)
    # print(temp_df.head(5))
    # print(temp_df.shape, type(temp_df))
    temp_df.insert(loc=0, column="density", value=temp_df["well-id"].apply(lambda x: args.wellid2density[x]))
    temp_df.insert(loc=0, column="treatment", value=temp_df["well-id"].apply(lambda x: args.wellid2treat[x]))
    temp_df.to_csv(args.main_path/args.experiment/"features_cell_counts.csv")
    return temp_df


def drop_nan_cols(features, start_index=5):
    channels = np.array([x.split("-")[0] for x in features.columns[start_index:]], dtype=str)
    channels = channels[np.sort(np.unique(channels, return_index=True)[1])]
    cols2drop = [f"{cin}-moments_normalized-{ii}-{jj}"
                 for cin in channels
                 for ii in range(0, 2) for jj in range(0, 2)]
    cols2drop = [it for it in cols2drop if "-1-1" not in it]
    features.drop(cols2drop, axis=1, inplace=True)
    return features


def drop_numerically_unstable_cols(features, start_index):
    # check for numerical stability
    cols2drop = []
    # print(features.shape)
    for col in tqdm(features.columns[start_index:]):
        cond0 = (features[col].values > -1e-6)
        cond1 = (features[col].values < 1e-6)
        median = np.median(features[col].values)
        mad = scipy.stats.median_abs_deviation(features[col].values)
        # print(mad)
        if median < 1e-4:
            cols2drop.append(col)
        #     print(f"{col:50} {100*np.sum(cond)/len(features):.2f}")
        elif (100 * np.sum(cond0 & cond1) / len(features) > 10) or (np.abs(mad/median) < 1e-4):
            #         features.drop(col, axis=1, inplace=True)
            cols2drop.append(col)
        # else:
        #     features = features.loc[~(cond0 & cond1)]

    #     if np.sum(features[cond][col].values)>.1*len(features[col]):
    #         print(f"{col:50} {100*np.sum(cond)/len(features):.2f}")
    features.drop(cols2drop, axis=1, inplace=True)
    # print(features.shape)
    # for col in cols2drop:
    #     print(col)
    return features


def normalize_features(features, lb=2, ub=98, start_index=5):
    # normalize each feature
    feat_cols = list(features.columns[start_index:])
    features[feat_cols] = robust_scale(features[feat_cols].values, quantile_range=(lb, ub))
    # clip outlier values to -1 and 1
    features[feat_cols] = features[feat_cols].clip(lower=-1, upper=1)
    return features


def get_wass_dist(ii, wellids, features, dmso_df, start_index=6):
    cols = features.columns[start_index:]
    M = len(cols)
    mat_distrib_dist = np.zeros((M,), dtype=np.float32)
    mat_median_dist = np.zeros((M,), dtype=np.float32)
    mat_mean_dist = np.zeros((M,), dtype=np.float32)
    for jj in range(M):
        x = features.loc[(features["well-id"] == wellids[ii])][cols[jj]].values
        y = dmso_df[cols[jj]].values
        # print(x, y)
        sign = np.sign(np.median(x, axis=0) - np.median(y, axis=0))
        mat_distrib_dist[jj] = sign * stats.wasserstein_distance(x, y)
        mat_median_dist[jj] = np.median(x)
        mat_mean_dist[jj] = np.mean(x)
    return mat_distrib_dist, mat_median_dist, mat_mean_dist


def sort_fn(x, meta_col):
    """x = f"{treatment}_{meta_col_val}_{wid}_{num_cells}" """
    if meta_col == "dosage":
        return x.split("_")[0], float(x.split("_")[1][0:-2]), x.split("_")[2]
    elif meta_col == "density":
        return x.split("_")[0], float(x.split("_")[1][0:-1]), x.split("_")[2]


def main():
    ######################################################################################
    # start_index = 6
    # args.experiment = "2022-0817-CP-benchmarking-density_20220817_120119"
    # meta_col = "density"
    # meta_col_anchor_val = "2.5k"
    # anchor = "veh"
    # densities = sorted(list(np.unique(features['density'])), key=lambda x: float(x[0:-1]))
    # print(densities)
    ########################################################################################
    start_index = 7
    args.experiment = "others"
    meta_col = "dosage"
    meta_col_anchor_val = "1.0uM"
    anchor = 'negcon[dmso]'
    #######################################################################################
    # start_index = 7
    # args.experiment = "20220831-cellpainting-benchmarking-DRC_20220831_173200"
    # meta_col = "dosage"
    # meta_col_anchor_val = "0uM"
    # anchor = "veh"
    ########################################################################################
    # CASE 0) NORMALIZE ALL FEATURES TOGETHER, THEN CALCULATE ALL FEATURE MAPS TOGETHER
    cin = 4
    ##########################################################################################
    print(f"loading channel #{cin} features ...")
    s_time = time.time()
    features = pd.read_csv(args.main_path/args.experiment/"results"/f"w{cin}_features.csv")
    # print(features.shape)
    print(f"w{cin}_features csv file loading time in seconds: {time.time()-s_time}")
    features = features.loc[features["has nucleoli"] == 1]
    features = drop_numerically_unstable_cols(features, start_index=start_index)
    features = normalize_features(features, lb=2, ub=98, start_index=start_index)
    # only for DRC and others experiments
    features["dosage"] = features["dosage"].apply(lambda x: f"{x}uM" if x == 0 or x == "0" else x)
    # for col in features.columns:
    #     print(col)
    ##########################################################################################
    control_feats = features.loc[(features["treatment"] == anchor) & (features["dosage"] == meta_col_anchor_val)]
    treat_feats = features.loc[(features["treatment"] == "poscon[fen]") & (features["dosage"] == "6.45uM")]
    control_feats = control_feats["Mito-asm-0-11"]
    treat_feats = treat_feats["Mito-asm-0-11"]
    print(treat_feats.shape, control_feats.shape)

    fig, axes = plt.subplots(1, 1)
    fig.suptitle("Histogram of normalized values of \n Mito-asm-0-11 feature comparison")
    axes.hist(control_feats, color="blue", label=f"{anchor}_dosage={meta_col_anchor_val}", alpha=.5)
    axes.hist(treat_feats, color="red", label=f"poscon[fen]_dosage=6.45uM", alpha=.5)

    axes.vlines(x=np.mean(control_feats), ymin=0, ymax=300, linestyle='dashed', linewidth=2, color="black")
    axes.vlines(x=np.median(control_feats), ymin=0, ymax=300, linestyle='dashed', linewidth=2, color="black")

    axes.vlines(x=np.mean(treat_feats), ymin=0, ymax=300, linestyle='dashed', linewidth=2, color="black")
    axes.vlines(x=np.median(treat_feats), ymin=0, ymax=300, linestyle='dashed', linewidth=2, color="black")

    axes.text(np.mean(control_feats), -.04, f"control\nmean", va='top', ha='center',
              transform=axes.get_xaxis_transform(), size=9, )
    axes.text(np.median(control_feats), -.04, f"control\nmedian", va='top', ha='center',
              transform=axes.get_xaxis_transform(), size=9, )
    axes.text(np.mean(treat_feats), -.04, "treat\nmean", va='top', ha='center',
              transform=axes.get_xaxis_transform(), size=9, )
    axes.text(np.median(treat_feats), -.04, "treat\nmedian", va='top', ha='center',
              transform=axes.get_xaxis_transform(), size=9, )
    sign = np.sign(np.median(treat_feats, axis=0) - np.median(control_feats, axis=0))
    distance = sign * stats.wasserstein_distance(treat_feats, control_feats)

    axes.vlines(x=distance, ymin=0, ymax=300, linestyle='dashed', linewidth=2, color="black")
    axes.text(distance, -.04, "distibution\ndistance\n", va='top', ha='center',
              transform=axes.get_xaxis_transform(), size=9, )
    plt.legend()
    plt.show()


if __name__ == "__main__":
    args = create_shared_multiprocessing_name_space_object(args)
    main()
