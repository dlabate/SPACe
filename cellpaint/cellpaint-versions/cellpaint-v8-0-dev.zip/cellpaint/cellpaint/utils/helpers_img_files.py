import warnings
import imageio.core.util

import itertools

import tifffile
import numpy as np


class FoundItem(Exception):
    pass


def ignore_imgaeio_warning():

    def ignore_warnings(*args, **kwargs):
        pass

    warnings.filterwarnings('ignore')
    imageio.core.util._precision_warn = ignore_warnings


def sort_key_for_imgs(file_path, plate_protocol, sort_purpose):
    """
    Get sort key from the img filename.
    The function is used to sort image filenames for a specific experiment taken with a specific plate_protocol.
    """
    # plate_protocol = plate_protocol.lower()
    if plate_protocol == "greiner" or plate_protocol == "perkinelmer":
        """img filename example:
        .../AssayPlate_PerkinElmer_CellCarrier-384/AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif
        .../AssayPlate_Greiner_#781896/AssayPlate_Greiner_#781896_A04_T0001F001L01A01Z01C01.tif
        """

        folder = file_path.parents[1].stem  # "AssayPlate_PerkinElmer_CellCarrier-384"
        filename = file_path.stem  # AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif
        split = filename.split("_")
        well_id = split[-2]  # A02
        fkey = split[-1]  # T0001F001L01A01Z01C02
        inds = [fkey.index(ll, 0, len(fkey)) for ll in fkey if ll.isalpha()]
        inds.append(None)
        # print(inds)
        timestamp, fov, id2, x1, zslice, channel = \
            [fkey[inds[ii]:inds[ii + 1]] for ii in range(len(inds) - 1)]
        # print(well_id, parts)

    elif plate_protocol == "combchem":
        """img filename example:
        .../P000025-combchem-v3-U2OS-24h-L1-copy1/
        P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s5_w3C00578CF-AD4A-4A29-88AE-D2A2024F9A92.tif"""
        folder = file_path.parents[1].stem
        filename = file_path.stem
        split = filename.split("_")
        well_id = split[1]
        fov = split[2][1]
        channel = split[3][1]
        # print(well_id, parts)
    else:
        raise ValueError(f"{plate_protocol} is not implemented")

    if sort_purpose == "to_sort_channels":
        return folder, well_id, fov, channel

    elif sort_purpose == "to_group_channels":
        # print(folder, well_id, fov)
        return folder, well_id, fov

    elif sort_purpose == "to_match_it_with_mask_path":
        return f"{well_id}_{fov}"
    elif sort_purpose == "to_get_well_id":
        return well_id
    elif sort_purpose == "to_get_well_id_and_fov":
        return well_id, fov
    else:
        raise ValueError(f"sort purpose {sort_purpose} does not exist!!!")


def sort_key_for_masks(mask_path):
    """example: .../w0_A02_F001.png"""
    split = mask_path.stem.split("_")
    well_id = split[-2]
    fov = split[-1]
    return f"{well_id}_{fov}"


def get_img_paths(main_path, experiment, plate_protocol):
    """AssayPlate_Greiner_#781896_A04_T0001F001L01A01Z01C01"""
    """AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tif"""
    """P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s5_w3C00578CF-AD4A-4A29-88AE-D2A2024F9A92.tif"""

    img_paths = list((main_path / experiment).rglob("*.tif"))
    if plate_protocol.lower() in ['greiner', 'perkinelmer']:
        # sometimes there are other tif files in the experiment folder that are not an image, so we have to
        # remove them from img_paths, so that they do not mess-up the analysis.
        img_paths = [item for item in img_paths if item.stem.split("_")[-1][0:5] == "T0001"]
    img_paths = sorted(
        img_paths,
        key=lambda x: sort_key_for_imgs(x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))
    return img_paths


def get_all_file_paths(
        main_path, experiement, analysis_save_path,
        plate_protocol="PerkinElmer", mask_folder="MasksP1", nucleus_idx=0, cyto_idx=1):
    img_paths = get_img_paths(main_path, experiement, plate_protocol)
    # print(nucleus_idx, cyto_idx, analysis_save_path / mask_folder)
    mask0_paths = list((analysis_save_path / mask_folder).rglob(f"w{nucleus_idx}_*.png"))  # Nucleus Masks
    mask1_paths = list((analysis_save_path / mask_folder).rglob(f"w{cyto_idx}_*.png"))  # Cytoplasm Masks
    # print(len(img_paths), len(mask0_paths), len(mask1_paths))
    mask0_paths = sorted(mask0_paths, key=sort_key_for_masks)
    mask1_paths = sorted(mask1_paths, key=sort_key_for_masks)

    #  grouping channels of each image together!
    keys, img_path_groups = [], []
    for item in itertools.groupby(
            img_paths, key=lambda x: sort_key_for_imgs(
                x, plate_protocol=plate_protocol, sort_purpose="to_group_channels")):
        keys.append(item[0])
        img_path_groups.append(list(item[1]))
    num_channels = len(img_path_groups[0])

    # making sure there is a one-to-one correspondence/matching between img_paths, mask0_paths, and mask1_paths.
    for it0, it1, it2 in zip(mask0_paths, mask1_paths, keys):
        split0, split1 = it0.stem.split("_"), it1.stem.split("_")
        assert "_".join(split0[-2:]) == "_".join(split0[-2:]) == "_".join(it2[1:])
    # img_path_groups = np.vstack(img_path_groups)
    return img_path_groups, mask0_paths, mask1_paths, num_channels


def remove_img_path_groups_with_no_masks(
        main_path, experiement, analysis_save_path,
        plate_protocol="PerkinElmer", mask_folder="MasksP1", nucleus_idx=0, cyto_idx=1):
    """In segmentation_step1 some of the images does to have enough cells
    ((#cells in w0_mask + #cells in w1_mask)//2 < args.min_cell_count),
    and therefore have to be remove, at the beginning of  segmentation_step2.

    Similarly, In segmentation_step2 some of the images does to have enough cells (#cells < args.min_cell_count),
    and therefore have to be remove, at the beginning of  feature extraction step.

    This function ensures a one-to-one correspondence/matching between:
     img_paths, mask0_paths, and mask1_paths at the start of segmentation_step2, and
     img_paths, mask0_paths, mask1_paths, mask2_paths, and mask4_paths at the start of feature extraction step.
    """

    img_paths = get_img_paths(main_path, experiement, plate_protocol)
    # print(nucleus_idx, cyto_idx, analysis_save_path / mask_folder)
    mask0_paths = list((analysis_save_path / mask_folder).rglob(f"w{nucleus_idx}_*.png"))  # Nucleus Masks
    mask1_paths = list((analysis_save_path / mask_folder).rglob(f"w{cyto_idx}_*.png"))  # Cytoplasm Masks
    # print(len(img_paths), len(mask0_paths), len(mask1_paths))
    mask_paths_keys = [sort_key_for_masks(it) for it in mask0_paths]
    # print(len(mask_paths_keys))
    assert len(mask_paths_keys) == len(np.unique(mask_paths_keys))
    # # through away image paths for which is no mask path file.
    img_paths = sorted(
        list(filter(
            lambda x: sort_key_for_imgs(x, plate_protocol, "to_match_it_with_mask_path") in mask_paths_keys,
            img_paths)),
        key=lambda x: sort_key_for_imgs(x, plate_protocol=plate_protocol, sort_purpose="to_sort_channels"))
    mask0_paths = sorted(mask0_paths, key=sort_key_for_masks)
    mask1_paths = sorted(mask1_paths, key=sort_key_for_masks)

    #  grouping channels of each image together!
    keys, img_path_groups = [], []
    for item in itertools.groupby(
            img_paths, key=lambda x: sort_key_for_imgs(
                x, plate_protocol=plate_protocol, sort_purpose="to_group_channels")):
        keys.append(item[0])
        img_path_groups.append(list(item[1]))
    num_channels = len(img_path_groups[0])

    # making sure there is a one-to-one correspondence/matching between img_paths, mask0_paths, and mask1_paths.
    for it0, it1, it2 in zip(mask0_paths, mask1_paths, keys):
        split0, split1 = it0.stem.split("_"), it1.stem.split("_")
        assert "_".join(split0[-2:]) == "_".join(split0[-2:]) == "_".join(it2[1:])
    # img_path_groups = np.vstack(img_path_groups)
    return img_path_groups, mask0_paths, mask1_paths, num_channels


def load_img(file_paths, num_channels, height, width):
    """load channel tiff files belonging to a single image into a single tiff file.
    file_paths: list of channel tiff files
    example:
    [.../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C01.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C02.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C03.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C04.tiff,
     .../AssayPlate_PerkinElmer_CellCarrier-384_A02_T0001F001L01A01Z01C05.tiff,]
     num_channels: The number of channels contained in the image,
     height: height of each image (It is always fixed for a single experiment.),
     width: width of each image (It is always fixed for a single experiment.),
    """
    assert len(file_paths) == num_channels
    img = np.zeros((num_channels, height, width), dtype=np.float32)
    for jj in range(num_channels):
        img[jj] = tifffile.imread(file_paths[jj])
    # for jj, fp in enumerate(fil_paths):
    #     img[jj] = tifffile.imread(fp)
    return img


def find_first_occurance(string_list, substring):
    N = len(string_list)
    for ii in range(N):
        if substring in string_list[ii]:
            return ii


def unique_with_preservered_order(mylist):
    a = np.array(mylist)
    _, idx = np.unique(a, return_index=True)
    return a[np.sort(idx)]



