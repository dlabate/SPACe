import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
import matplotlib.pyplot as plt

# main_path = r"F:\CellPainting\20230119-CP-Fabio-QCcelllines-EXP01"
# # fn = "dmso_AUCMap_l1_6_skbr3"
# fn = "dmso_AUCMap_l1_8_u2os"
#
# df = pd.read_csv(f"{main_path}/QC/{fn}.csv", index_col=0)
# clf = IsolationForest(random_state=100, max_features=10).fit(
#     df.to_numpy()[:, 1:], sample_weight=df.to_numpy()[:, 0])
# num_labels = clf.predict(df.to_numpy()[:, 1:])
# for it in zip(df.index, num_labels):
#     print(it[0], it[1])

# line_styles = ["-", "--"]
# markers = [",", "o", "*"]
# colors = list(plt.cm.tab10(np.linspace(0, 1, 10))) + ["black"]
# # colors = ["red", "green", "blue", "orange", "purple", "pink", "gray", "black"]
# markersize = 6
# triplets = [(it0, it1, it2) for it0 in line_styles for it1 in markers for it2 in colors]
#
# for it in triplets:
#     print(it[0], it[1], it[2])


# x = np.arange(0,4*np.pi, 0.1)   # start,stop,step
# y = np.sin(x)
#
# plt.plot(x, y, marker=",", markersize=8)
# plt.show()


x = np.random.randint(0, 5, (4, ))
y = np.random.randint(0, 5, (4, ))
z = np.vstack((x, y)).T
print(z.shape)

# print(x)
# print(np.where(x>2))
# print(x>2)
# print(x[x>2])

# print(np.mean(x, axis=0).shape)
# print(np.mean(x, axis=1).shape)

