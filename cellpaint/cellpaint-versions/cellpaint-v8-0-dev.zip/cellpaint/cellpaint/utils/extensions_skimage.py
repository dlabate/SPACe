import numpy as np
from scipy import ndimage as ndi
from scipy.stats import median_abs_deviation

from skimage.measure import _moments, find_contours
from skimage.measure._regionprops import RegionProperties, _cached, only2d
from skimage.feature import graycomatrix
from skimage.segmentation import find_boundaries
from pyefd import elliptic_fourier_descriptors


def safe_log_10_v0(value):
    """https://stackoverflow.com/questions/21610198/runtimewarning-divide-by-zero-encountered-in-log"""
    value = np.abs(value)
    result = np.where(value > 1e-12, value, -12)
    # print(result)
    res = np.log10(result, out=result, where=result > 1e-12)
    return res


def safe_log_10_v1(value):
    """Pankaj"""
    return -np.log(1+np.abs(value))


def discretize_intensity_global(img, intensity_level_thresholds):
    """Assuming Img is a 2d/3d numpy array, here img refers to the entire field of view"""
    # every intensity value about the intensity_level_thresholds[-1] will be set to intensity_level_thresholds[-1]
    # discrete_img = np.clip(img, None, intensity_level_thresholds[-1]).astype(np.uint8)
    discrete_img = np.zeros(img.shape, dtype=np.uint8)
    num_levels = len(intensity_level_thresholds)
    # print("num levels inside discrete global", num_levels)
    for ii in range(1, num_levels):
        # i0 = intensity_level_thresholds[ii - 1]
        # i2 = intensity_level_thresholds[ii]
        # chopping the image
        # discrete_img[(i0 <= img) & (img < i1)] = ii
        # discrete_img += ((i0 <= img) * (img < i1) * (ii - 1)).astype(np.uint8)
        #########################################################################
        # # round clipping the image
        # i1 = i0 + (i2 - i0) // 2
        # discrete_img[(i0 <= img) & (img < i1)] = ii - 1
        # discrete_img[(i1 <= img) & (img < i2)] = ii
        ###################################
        # hard clipping (chopping) the image
        discrete_img[(intensity_level_thresholds[ii - 1] <= img) &
                     (img < intensity_level_thresholds[ii])] = ii-1
    discrete_img[img == intensity_level_thresholds[-1]] = num_levels-1

    return discrete_img


def discretize_intensity_local(img, num_levels=8):
    """
    Assuming Img is a 2d/3d numpy array, here img refers an object within a bounding box
    within a field of view."""
    min_ = np.amin(img)
    max_ = np.max(img)
    levels = np.linspace(min_, max_, num_levels)
    discrete_img = np.zeros(img.shape, dtype=np.uint8)
    # print("num levels inside discrete local", num_levels)
    for ii in range(1, num_levels):
        # i0 = levels[ii - 1]
        # i2 = levels[ii]
        # chop clipping the image
        # discrete_img[(i0 <= img) & (img < i1)] = ii
        # discrete_img += ((i0 <= img) * (img < i1) * (ii - 1)).astype(np.uint8)
        #########################################################################
        # # round clipping the image
        # i1 = i0 + (i2 - i0) // 2
        # discrete_img[(i0 <= img) & (img < i1)] = ii - 1
        # discrete_img[(i1 <= img) & (img < i2)] = ii
        # ###################################
        # hard clipping (chopping) the image
        discrete_img[(levels[ii-1] <= img) & (img < levels[ii])] = ii-1
    discrete_img[img == max_] = num_levels-1
    return discrete_img


def regionprops(w0_mask, w1_mask, w2_mask, w4_mask, img,
                num_discrete_levels, intensity_percentiles, distances, angles, ):
    N = len(np.unique(w0_mask)) - 1
    regions = np.zeros((5, N), dtype=object)
    has_nucleoli = np.zeros((N, 1), dtype=np.uint8)

    max_ = np.amax(w0_mask)
    w0_objects = ndi.find_objects(w0_mask, max_label=max_)
    w1_objects = ndi.find_objects(w1_mask, max_label=max_)
    w2_objects = ndi.find_objects(w2_mask, max_label=max_)
    w4_objects = ndi.find_objects(w4_mask, max_label=max_)
    cnt = 0
    for ii in range(max_):
        if w0_objects[ii] is None:
            continue
        label = ii + 1
        w0_props = RegionPropertiesExtension(
            w0_objects[ii], label, w0_mask, img[0],
            num_discrete_levels, intensity_percentiles, distances, angles, )
        w1_props = RegionPropertiesExtension(
            w1_objects[ii], label, w1_mask, img[1],
            num_discrete_levels, intensity_percentiles, distances, angles, )
        w3_props = RegionPropertiesExtension(
            w1_objects[ii], label, w1_mask, img[3],
            num_discrete_levels, intensity_percentiles, distances, angles, )
        w4_props = RegionPropertiesExtension(
            w4_objects[ii], label, w4_mask, img[4],
            num_discrete_levels, intensity_percentiles, distances, angles, )
        if w2_objects[ii] is not None:
            w2_props = RegionPropertiesExtension(
                w2_objects[ii], label, w2_mask, img[2],
                num_discrete_levels, intensity_percentiles, distances, angles, )
            has_nucleoli[cnt] = 1
        else:
            w2_props = None
            has_nucleoli[cnt] = 0

        regions[0, cnt] = w0_props
        regions[1, cnt] = w1_props
        regions[2, cnt] = w2_props
        regions[3, cnt] = w3_props
        regions[4, cnt] = w4_props

        cnt += 1

    return regions, has_nucleoli


class RegionPropertiesExtension(RegionProperties):
    """Please refer to `skimage.measure.regionprops` for more information
    on the available region properties.
    """
    ndim = 2
    bd_val = 10
    bd_padding = [(bd_val, bd_val), (bd_val, bd_val)]

    def __init__(self, slice, label, label_image,
                 intensity_image, num_discrete_levels, distances, angles,
                 intensity_percentiles,
                 cache_active=True, ):
        super().__init__(slice, label, label_image, intensity_image, cache_active)

        self.intensity_percentiles = intensity_percentiles

        # The number of levels found within an image may not be the same as
        # the total number of globally available levels predefined/preset by us.
        # Therefore we must pass the number of globally available levels
        # as an argument to the class.
        ##################################################################
        # This is the wrong way!!!
        # As it will depend on the number of levels within a single image!!!
        # self.num_discrete_levels = np.amax(self._intensity_image_discrete) + 1
        #################################################################
        # This is the correct way!!!
        # As the number of levels is set independant of the image!!!
        # print("num levels inside the class ... ", num_discrete_levels)
        self.num_discrete_levels = num_discrete_levels
        self.distances = distances
        self.angles = angles

    @property
    @_cached
    def image_intensity_discrete_local(self):
        # if self._intensity_image_discrete is None:
        #     raise AttributeError('No intensity image specified.')
        # print("image_intensity_discrete_local shape:", self.image_intensity.shape)
        return discretize_intensity_local(self.image_intensity, self.num_discrete_levels)

    @property
    @only2d
    @_cached
    def moments_hu(self):
        mh = _moments.moments_hu(self.moments_normalized)
        return -1 * np.sign(mh) * safe_log_10_v0(mh)

    @property
    @only2d
    @_cached
    def moments_weighted_hu(self):
        # nu = self.moments_weighted_normalized
        mhw = _moments.moments_hu(self.moments_weighted_normalized)
        return -1 * np.sign(mhw) * safe_log_10_v0(mhw)

    @property
    @_cached
    def moments_weighted_normalized(self):
        # mu = self.moments_weighted_central
        mwn = _moments.moments_normalized(self.moments_weighted_central, order=3)
        # print("mwn")
        # print(mwn)
        # print("Stackoverflow", -1 * np.sign(mwn) * safe_log_10_v0(mwn))
        # print('\n')
        return -1 * np.sign(mwn) * safe_log_10_v0(mwn)

    @property
    @_cached
    def image_intensity_vec(self):
        return self.image_intensity[self.image_intensity > 0]

    @property
    @_cached
    def intensity_statistics(self, ):
        percentiles = np.percentile(self.image_intensity_vec, self.intensity_percentiles)
        intensity_median, intensity_mad, intensity_mean, intensity_std = \
            np.median(self.image_intensity_vec), median_abs_deviation(self.image_intensity_vec), \
            np.mean(self.image_intensity_vec), np.std(self.image_intensity_vec)
        return tuple(percentiles) + (intensity_median, intensity_mad, intensity_mean, intensity_std,)

    @property
    @_cached
    def gmat(self, ):  # gray-comatrix
        # remove level-zero (pixels with value zero identify the background and have to be removed from the analysis)
        P = graycomatrix(
            self.image_intensity_discrete_local,
            distances=self.distances,
            angles=self.angles,
            levels=self.num_discrete_levels,
            symmetric=False, normed=False)[1:, 1:]
        # normalize each GLCM
        P = P.astype(np.float32)
        glcm_sums = np.sum(P, axis=(0, 1), keepdims=True)
        glcm_sums[glcm_sums == 0] = 1
        P /= glcm_sums
        return P

    @property
    @_cached
    def haralicks(self,):
        """
        Calculate texture properties of a GLCM.
        Compute a feature of a gray level co-occurrence matrix to serve as
        a compact summary of the matrix. The properties are computed as
        follows:
        - 'contrast': :math:`\\sum_{i,j=0}^{levels-1} P_{i,j}(i-j)^2`
        - 'dissimilarity': :math:`\\sum_{i,j=0}^{levels-1}P_{i,j}|i-j|`
        - 'homogeneity': :math:`\\sum_{i,j=0}^{levels-1}\\frac{P_{i,j}}{1+(i-j)^2}`
        - 'ASM': :math:`\\sum_{i,j=0}^{levels-1} P_{i,j}^2`
        - 'energy': :math:`\\sqrt{ASM}`
        - 'correlation':
            .. math:: \\sum_{i,j=0}^{levels-1} P_{i,j}\\left[\\frac{(i-\\mu_i) \\
                      (j-\\mu_j)}{\\sqrt{(\\sigma_i^2)(\\sigma_j^2)}}\\right]
        Each GLCM is normalized to have a sum of 1 before the computation of
        texture properties.
        .. versionchanged:: 0.19
               `greycoprops` was renamed to `graycoprops` in 0.19.
        Parameters
        ----------
        P : ndarray
            Input array. `P` is the gray-level co-occurrence histogram
            for which to compute the specified property. The value
            `P[i,j,d,theta]` is the number of times that gray-level j
            occurs at a distance d and at an angle theta from
            gray-level i.
        prop : {'contrast', 'dissimilarity', 'homogeneity', 'energy', \
                'correlation', 'ASM'}, optional
            The property of the GLCM to compute. The default is 'contrast'.
        Returns
        -------
        results : 2-D ndarray
            2-dimensional array. `results[d, a]` is the property 'prop' for
            the d'th distance and the a'th angle.
        References
        ----------
        .. [1] M. Hall-Beyer, 2007. GLCM Texture: A Tutorial v. 1.0 through 3.0.
               The GLCM Tutorial Home Page,
               https://prism.ucalgary.ca/handle/1880/51900
               DOI:`10.11575/PRISM/33280`
        Examples
        --------
        Compute the contrast for GLCMs with distances [1, 2] and angles
        [0 degrees, 90 degrees]
        >>> image = np.array([[0, 0, 1, 1],
        ...                   [0, 0, 1, 1],
        ...                   [0, 2, 2, 2],
        ...                   [2, 2, 3, 3]], dtype=np.uint8)
        >>> g = graycomatrix(image, [1, 2], [0, np.pi/2], levels=4,
        ...                  normed=True, symmetric=True)
        """
        # print(gmat.shape)
        (num_level, num_level2, num_dist, num_angle) = self.gmat.shape

        # there is no need for these checks as I already know the matrix is in correct shape!!!
        # if num_level != num_level2:
        #     raise ValueError('num_level and num_level2 must be equal.')
        # if num_dist <= 0:
        #     raise ValueError('num_dist must be positive.')
        # if num_angle <= 0:
        #     raise ValueError('num_angle must be positive.')
        ##############################################
        ####################################
        # create weights for specified property
        I, J = np.ogrid[0:num_level, 0:num_level]
        ###############################
        # contrast
        weights0 = (I - J) ** 2
        weights0 = weights0.reshape((num_level, num_level, 1, 1))
        contrast = np.sum(self.gmat * weights0, axis=(0, 1))
        # dissimilarity
        weights1 = np.abs(I - J)
        weights1 = weights1.reshape((num_level, num_level, 1, 1))
        dissimilarity = np.sum(self.gmat * weights1, axis=(0, 1))
        # homogeneity
        weights2 = 1. / (1. + (I - J) ** 2)
        weights2 = weights2.reshape((num_level, num_level, 1, 1))
        homogeneity = np.sum(self.gmat * weights2, axis=(0, 1))
        ###################################################
        # asm and energy
        asm = np.sum(self.gmat ** 2, axis=(0, 1))
        # energy = np.sqrt(asm)
        ##############################################
        # correlation
        correlation = np.zeros((num_dist, num_angle), dtype=np.float64)
        I = np.array(range(num_level)).reshape((num_level, 1, 1, 1))
        J = np.array(range(num_level)).reshape((1, num_level, 1, 1))
        diff_i = I - np.sum(I * self.gmat, axis=(0, 1))
        diff_j = J - np.sum(J * self.gmat, axis=(0, 1))
        std_i = np.sqrt(np.sum(self.gmat * (diff_i ** 2), axis=(0, 1)))
        std_j = np.sqrt(np.sum(self.gmat * (diff_j ** 2), axis=(0, 1)))
        cov = np.sum(self.gmat * (diff_i * diff_j), axis=(0, 1))
        # handle the special case of standard deviations near zero
        mask_0 = std_i < 1e-15
        mask_0[std_j < 1e-15] = True
        correlation[mask_0] = 1
        # handle the standard case
        mask_1 = ~mask_0
        correlation[mask_1] = cov[mask_1] / (std_i[mask_1] * std_j[mask_1])
        ###############################################
        # haralick_features = np.vstack((contrast, dissimilarity, homogeneity, asm, correlation)).reshape(-1)
        # return haralick_features
        #######################################################
        # If summary of these features is preferable because of redundancy
        # print("contrast:", contrast.shape)
        # print(
        # np.median(contrast, axis=0).shape,
        # median_abs_deviation(contrast, axis=0).shape)

        haralick_features = np.vstack([
            np.median(contrast, axis=0),
            median_abs_deviation(contrast, axis=0),

            np.median(dissimilarity, axis=0),
            median_abs_deviation(dissimilarity, axis=0),

            np.median(homogeneity, axis=0),
            median_abs_deviation(homogeneity, axis=0),

            np.median(asm, axis=0),
            median_abs_deviation(asm, axis=0),

            np.median(correlation, axis=0),
            median_abs_deviation(correlation, axis=0)])
        # print(contrast.shape)
        # print(np.median(contrast, axis=0).shape)
        # print(haralick_features.shape)
        return haralick_features.reshape(-1)

        # return contrast, dissimilarity, homogeneity, asm, correlation

    @property
    @_cached
    def efc_ratio(self, ):
        bd = find_boundaries(np.pad(self.image, self.bd_padding, 'constant', constant_values=(0, 0)))
        bd_contours = find_contours(bd, .1)[0]
        efc = elliptic_fourier_descriptors(bd_contours,
                                           normalize=True,
                                           order=15)
        # N = efc.shape[0]
        efcs = np.sqrt(efc[:, 0] ** 2 + efc[:, 1] ** 2) + np.sqrt(efc[:, 2] ** 2 + efc[:, 3] ** 2)
        ratio = efcs[0] / np.sum(efcs[1:])
        return ratio

    @property
    @_cached
    def circularity(self, ):
        if self.perimeter > 1e-6:
            return  (4 * np.pi * self.area) / self.perimeter ** 2
        else:
            return np.nan