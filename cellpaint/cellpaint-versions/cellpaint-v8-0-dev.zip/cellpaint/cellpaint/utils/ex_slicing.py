# import shutil
#
# src = r"F:\PyTorch\cudnn-windows-x86_64-8.7.0.84_cuda11-archive\bin"
# dst = r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.7\bin"
# shutil.copy(src, dst)
import numpy as np
np.set_printoptions(linewidth=200)

a = np.zeros((2, 10, 10), dtype=np.uint16)
a[0, 0:5, 0:5] = 1
a[0, 7:10, 7:10] = 2

a[1, 0:7, 0:6] = 1
a[1, 4:10, 6:10] = 2
b = a[a[:, ] == 1]
print(a.shape, b.shape)

print(a, '\n')
print(b)

# print(np.mean(b[b > 0]))
