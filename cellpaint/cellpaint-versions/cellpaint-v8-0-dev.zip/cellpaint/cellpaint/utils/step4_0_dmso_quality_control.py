from pathlib import WindowsPath

import torch
import numpy as np
import pandas as pd
import scipy.stats as scstats

from scipy.integrate import simpson
from sklearn.cluster import AffinityPropagation
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import robust_scale

from cellpaint.utils.args import CellPaintArgs
from cellpaint.utils.helpers_shared_memory import create_shared_pd_df
from cellpaint.utils.extensions_torch import wassertein_distance_2d

import time
from tqdm import tqdm
import multiprocessing as mp

import string
import seaborn as sns
import cmcrameri as cmc
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap


def create_heatmap(data, rows, cols, title, save_path, save_name):
    fig, axes = plt.subplots(1, 1)
    fig.set_size_inches(21.3, 13.3)
    fig.suptitle(title, fontsize=25, fontname='Comic Sans MS')
    myColors = ((0.8, 0.0, 0.0, 1.0), (0.0, 0.0, 0.8, 1.0))
    cmap = LinearSegmentedColormap.from_list('Custom', myColors, len(myColors))
    axes = sns.heatmap(data, cmap=cmap, annot=True)

    # Manually specify colorbar labelling after it's been generated
    colorbar = axes.collections[0].colorbar
    colorbar.set_ticks([-0.5, 0.5])
    colorbar.set_ticklabels(["Bad\nWells", "Good\nWells"], fontsize=20)

    axes.set_yticks(np.arange(.5, len(rows) + .5, 1))
    axes.set_yticklabels([it for ii, it in enumerate(list(rows))])
    axes.set_xticklabels(axes.get_xmajorticklabels(), rotation=90, fontsize=15)

    axes.set_xticks(np.arange(.5, len(cols) + .5, 1))
    axes.set_xticklabels([it for ii, it in enumerate(cols)])
    axes.set_yticklabels(axes.get_ymajorticklabels(), rotation=0, fontsize=15)

    save_path.mkdir(exist_ok=True, parents=True)
    plt.savefig(save_path / f"{save_name}.png", bbox_inches='tight', dpi=300)
    plt.show()
    # plt.close(fig)
    # plt.cla()


class QualityControlDMSO:
    outlier_feat_cat_count_thresh = 5

    thresholds = np.linspace(0, 1, 100)
    num_thresholds = len(thresholds)

    colormap = "cmc.batlow"  # "magma", "jet", "rocket_r", "tab20"
    normalize_heatmap = False
    apply_auc_thresh = False
    auc_threshold = .05
    colors = list(plt.cm.tab10(np.linspace(0, 1, 10))) + ["black"]
    # colors = ["red", "green", "blue", "orange", "purple", "pink", "gray", "black"]
    line_styles = ["-", "--"]
    markers = ["o", "2"]
    markersize = 4
    mad_multiplier = 2
    save_maps = True

    device_id = 0
    device = torch.device(f"cuda:{device_id}")
    normalize_quartile_range = (2, 98)

    min_cells = 150
    num_groups_ub = 2000
    cmap = "cmc.batlow"
    annot = False

    def __init__(self, args, treatments):
        self.args = args
        self.treatments = treatments

        self.group_cols = ["exp-id", "cell-line", "treatment", "well-id"]
        self.sort_types = [True] * len(self.group_cols)

        self.all_features = self.load_and_preprocess_features()
        self.feat_cols = list(self.all_features.columns[self.start_index:])
        self.M = len(self.feat_cols)
        self.R = len(self.args.celllines)

        self.save_path = self.args.main_path / self.args.experiment / "QC"
        self.save_path.mkdir(exist_ok=True, parents=True)

        self.feature_types = args.heatmap_feature_groups[1:]
        self.channels = self.args.organelles
        self.num_feat_cat, self.num_cin = len(self.feature_types), len(self.channels)

        self.xlabels = [f"{it0}_{it1}" for it0 in self.channels for it1 in self.feature_types]
        self.triplets = [(it0, it1, it2)
                         for it0 in self.markers
                         for it1 in self.line_styles
                         for it2 in self.colors]

        # stepI
        self.caculate_multi()
        # stepII

    def caculate_multi(self, ):
        # to avoid leaks and copies!
        self.all_features = create_shared_pd_df(self.all_features)
        celllines = np.unique(self.all_features["cell-line"])
        densities = np.unique(self.all_features["density"])
        cases = [(it0, it1, it2) for it0 in celllines for it1 in densities for it2 in self.treatments]
        cases = [it + (ii,) for ii, it in enumerate(cases)]
        num_proc = min(len(cases), mp.cpu_count())

        with mp.Pool(processes=num_proc) as pool:
            for ii, _ in tqdm(enumerate(pool.imap(self.calculate_single, cases)), total=len(cases)):
                pass

    def calculate_single(self, quartet):
        cellline, density, treatment, index = quartet
        treat_shortname = treatment.upper().replace("_", "-").replace(" ", "-")[0:10]
        cellline_shortname = cellline.upper().replace("_", "-").replace(" ", "-")[0:10]
        cond0 = ((self.all_features["cell-line"] == cellline) &
                 (self.all_features["density"] == density) &
                 (self.all_features["treatment"] == treatment))
        dosages = np.unique(self.all_features[cond0]["dosage"].to_numpy())

        outliers = np.zeros((len(dosages),), dtype=object)
        for ii, dose in enumerate(dosages):
            features = self.all_features[cond0 & (self.all_features["dosage"] == dose)]
            features = self.normalize_features(features)
            assert len(features) > 1000, \
                "anchor treatment has to be present in all cell-lines and experiments with enough cells"
            print(f"{cellline} {treat_shortname} features ", features.shape)
            features.reset_index(inplace=True, drop=True)
            features.sort_values(by=self.group_cols, ascending=[True] * len(self.group_cols), inplace=True)
            # groups_index is necessary for dist_map gpu-calculation
            groups_meta, groups_index = self.get_groups(features)
            """groups_meta columns are (cell_count, exp-id, cell-line, treatment, well-id)"""
            well_ids, cell_counts = groups_meta[:, -1], groups_meta[:, 0]
            dist_map = self.get_distances_from_ref_distribution(features, groups_index)
            dist_map = pd.DataFrame(dist_map, columns=self.feat_cols, index=well_ids)
            deriv_map, auc_map = self.compute_deriv_maps(dist_map)
            if self.save_maps:
                fig_title = f"{treat_shortname}  {cellline_shortname}  density={density}\ndosage={dose}uM  l1-Norm"
                savename1 = f"{treat_shortname}_DerivMap_l1_{index}_{cellline_shortname}_{density}_{dose}"
                savename2 = f"{treat_shortname}_AUCMap_l1_{index}_{cellline_shortname}_{density}_{dose}"
                savename3 = f"{treat_shortname}_DistHeatMap_l1_{index}_{cellline_shortname}_{density}_{dose}"

                self.plot_deriv_curves(deriv_map, well_ids, title=fig_title, savename=savename1)
                self.plot_auc_heatmap(auc_map, well_ids, cell_counts, title=fig_title, savename=savename2)
                # self.plot_feature_heatmap(dist_map, groups_meta, title=fig_title, savename=savename3)
            outliers[ii] = self.find_outliers(auc_map, well_ids, cell_counts)

        outliers = np.concatenate(outliers, axis=0)
        outliers = pd.DataFrame(outliers, columns=["QC-label", "cell-count", "well-id"])
        outliers.to_csv(self.save_path / f"{treat_shortname}_outliers_{index}_{cellline_shortname}_{density}.csv")

    def load_and_preprocess_features(self, ):
        w0_features = pd.read_csv(self.args.features_path / "w0_features.csv")
        w1_features = pd.read_csv(self.args.features_path / "w1_features.csv")
        w2_features = pd.read_csv(self.args.features_path / "w2_features.csv")
        w3_features = pd.read_csv(self.args.features_path / "w3_features.csv")
        w4_features = pd.read_csv(self.args.features_path / "w4_features.csv")
        misc_features = pd.read_csv(self.args.features_path / "misc_features.csv")
        metadata = pd.read_csv(self.args.features_path / "metadata_of_features.csv")
        if "exp-id" not in list(metadata.columns):
            metadata.insert(0, "exp-id", self.args.experiment)
        # TODO: Fix global-haralick and local-haralick bullshit!!!!
        # The first 4 feature columns for each channel are bounding boxes.
        all_features = pd.concat([
            metadata,
            misc_features,
            w0_features.loc[:, w0_features.columns[4:]],
            w1_features.loc[:, w1_features.columns[4:]],
            w2_features.loc[:, w2_features.columns[4:]],
            w3_features.loc[:, w3_features.columns[4:]],
            w4_features.loc[:, w4_features.columns[4:]]],
            axis=1)
        all_features = all_features.loc[all_features["has-nucleoli"] == 1]
        all_features.dropna(axis=0, inplace=True)
        print("all_features.shape after removing NaNs: ", all_features.shape)
        self.start_index = metadata.shape[1]
        self.min_num_cols = self.start_index + 5 * 5
        return all_features

    def normalize_features(self, features):
        """Normalizes the feature columns of the features dataframe."""
        # normalize each feature column (NOT metadata columns)
        feature_cols = list(features.columns[self.start_index:])
        features[feature_cols] = robust_scale(
            features[feature_cols].to_numpy(), quantile_range=self.normalize_quartile_range)
        # clip outlier feature values to -1 and 1
        features[feature_cols] = features[feature_cols].clip(lower=-1, upper=1)
        return features

    def find_outliers(self, auc_map, well_ids, cell_counts):
        auc_map = auc_map.reshape((-1, auc_map.shape[-1])).T
        # clf = IsolationForest(random_state=100, max_features=10).fit(
        # X=auc_map_array, sample_weight=cell_counts)
        # num_labels = clf.predict(auc_map_array)

        median = np.median(auc_map, axis=0)
        mad = scstats.median_abs_deviation(auc_map, axis=0)
        mad = np.repeat(mad[np.newaxis], repeats=auc_map.shape[0], axis=0)
        median = np.repeat(median[np.newaxis], repeats=auc_map.shape[0], axis=0)
        cond = (median - self.mad_multiplier * mad <= auc_map) & \
               (auc_map <= median + self.mad_multiplier * mad)
        # create_heatmap(cond, well_ids, self.xlabels, title, self.save_path, save_name="QC-test-plot")
        num_labels = np.sum(cond, axis=1) > self.outlier_feat_cat_count_thresh
        return np.vstack((num_labels, cell_counts, well_ids)).T

    def plot_auc_heatmap(self, auc_map, well_ids, cell_counts, title, savename):
        """
        auc_map.shape = (self.num_feat_cat, self.num_cin, num_curves/num_well_ids)
        """
        #  gridspec_kw={'width_ratios': [1, 0.08]}
        num_maps = auc_map.shape[0]
        min_cval, max_cval = np.nanmin(auc_map, axis=(1, 2)), np.nanmax(auc_map, axis=(1, 2))

        fig, axes = plt.subplots(1, num_maps)
        fig.set_size_inches(21.3, 13.3)
        fig.suptitle(title, fontname='Comic Sans MS', fontsize=20)
        cbar_props = {"orientation": "horizontal", "shrink": 0.4}
        for ii in range(num_maps):
            sns.heatmap(
                auc_map[ii], cmap=self.colormap, annot=True, ax=axes[ii], linecolor='gray',
                vmin=min_cval[ii], vmax=max_cval[ii], cbar_kws=cbar_props)
            axes[ii].set_title(self.feature_types[ii], fontname='Comic Sans MS', fontsize=15)
            # linewidths=.05,
            # vmin=0, vmax=1 if self.normalize_heatmap else np.nanmax(auc_map),
            if ii == 0:
                axes[ii].set_yticks(np.arange(.5, len(well_ids) + .5, 1))
                axes[ii].set_yticklabels([f"{it0}_{it1}" for ii, (it0, it1) in enumerate(zip(well_ids, cell_counts))])
                axes[ii].set_yticklabels(axes[ii].get_ymajorticklabels(), rotation=0, fontsize=10)
            else:
                axes[ii].set_yticks([])
            axes[ii].set_xticks(np.arange(.5, self.num_cin + .5, 1))
            axes[ii].set_xticklabels([it for ii, it in enumerate(self.channels)])
            axes[ii].set_xticklabels(axes[ii].get_xmajorticklabels(), rotation=90, fontsize=8)

        plt.savefig(self.save_path / f"{savename}.png", bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close(fig)
        plt.cla()

    def plot_deriv_curves(self, deriv_map, well_ids, title, savename):
        """min_yaxis, max_yaxis, and max_ids_xaxis are calculated per feature category, which are:
        shapes, intensities, and haralick"""

        min_yaxis, max_yaxis = np.nanmin(deriv_map, axis=(1, 2, 3)), np.nanmax(deriv_map, axis=(1, 2, 3))
        M, N = len(self.feature_types), len(self.channels)
        max_ids_xaxis = np.zeros((M,), dtype=object)
        fig, axes = plt.subplots(M, N)
        fig.set_size_inches(21.3, 13.3)
        fig.suptitle(title, fontname='Comic Sans MS', fontsize=20)

        for ii, it1 in enumerate(self.feature_types):  # rows
            max_ids_xaxis[ii] = []
            axes[ii, 0].set_ylabel(it1, fontname="Courier New", fontsize=17)
            for jj, it2 in enumerate(self.channels):  # columns
                if ii == 0:
                    axes[ii, jj].set_title(f"{it2}", **self.args.csfont)
                for kk, (wid, plot_prop) in enumerate(zip(well_ids, self.triplets)):  # curves (well-ids)
                    zids = np.where(np.abs(deriv_map[ii, jj, kk]) < 1e-5)[0]
                    if len(zids) > 0:
                        max_ids_xaxis[ii].append(zids[0])
                    axes[ii, jj].plot(
                        self.thresholds,
                        deriv_map[ii, jj, kk],
                        label=wid,
                        marker=plot_prop[0],
                        linestyle=plot_prop[1],
                        color=plot_prop[2],
                        markersize=self.markersize
                    )
                    axes[ii, jj].set_ylim([min_yaxis[ii], max_yaxis[ii]])
        for ii, it1 in enumerate(self.feature_types):
            x_max_id = np.nanmax(max_ids_xaxis[ii]) if len(max_ids_xaxis[ii]) > 0 else -1
            for jj, it2 in enumerate(self.channels):
                axes[ii, jj].set_xlim([0, self.thresholds[x_max_id]])

        plt.legend(loc="lower center",
                   bbox_to_anchor=(-.7, -1.1),
                   ncols=9,
                   borderaxespad=0.1,
                   fancybox=False,
                   shadow=False,
                   prop={'size': 16, 'family': 'Consolas'})

        # fig.text(0.06, 0.5, f"# of none-zero entries", va='center', rotation='vertical', **args.csfont)
        # fig.text(0.5, 0.04, f"Thresholds used to zero out entries", ha='center', **args.csfont)
        # Create a big subplot
        ax = fig.add_subplot(111, frameon=False)
        # hide tick and tick label of the big axes
        ax.tick_params(labelcolor='none', top='off', bottom='off', left='off', right='off')
        # Use argument `labelpad` to move label downwards or leftward.
        ax.set_xlabel(f"Threshold used to zero out entries", labelpad=9, fontname="Cambria", fontsize=18)
        ax.set_ylabel(f"# of none-zero entries from the wasserstien distance map",
                      labelpad=40, rotation="vertical", fontname="Cambria", fontsize=18)
        plt.savefig(self.save_path / f"{savename}.png", bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close(fig)
        plt.cla()

    def compute_deriv_maps(self, distancemap):
        num_curves = distancemap.shape[0]
        deriv_map = np.zeros((self.num_feat_cat, self.num_cin, num_curves, self.num_thresholds), dtype=np.float32)
        auc_map = np.zeros((self.num_feat_cat, self.num_cin, num_curves), dtype=np.float32)
        for ii, it1 in enumerate(self.feature_types):
            for jj, it2 in enumerate(self.channels):
                feat_cols = [cc for cc in distancemap.columns if it1 in cc and it2 in cc]
                assert len(feat_cols) > 0

                for kk in range(num_curves):  # restrict to a specific (exp-id, treatment, dosage) triplet
                    tmp = np.abs(distancemap.iloc[kk][feat_cols].to_numpy())
                    if len(tmp) == 0:
                        continue
                    for ll, it4 in enumerate(self.thresholds):
                        tmp1 = tmp.copy()
                        tmp1[(tmp <= it4)] = 0
                        if tmp1.size > 0:
                            deriv_map[ii, jj, kk, ll] = np.nansum(tmp1) / tmp1.shape[0]
                        else:
                            deriv_map[ii, jj, kk, ll] = 0

                    auc_map[ii, jj, kk] = simpson(deriv_map[ii, jj, kk, :], dx=1)
        return deriv_map, auc_map

    def get_groups(self, features):
        """Assuming all relevant metadata cols, except exp-id and well-id,
         have been alread fixed properly!

         We want to get feature distance metrics per (exp-id, well-id) pair, but can't
         use strings as tensors in pytorch. so we want to extract the metadata per pair
         as well as get the corresponding index to as a numeric value to be used as reference
         when calculating distances with pytorch.

         groups_meta columns are (group_id, cell_count, exp-id, cell-line, treatment, well-id)
         """
        grp_id = 0
        groups = features[self.group_cols].groupby(self.group_cols, group_keys=False)
        groups_meta = np.zeros((self.num_groups_ub, len(self.group_cols) + 1), dtype=object)
        groups_index = -1 * np.ones((len(features),), dtype=np.int64)
        # loop over the (expid, wellid) unique pairs in the features dataframe
        for ii, (key, slice_) in enumerate(groups):
            # print(counter, slice_.index, key)
            cell_count = len(slice_)
            if cell_count < self.min_cells:
                continue
            groups_meta[grp_id] = (cell_count,) + tuple(key)
            groups_index[slice_.index] = grp_id  # valid group index starts at 1, not zero
            grp_id += 1

        groups_meta = groups_meta[0:grp_id]
        return groups_meta, groups_index

    def get_clusters(self, distances, groups_meta):
        clustering = AffinityPropagation(random_state=100, ).fit(distances)
        num_labels = clustering.labels_
        median_ = np.median(distances, axis=1)
        unix = np.unique(num_labels)
        for ii, it in enumerate(unix):
            cond = (num_labels == it)
            print(it, groups_meta[cond, 2:4], median_[cond])

    def get_distances_pairwise(self, features, groups_index, feat_cols):
        unix = np.unique(groups_index)
        features = torch.as_tensor(np.float32(features[feat_cols].to_numpy()).T).to(self.device)
        groups_index = torch.as_tensor(np.int64(groups_index)).to(self.device)
        N = features.shape[1]  # number of cells
        M = features.shape[0]  # number of features
        P = len(unix)
        distances = torch.zeros((P, P, M), dtype=torch.float32).to(self.device)
        # print(distances.size())
        with torch.no_grad():
            for ii in range(0, P):
                for jj in range(ii, P):
                    cond1 = groups_index == ii + 1
                    cond2 = groups_index == jj + 1
                    median_distance = torch.median(features[:, cond1], dim=1)[0] - \
                                      torch.median(features[:, cond2], dim=1)[0]
                    median_sign = torch.sign(median_distance)
                    dist = wassertein_distance_2d(features[:, cond1], features[:, cond2])
                    dist = torch.mul(dist, median_sign)
                    # print(dist.size())
                    distances[ii, jj, :] = dist

        distances += torch.transpose(distances.clone(), 0, 1)
        similarities = torch.mean(distances, dim=2)
        distances = distances.cpu().numpy()
        similarities = similarities.cpu().numpy()
        torch.cuda.empty_cache()
        return distances, similarities

    def get_distances_from_ref_distribution(self, features, groups_index):
        unix = np.unique(groups_index[groups_index != -1])
        assert len(unix) >= 1, "All the wells for this cell-line DMSO have already been removed!"
        feats = torch.as_tensor(np.float32(features[self.feat_cols].to_numpy()).T).to(self.device)
        groups_index = torch.as_tensor(np.int64(groups_index)).to(self.device)
        M = feats.shape[0]  # number of feats
        N = feats.shape[1]  # number of cells
        P = len(unix)  # usually number of unique well-ids within a cell-line with DMSO treatment
        # print(N, M, P)
        distances = torch.zeros((P, M), dtype=torch.float32).to(self.device)
        with torch.no_grad():
            for ii in unix:
                # cond = (groups_index == ii)
                # print(ii, feats[:, cond].shape, feats.shape)
                # median_distance = torch.median(feats[:, cond], dim=1)[0] - torch.median(feats, dim=1)[0]
                # median_sign = torch.sign(median_distance)
                # dist = wassertein_distance_2d(feats[:, cond], feats)
                # dist = torch.mul(dist, median_sign)
                distances[ii, :] = wassertein_distance_2d(feats[:, (groups_index == ii)], feats)
        distances = distances.cpu().numpy()
        torch.cuda.empty_cache()
        return distances

    def plot_feature_heatmap(self, distances, groups_meta, title, savename):
        min_, max_ = np.nanmin(distances), np.nanmax(distances)
        """groups_meta columns are (cell_count, exp-id, cell-line, treatment, well-id)"""
        meta_labels = [f"{it[4]}_{it[0]}" for it in groups_meta]

        fig, axes = plt.subplots(1, 1, sharex=True, sharey=True)
        fig.set_size_inches(21.3, 13.3)
        fig.suptitle(title, fontname='Comic Sans MS', fontsize=20)
        sns.heatmap(distances, cmap=self.cmap, vmin=min_, vmax=max_, )

        axes.set_xticks(np.arange(.5, len(self.feat_cols) + .5, 1))
        axes.set_xticklabels([it for ii, it in enumerate(self.feat_cols)])
        axes.set_yticks(np.arange(.5, len(meta_labels) + .5, 1))
        axes.set_yticklabels([it for ii, it in enumerate(meta_labels)])
        axes.set_xticklabels(axes.get_xmajorticklabels(), rotation=90, fontsize=6)
        axes.set_yticklabels(axes.get_ymajorticklabels(), rotation=0, fontsize=6)

        plt.savefig(self.save_path / f"{savename}.png", bbox_inches='tight', dpi=300)
        plt.close(fig)


def main():
    # exp = "20221116-CP-Fabio-DRC-BM-P01"
    # exp = "20220831-CP-Fabio-DRC-BM-R01"
    # exp = "20220831-CP-Fabio-DRC-BM-R01"
    # exp = "20221102-CP-Fabio-DRC-BM-P02"
    # exp = "20230119-CP-Fabio-QCcelllines-EXP01"
    exp = "20230124-CP-Fabio-QCcelllines-EXP02"

    args = CellPaintArgs(experiment=exp, mode="full", ).args
    my_class = QualityControlDMSO(args, treatments=args.treatments)
    my_class.caculate_multi()
    #################################################################
    # data1 = np.concatenate(np.load("all_labels_dmso.npy", allow_pickle=True), axis=0)
    # data2 = np.concatenate(np.load("all_labels_berberine.npy", allow_pickle=True), axis=0)
    # data = np.concatenate((data1, data2), axis=0)
    # print(data.shape)
    # rows = list(string.ascii_uppercase[:16])
    # cols = [str(ii).zfill(2) for ii in np.arange(1, 25)]
    # data = pd.DataFrame(data, columns=["well-id", "cell-count", "QC-label"])
    # pdf = pd.DataFrame(np.zeros((16, 24), dtype=int), columns=cols, index=rows)
    # print(pdf.head(3))
    # print('\n')
    # for id, row in data.iterrows():
    #     # print(id)
    #     label = row["QC-label"]
    #     well_id, cell_count = row["well-id"], row["cell-count"]
    #     rr, cc = well_id[0], well_id[1:]
    #     print(rr, cc)
    #     pdf.loc[rr, cc] = label
    # pdf[pdf == 0] = np.nan
    # print(pdf)
    #
    # fig, axes = plt.subplots(1, 1, sharex=True, sharey=True)
    # fig.set_size_inches(21.3, 13.3)
    # fig.suptitle(f"{args.experiment}\nQuality Control", fontsize=25, fontname='Comic Sans MS', )
    # # similarities = np.mean(similarities, axis=2)
    # myColors = ((0.8, 0.0, 0.0, 1.0), (0.0, 0.0, 0.8, 1.0))
    # cmap = LinearSegmentedColormap.from_list('Custom', myColors, len(myColors))
    # ax = sns.heatmap(pdf, cmap=cmap, annot=True)
    #
    # # Manually specify colorbar labelling after it's been generated
    # colorbar = ax.collections[0].colorbar
    # colorbar.set_ticks([-0.5, 0.5])
    # colorbar.set_ticklabels(["Bad\nWells", "Good\nWells"], fontsize=20)
    #
    # axes.set_yticks(np.arange(.5, len(list(pdf.index)) + .5, 1))
    # axes.set_yticklabels([it for ii, it in enumerate(list(pdf.index))])
    #
    # axes.set_xticks(np.arange(.5, len(pdf.columns) + .5, 1))
    # axes.set_xticklabels([it for ii, it in enumerate(pdf.columns)])
    #
    # axes.set_xticklabels(axes.get_xmajorticklabels(), rotation=90, fontsize=15)
    # axes.set_yticklabels(axes.get_ymajorticklabels(), rotation=0, fontsize=15)
    #
    # plt.savefig(args.main_path / args.experiment / "QC" / f"Platemap-2.png", bbox_inches='tight', dpi=300)
    # # plt.show()
    # plt.close(fig)
    # plt.cla()
    ################################################################################################
    # df = []
    # csv_files = (args.main_path/args.experiment/"QC").rglob("*_l1_*.csv")
    # for ii, it in enumerate(csv_files):
    #     df.append(pd.read_csv(it, index_col=0))
    # df = pd.concat(df)
    # # print(df.index, df.shape)
    # rows = list(string.ascii_uppercase[:16])
    # cols = [str(ii).zfill(2) for ii in np.arange(1, 25)]
    # pdf = pd.DataFrame(np.zeros((16, 24), dtype=int), columns=cols, index=rows)
    # for well_id, row in df.iterrows():
    #     label = row["QC-label"]
    #     row, col = well_id[0], well_id[1:]
    #     # print(well_id, label)
    #     pdf.loc[row, col] = label
    # pdf[pdf == 0] = np.nan
    # print(pdf)
    #
    # fig, axes = plt.subplots(1, 1, sharex=True, sharey=True)
    # fig.set_size_inches(21.3, 13.3)
    # fig.suptitle(f"{args.experiment}\nQuality Control", fontsize=25, fontname='Comic Sans MS',)
    # # similarities = np.mean(similarities, axis=2)
    # myColors = ((0.8, 0.0, 0.0, 1.0), (0.0, 0.0, 0.8, 1.0))
    # cmap = LinearSegmentedColormap.from_list('Custom', myColors, len(myColors))
    # ax = sns.heatmap(pdf, cmap=cmap, annot=True)
    #
    # # Manually specify colorbar labelling after it's been generated
    # colorbar = ax.collections[0].colorbar
    # colorbar.set_ticks([-0.5, 0.5])
    # colorbar.set_ticklabels(["Bad\nWells", "Good\nWells"], fontsize=20)
    #
    # axes.set_yticks(np.arange(.5, len(list(pdf.index)) + .5, 1))
    # axes.set_yticklabels([it for ii, it in enumerate(list(pdf.index))])
    #
    # axes.set_xticks(np.arange(.5, len(pdf.columns) + .5, 1))
    # axes.set_xticklabels([it for ii, it in enumerate(pdf.columns)])
    #
    # axes.set_xticklabels(axes.get_xmajorticklabels(), rotation=90, fontsize=15)
    # axes.set_yticklabels(axes.get_ymajorticklabels(), rotation=0, fontsize=15)
    #
    # plt.savefig(args.main_path/args.experiment/"QC"/f"Platemap.png", bbox_inches='tight', dpi=300)
    # # plt.show()
    # plt.close(fig)
    # plt.cla()


if __name__ == "__main__":
    main()
