import re
import itertools
import numpy as np
import pandas as pd
import tifffile
from tqdm import tqdm
import multiprocessing as mp

from PIL import Image
import matplotlib.pyplot as plt
from skimage.feature import greycomatrix, greycoprops
from skimage.measure import label, regionprops_table
from skimage.color import label2rgb

from utils.args import args, ignore_imgaeio_warning, create_shared_multiprocessing_name_space_object
from utils.image_and_mask_files import get_key_from_img_path, get_mask_path_key, \
    get_matching_img_group_nuc_mask_cyto_mask, load_img, containsLetterAndNumber
from pandas import DataFrame
from functools import partial
from scipy import stats

########################
from scipy.ndimage import find_objects
from skimage.measure._regionprops import RegionProperties
from inspect import signature
from operator import attrgetter
#########################


def get_intensity_features(regionmask, intensity):
    quartiles = np.percentile(intensity[regionmask], args.intensity_percentiles)
    intensity_median, intensity_mad, intensity_mean, intensity_std = \
        np.median(intensity[regionmask]),\
        stats.median_abs_deviation(intensity[regionmask]),\
        np.mean(intensity[regionmask]), \
        np.std(intensity[regionmask])
    return *quartiles, intensity_median, intensity_mad, intensity_mean, intensity_std


def get_haralick_features(regionmask, intensity_image):
    num_channels = intensity_image.shape[2]
    # print("intensity_image", intensity_image.shape, num_channels)
    if intensity_image.ndim == 2:
        return None
    cins = np.arange(num_channels)
    glcm_props = np.zeros(
        (num_channels, 6, len(args.distances), len(args.angles)),
        dtype=np.float32)
    for cin in cins:
        glcm = greycomatrix(
            intensity_image[:, :, cin],
            distances=args.distances,
            angles=args.angles,
            levels=len(args.intensity_level_thresholds) + 1,
            symmetric=True, normed=True)
        glcm = glcm[1:, 1:]
        # print(glcm.shape)
        # haralick_features = np.vstack((
        #     greycoprops(glcm, prop='contrast'),
        #     greycoprops(glcm, prop='dissimilarity'),
        #     greycoprops(glcm, prop='homogeneity'),
        #     greycoprops(glcm, prop='ASM'),
        #     greycoprops(glcm, prop='energy'),
        #     greycoprops(glcm, prop='correlation')))
        # print(haralick_features.shape, greycoprops(glcm, prop='contrast').shape)
        # return haralick_features.flatten()
        glcm_props[cin, 0] = greycoprops(glcm, prop='contrast')
        glcm_props[cin, 1] = greycoprops(glcm, prop='dissimilarity')
        glcm_props[cin, 2] = greycoprops(glcm, prop='homogeneity')
        glcm_props[cin, 3] = greycoprops(glcm, prop='ASM')
        glcm_props[cin, 4] = greycoprops(glcm, prop='energy')
        glcm_props[cin, 5] = greycoprops(glcm, prop='correlation')
    return glcm_props


def get_my_props(quartet, args):

    w0_mask_path, w1_mask_path, w2_mask_path, img_channels_group = quartet
    if args.testing:
        # for item in img_channels_group:
        #     print(item)
        print(w0_mask_path.stem)
    """
    w0_mask_path = .../w0_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
    w1_mask_path = .../w1_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
    m2 = .../w2_P000025-combchem-v3-U2OS-24h-L1-copy1_B02_1.png
    img_channels_group:
    [
    .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w1DCEB3369-8F24-4915-B0F6-B543ADD85297.tif,
    .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w2C3AF00C2-E9F2-406A-953F-2ACCF649F58B.tif,
    .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w3524F4D75-8D83-4DDC-828F-136E6A520E5D.tif,
    .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w4568AFB8E-781D-4841-8BC8-8FD870A3147F.tif,
    .../P000025-combchem-v3-U2OS-24h-L1-copy1_B02_s1_w5D9A405BD-1C0C-45E4-A335-CEE88A9AD244.tif,
    ]
    """

    # # TODO: Fix this assertion statement for all cases, so that it works for all cases of experiment
    # # assert img_channels_group[0].parents[1].stem == w0_mask_path.stem.split("_")[1]  # match experiment id
    # assert img_channels_group[0].stem.split("_")[3] == w0_mask_path.stem.split("_")[2]  # match well-id
    # assert img_channels_group[0].stem.split("_")[-1][5:9] == w0_mask_path.stem.split("_")[3]  # match fov
    assert get_key_from_img_path(img_channels_group[2], args.lab, key_purpose="to_match_it_with_mask_path") == \
           get_mask_path_key(w0_mask_path) == \
           get_mask_path_key(w1_mask_path) == \
           get_mask_path_key(w2_mask_path)
    ###############################################################################
    # extract metadata
    # exp_id = w0_mask_path.stem.split("_")[1]
    well_id = w0_mask_path.stem.split("_")[2]
    ################################################################################
    # # sometimes a image well-id might not be present in the platemap.
    # try:
    #     xx = args.wellid2num[well_id]
    #     yy = args.wellid2treat[well_id]
    # except:
    #     return None
    ###############################################################################

    fov = w0_mask_path.stem.split("_")[3]
    if containsLetterAndNumber(fov):
        fov = int(re.findall(r'\d+', fov)[0])
    elif fov.isdigit:
        # print(fov)
        fov = int(fov)
    else:
        raise ValueError(f"FOV value {fov} is unacceptable!")

    dosage = args.wellid2dosage[well_id]
    treatment = args.wellid2treatment[well_id]
    celline = args.wellid2cellline[well_id]
    density = args.wellid2density[well_id]
    # convert string values to numbers for less storage, faster saving, and faster loading.
    # print(well_id, fov, celline, treatment)

    well_id = args.wellid2num[well_id]
    celline = args.cellline2num[celline]
    treatment = args.treatment2num[treatment]
    density = args.density2num[density]
    dosage = args.dosage2num[dosage]
    ######################################################################################################

    # read masks from hard drive
    w0_mask = np.array(Image.open(w0_mask_path)).astype(np.uint16)  # nuclei mask
    # When there is not enough cells (< 5 cells) detected within the image, skip that image entirely.
    if len(np.unique(w0_mask)) <= 6:
        return None
    w1_mask = np.array(Image.open(w1_mask_path)).astype(np.uint16)  # w1 mask
    # TODO: add the new w4 mask later
    w2_mask = np.array(Image.open(w2_mask_path)).astype(np.uint16)  # w2 mask
    w4_mask = w1_mask  # w4 mask

    # read image from hard drive
    # img of the fov with 4 channels: (DAPI, CYTOPLASM, WGA, MITOCONDRIA)
    # img of the fov with 5 channels: (DAPI, CYTO, w2, actin, MITO)
    img = load_img(img_channels_group, args.num_channels, args.height, args.width)
    img = img.transpose((1, 2, 0))
    ####################################################################################
    # remove the w0 from the w1plasm mask
    w1_mask[w0_mask > 0] = 0
    # relabel w2_mask with the nuclei/w1plasm masks (already matching) labels
    w2_mask[w2_mask > 0] = w0_mask[w2_mask > 0]
    cell_mask = w0_mask + w1_mask  # actin mask

    # print(len(np.unique(cell_mask)), len(np.unique(w1_mask)), len(np.unique(w0_mask)))
    # assert np.array_equal(np.unique(w1_mask), np.unique(w0_mask))
    assert np.array_equal(cell_mask[w0_mask > 0], w0_mask[w0_mask > 0])

    unix = np.setdiff1d(np.unique(cell_mask), [0])  # cell ids excluding background
    pos_idx = np.unique(cell_mask[w2_mask > 0])  # with w2
    neg_idx = np.setdiff1d(unix, pos_idx)  # without w2

    # divide cells into 2 separate populations : with w2 and without w2
    has_nucleoli = cell_mask.copy()
    has_nucleoli[np.isin(cell_mask, pos_idx)] = 1
    has_nucleoli[np.isin(cell_mask, neg_idx)] = -1
    ####################################################################################################
    discrete_img = np.clip(np.uint16(img), None, args.intensity_thresh_ub)
    for ii, (it0, it1) in enumerate(zip(
            args.intensity_level_thresholds[0:-1], args.intensity_level_thresholds[1:])):
        # print(ii)
        discrete_img[(it0 <= img) & (img < it1)] = ii
    discrete_img[img >= args.intensity_thresh_ub] = len(args.intensity_level_thresholds) - 1
    # print("discrete_img", discrete_img.shape)
    # print("cell_mask", cell_mask.shape)
    # #####################################################################################
    # # prop1: cells with w2
    # if args.experiment == "2021-CP007" or args.experiment == "2021-CP008":
    #     channel_ids = [0, 1, 2, 3]
    #     shape_masks = [w0_mask, w1_mask, w2_mask, w1_mask]
    #     texture_masks = [w0_mask, cell_mask, w0_mask, cell_mask]
    #
    #     # shape_masks = np.stack([
    #     #     w0_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1),
    #     #     w2_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1)], axis=-1)
    #     # my_images = np.transpose(img, (1, 2, 0))
    # elif args.experiment == "others":
    #     channel_ids = [0, 1, 2, 3, 4]
    #     shape_masks = [w0_mask, w1_mask, w1_mask, w2_mask, w1_mask]
    #     texture_masks = [w0_mask, cell_mask, cell_mask, w0_mask, cell_mask]
    #     # my_images = np.transpose(img, (1, 2, 0))
    #     # shape_masks = np.stack([
    #     #     w0_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1),
    #     #     w2_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1)],
    #     #     axis=-1)
    # else:
    #     channel_ids = [0, 1, 2, 3, 4]
    #     shape_masks = [w0_mask, w1_mask, w2_mask, w1_mask, w1_mask]
    #     texture_masks = [w0_mask, cell_mask, w0_mask, cell_mask, cell_mask]
    #     # my_images = np.transpose(img, (1, 2, 0))
    #     # # print(w0_mask.shape, w1_mask.shape, w2_mask.shape, w1_mask.shape, w1_mask.shape)
    #     # my_masks = np.stack([
    #     #     w0_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1),
    #     #     w2_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1),
    #     #     w1_mask*(w2 == 1)], axis=-1)
    #     # print(my_masks.shape)

    # initialize img_props for cells "with w2", w2_flag==1
    # and cells "without w2", w2_flag==2
    # w2_flag = 1, num_cells = N1
    # nchannels = NUM_ORGANELLES if w2_flag == 1 else NUM_ORGANELLES - 1

    # N1, N2 = len(np.unique(w0_mask * (has_nucleoli == 1)))-1, \
    #          len(np.unique(w0_mask * (has_nucleoli == -1))) - 1

    # Analyze only the cells the have nucleoli for now (has_nucleoli == 1)
    cell_mask = cell_mask * (has_nucleoli == 1)
    w0_mask = w0_mask * (has_nucleoli == 1)
    w1_mask = w1_mask * (has_nucleoli == 1)
    w2_mask = w2_mask * (has_nucleoli == 1)
    w4_mask = w4_mask * (has_nucleoli == 1)

    N1 = len(np.unique(w0_mask)) - 1
    max_obj_ind = np.amax(cell_mask)

    cell_objects = find_objects(cell_mask, max_label=max_obj_ind)
    w0_objects = find_objects(w0_mask, max_label=max_obj_ind)
    w1_objects = find_objects(w1_mask, max_label=max_obj_ind)
    w2_objects = find_objects(w2_mask, max_label=max_obj_ind)
    w4_objects = find_objects(w1_mask, max_label=max_obj_ind)

    n0, n1, n2, n3, n4 = \
        len(args.metadata_cols), \
        len(args.bbox), \
        len(args.shape_keys), \
        len(args.extra_props_keys_intensity), \
        len(args.extra_prop_keys_haralick)

    w0_features = np.zeros((N1, args.num_cols-n0), dtype=object)
    w1_features = np.zeros((N1, args.num_cols-n0), dtype=object)
    w2_features = np.zeros((N1, args.num_cols-n0), dtype=object)
    w3_features = np.zeros((N1, args.num_cols-n0), dtype=object)
    w4_features = np.zeros((N1, args.num_cols-n0), dtype=object)

    counter = 0

    for jjjj, (cell_obj, w0_obj, w1_obj, w4_obj, w2_obj) in \
            enumerate(zip(cell_objects, w0_objects, w1_objects, w4_objects, w2_objects)):
            # tqdm(enumerate(zip(cell_objects, w0_objects, w1_objects, w4_objects, w2_objects)), total=max_obj_ind):
        if cell_obj is None:
            continue

        obj_label = jjjj + 1
        # print(obj_label)

        cell_haralick_props = RegionProperties(
            slice=cell_obj, label=obj_label, label_image=cell_mask,
            intensity_image=discrete_img[:, :, [1, 3, 4]],
            cache_active=True,
            extra_properties=[get_haralick_features, ])
        nuc_haralick_props = RegionProperties(
            w0_obj, obj_label, w0_mask,
            intensity_image=discrete_img[:, :, [0, 2]],
            cache_active=True,
            extra_properties=[get_haralick_features, ])

        w0_intensity_and_shape_props = RegionProperties(
            w0_obj, obj_label, w0_mask,
            intensity_image=img[:, :, 0],
            cache_active=True,
            extra_properties=[get_intensity_features, ])
        w1_intensity_and_shape_props = RegionProperties(
            w1_obj, obj_label, w1_mask,
            intensity_image=img[:, :, 1],
            cache_active=True,
            extra_properties=[get_intensity_features, ])
        w2_intensity_and_shape_props = RegionProperties(
            w2_obj, obj_label, w2_mask,
            intensity_image=img[:, :, 2],
            cache_active=True,
            extra_properties=[get_intensity_features, ])
        w3_intensity_and_shape_props = RegionProperties(
            w1_obj, obj_label, w1_mask,
            intensity_image=img[:, :, 3],
            cache_active=True,
            extra_properties=[get_intensity_features, ])
        w4_intensity_and_shape_props = RegionProperties(
            w4_obj, obj_label, w4_mask,
            intensity_image=img[:, :, 4],
            cache_active=True,
            extra_properties=[get_intensity_features, ])

        w0_features[counter, 0:n1] = w0_intensity_and_shape_props.bbox
        w1_features[counter, 0:n1] = w1_intensity_and_shape_props.bbox
        w2_features[counter, 0:n1] = w2_intensity_and_shape_props.bbox
        w3_features[counter, 0:n1] = w3_intensity_and_shape_props.bbox
        w4_features[counter, 0:n1] = w4_intensity_and_shape_props.bbox

        # get shape features for each channel
        # print(w0_intensity_and_shape_props.bbox)
        w0_features[counter, n1:n1+n2] = attrgetter(*args.shape_keys)(w0_intensity_and_shape_props)
        w1_features[counter, n1:n1+n2] = attrgetter(*args.shape_keys)(w1_intensity_and_shape_props)
        w2_features[counter, n1:n1+n2] = attrgetter(*args.shape_keys)(w2_intensity_and_shape_props)
        w3_features[counter, n1:n1+n2] = attrgetter(*args.shape_keys)(w3_intensity_and_shape_props)
        w4_features[counter, n1:n1+n2] = attrgetter(*args.shape_keys)(w4_intensity_and_shape_props)

        # get intensity features for each channel
        w0_features[counter, n1+n2:n1+n2+n3] = w0_intensity_and_shape_props.get_intensity_features
        w1_features[counter, n1+n2:n1+n2+n3] = w1_intensity_and_shape_props.get_intensity_features
        w2_features[counter, n1+n2:n1+n2+n3] = w2_intensity_and_shape_props.get_intensity_features
        w3_features[counter, n1+n2:n1+n2+n3] = w3_intensity_and_shape_props.get_intensity_features
        w4_features[counter, n1+n2:n1+n2+n3] = w4_intensity_and_shape_props.get_intensity_features

        # get haralick features for each channel
        nuc_haralick_feature_groups = getattr(nuc_haralick_props, "get_haralick_features")
        cell_haralick_feature_groups = getattr(cell_haralick_props, "get_haralick_features")
        w0_features[counter, n1+n2+n3:n1+n2+n3+n4] = nuc_haralick_feature_groups[0].reshape(-1)
        w1_features[counter, n1+n2+n3:n1+n2+n3+n4] = cell_haralick_feature_groups[0].reshape(-1)
        w2_features[counter, n1+n2+n3:n1+n2+n3+n4] = nuc_haralick_feature_groups[1].reshape(-1)
        w3_features[counter, n1+n2+n3:n1+n2+n3+n4] = cell_haralick_feature_groups[1].reshape(-1)
        w4_features[counter, n1+n2+n3:n1+n2+n3+n4] = cell_haralick_feature_groups[2].reshape(-1)

        counter += 1

    # features = np.zeros((N1, args.num_organelles*args.num_features_per_organelle), dtype=np.float32)
    # # number of channels differs for the cells with w2 and without w2
    # for ii, (cid, smask, tmask) in enumerate(zip(channel_ids, shape_masks, texture_masks)):
    #
    #     features[:, ii * args.num_features_per_organelle: (ii + 1) * args.num_features_per_organelle] = \
    #         np.vstack(tuple(regionprops_table(
    #                 smask * (w2 == 1),
    #                 img[cid],
    #                 properties=args.skimage_keys,
    #                 extra_properties=[get_intensity_features, ]).values())).T
    #     features[:, ii * args.num_features_per_organelle: (ii + 1) * args.num_features_per_organelle] = \
    #         np.vstack(tuple(regionprops_table(
    #                 tmask * (w2 == 1),
    #                 img_discrete[cid],
    #                 extra_properties=[get_haralick_features, ]).values())).T
    # concatenate the metadata to the features afterwards
    # all cells within a single image have the exact same metadata
    args.metadata_cols = ["well_id", "treatment", "celline", "density", "dosage", "fov",]
    metadata = np.vstack([
        np.repeat(well_id, N1),
        np.repeat(treatment, N1),
        np.repeat(celline, N1),
        np.repeat(density, N1),
        np.repeat(dosage, N1),
        np.repeat(fov, N1),
    ], ).T
    w0_features = np.concatenate((metadata, w0_features), axis=1)
    w1_features = np.concatenate((metadata, w1_features), axis=1)
    w2_features = np.concatenate((metadata, w2_features), axis=1)
    w3_features = np.concatenate((metadata, w3_features), axis=1)
    w4_features = np.concatenate((metadata, w4_features), axis=1)
    # print(w0_features.shape, w1_features.shape, w2_features.shape, w3_features.shape, w4_features.shape)
    return w0_features, w1_features, w2_features, w3_features, w4_features


def warn_user_about_missing_wellids(img_path_groups):
    wellids_from_img_files = [
        get_key_from_img_path(it[0], args.lab, key_purpose="to_get_well_id") for it in img_path_groups]
    wellids_from_platemap = args.wellids

    missig_wells_1 = np.setdiff1d(wellids_from_img_files, wellids_from_platemap)
    missig_wells_2 = np.setdiff1d(wellids_from_platemap, wellids_from_img_files)
    if len(missig_wells_1) > 0:
        raise ValueError(
            f"The following well-ids are in the image-folder  {args.experiment},\n"
            f" but are missing from the platemap file:\n"
            f"{missig_wells_1}")
    elif len(missig_wells_2) > 0:
        raise ValueError(
            f"The following well-ids are in the platemap file,\n"
            f" but are missing from the image-folder  {args.experiments}:\n"
            f"{missig_wells_1}")
    else:
        print("no well-id is missing!!! Enjoy!!!")


def main(args):
    # # print(args.testing)
    # # some images might have been removed during cellpose segmentation because they had very few cell,
    # # those image groups have to be removed.
    # # Them each image group will match with its corresponding mask.
    # img_path_groups, w0_mask_paths, w1_mask_paths, args.num_channels = \
    #     get_matching_img_group_nuc_mask_cyto_mask(args.main_path, args.experiment, args.lab, mask_folder="Masks")
    # w2_mask_paths = [it.parents[0]/f"w2_{'_'.join(it.stem.split('_')[1:])}.png" for it in w0_mask_paths]
    #
    # # sometimes some well_ids coming from image files might be missing from the provided platemap,
    # # on the other hand, sometimes some well_ids from the platemap might have no corresponding image file
    # # in the experiment folder, in both cases the user should be warned by the program.
    # warn_user_about_missing_wellids(img_path_groups)
    # cnt = 0
    # # 600 is the estimate of the maximum number of cells we can possibly find in a single image
    # # initialize array to store cells with w2 features
    # w0_features = np.zeros((len(w0_mask_paths) * 700, args.num_cols), dtype=object)
    # w1_features = np.zeros((len(w0_mask_paths) * 700, args.num_cols), dtype=object)
    # w2_features = np.zeros((len(w0_mask_paths) * 700, args.num_cols), dtype=object)
    # w3_features = np.zeros((len(w0_mask_paths) * 700, args.num_cols), dtype=object)
    # w4_features = np.zeros((len(w0_mask_paths) * 700, args.num_cols), dtype=object)
    #
    # if args.testing:
    #     for iiii, (w0_mask_path, w1_mask_path, m2, img_channels_group) in enumerate(zip(
    #             w0_mask_paths, w1_mask_paths, w2_mask_paths, img_path_groups)):
    #         # print(w0_mask_path)
    #         out = get_my_props(quartet=(w0_mask_path, w1_mask_path, m2, img_channels_group), args=args)
    #         if out is not None:
    #             num_cells = len(out[0])
    #             w0_features[cnt: cnt + num_cells] = out[0]
    #             w1_features[cnt: cnt + num_cells] = out[1]
    #             w2_features[cnt: cnt + num_cells] = out[2]
    #             w3_features[cnt: cnt + num_cells] = out[3]
    #             w4_features[cnt: cnt + num_cells] = out[4]
    #             cnt += num_cells
    #         if iiii == 3:
    #             break
    # else:
    #
    #     my_func = partial(get_my_props, args=args)
    #     with mp.Pool(processes=mp.cpu_count()) as pool:
    #         for iiii, out in tqdm(enumerate(pool.imap(
    #                 my_func,
    #                 zip(w0_mask_paths, w1_mask_paths, w2_mask_paths, img_path_groups))),
    #                 total=len(w0_mask_paths)):
    #             if out is not None:
    #                 num_cells = len(out[0])
    #                 w0_features[cnt: cnt + num_cells] = out[0]
    #                 w1_features[cnt: cnt + num_cells] = out[1]
    #                 w2_features[cnt: cnt + num_cells] = out[2]
    #                 w3_features[cnt: cnt + num_cells] = out[3]
    #                 w4_features[cnt: cnt + num_cells] = out[4]
    #                 cnt += num_cells
    #
    # # remove empty/unfilled rows from the end/tail of the array.
    # w0_features = w0_features[0: cnt]
    # w1_features = w1_features[0: cnt]
    # w2_features = w2_features[0: cnt]
    # w3_features = w3_features[0: cnt]
    # w4_features = w4_features[0: cnt]
    #
    # # ###############################################################################
    # # Saving all_props1 as a numpy array
    # # all_props1 = np.core.records.fromarrays(all_props1.T, names=cols1)
    # # print(all_props1.dtype.names)
    # np.save(args.main_path/args.experiment/"w0_features.npy", w0_features)
    # np.save(args.main_path/args.experiment/"w1_features.npy", w1_features)
    # np.save(args.main_path/args.experiment/"w2_features.npy", w2_features)
    # np.save(args.main_path/args.experiment/"w3_features.npy", w3_features)
    # np.save(args.main_path/args.experiment/"w4_features.npy", w4_features)
    # ################################################################################
    # saving "features" as a csv file
    print("loading the 'features' numpy array ....")
    w0_features = np.load(args.main_path/args.experiment/"w0_features.npy", allow_pickle=True)
    w1_features = np.load(args.main_path/args.experiment/"w1_features.npy", allow_pickle=True)
    w2_features = np.load(args.main_path/args.experiment/"w2_features.npy", allow_pickle=True)
    w3_features = np.load(args.main_path/args.experiment/"w3_features.npy", allow_pickle=True)
    w4_features = np.load(args.main_path/args.experiment/"w4_features.npy", allow_pickle=True)

    # def convert_metadata_back_2_str(x):
    #     """
    #     col0: dosage
    #     col1: well_id
    #     col2: fov
    #     col3: celline
    #     col4: treatment
    #     Change the first 4 columns from numeric value back to string value.
    #     """
    #     # args.metadata_cols = ["well_id", "treatment", "celline", "density", "dosage", "fov",]
    #     well_id, treatment, cellline, density, dosage = x[0], x[1], x[2], x[3], x[4]  # numeric values
    #     # print(dose, well_id, celline, treatment)
    #     well_id = args.num2wellid[well_id]
    #     treatment = args.num2treatment[treatment]
    #     cellline = args.num2cellline[cellline]
    #     density = args.num2density[density]
    #     dosage = args.num2dosage[dosage]
    #     x[0], x[1], x[2], x[3], x[4] = well_id, treatment, cellline, density, dosage  # string values
    #     return x
    w0_cols = [f"Nucleus-{it}" for it in args.cols[len(args.metadata_cols):]]
    w1_cols = [f"Cyto-{it}" for it in args.cols[len(args.metadata_cols):]]
    w2_cols = [f"Nucleoli-{it}" for it in args.cols[len(args.metadata_cols):]]
    w3_cols = [f"Actin-{it}" for it in args.cols[len(args.metadata_cols):]]
    w4_cols = [f"Mito-{it}" for it in args.cols[len(args.metadata_cols):]]
    w0_features = DataFrame(w0_features, columns=args.metadata_cols+w0_cols)
    w1_features = DataFrame(w1_features[:, len(args.metadata_cols):], columns=w1_cols)
    w2_features = DataFrame(w2_features[:, len(args.metadata_cols):], columns=w2_cols)
    w3_features = DataFrame(w3_features[:, len(args.metadata_cols):], columns=w3_cols)
    w4_features = DataFrame(w4_features[:, len(args.metadata_cols):], columns=w4_cols)

    features = pd.concat([w0_features,
                          w1_features,
                          w2_features,
                          w3_features,
                          w4_features,
                          ], axis=1)

    print("converting metadata cols to str ....")
    # features = np.apply_along_axis(convert_metadata_back_2_str, 1, features)
    # args.metadata_cols = ["well-id", "treatment", "cell-line", "density", "dosage", "fov", ]
    features["well-id"] = features["well-id"].apply(lambda x: args.num2wellid[x])
    features["treatment"] = features["treatment"].apply(lambda x: args.num2treatment[x])
    features["cell-line"] = features["cell-line"].apply(lambda x: args.num2cellline[x])
    features["density"] = features["density"].apply(lambda x: args.num2density[x])
    features["dosage"] = features["dosage"].apply(lambda x: args.num2dosage[x])
    print("conversion completed....")

    print("converted the 'features' numpy array to csv and saving it as a csv file....")
    features.to_csv(args.main_path / args.experiment / "features.csv", index=False, float_format="%.2f")


if __name__ == "__main__":
    args = create_shared_multiprocessing_name_space_object(args)
    ignore_imgaeio_warning()
    main(args)

    # img_path_groups, nucleus_mask_paths, w1_mask_paths, args.num_channels = \
    #     get_matching_img_group_nuc_mask_cyto_mask(args.main_path, args.experiment, args.lab, mask_folder="Masks")
    # img_path = img_path_groups[0][0]
    # img = tifffile.imread((img_path))
    # fig, axes = plt.subplots(1, 2)
    # axes[0].imshow(img, origin="upper", cmap="gray")
    # axes[1].imshow(img, origin="upper", cmap="gray")
    # axes[0].text(500, 500, 'KP', bbox=dict(fill=False, edgecolor='red', linewidth=2), fontsize=30, color='blue')
    # axes[1].text(500, 500, 'KP', bbox=dict(fill=False, edgecolor='red', linewidth=2), fontsize=30, color='blue')
    # plt.show()
