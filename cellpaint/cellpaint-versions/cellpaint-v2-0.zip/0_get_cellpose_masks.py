import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import numpy as np
# from pathlib import Path, WindowsPath
import itertools
import tifffile
from cellpose import models
from skimage import io

import SimpleITK as sitk
import matplotlib.pyplot as plt
from skimage.exposure import rescale_intensity
# from skimage.measure import label
# from skimage.color import label2rgb
# from skimage.segmentation import find_boundaries

from utils.args import args
from utils.image_and_mask_files import get_key_from_img_path, get_img_paths, \
    get_sitk_img_thresholding_mask_v1, get_overlay


# TODO: Add comments and functions and explanations
# TODO: NUM_CHANNELS calculation needs to be fixed!?
if args.testing:
    args.batch_size = 6


def get_batches(X, Y, batch_size):
    # batch generator
    n_samples = len(X)
    indices = np.arange(n_samples)
    # # Shuffle at the start of epoch
    # np.random.shuffle(indices)
    for start in range(0, n_samples, batch_size):
        end = np.minimum(start + batch_size, n_samples)
        batch_idx = indices[start:end]
        yield X[batch_idx], Y[batch_idx]


def main():
    """Read all the image tif files for the experiment as a list and sort them, "img_paths".
    Then divide the files into groups each containing the 4/5 channels of a single image, "img_paths_groups".
    for example,
    [[args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A01Z01C01.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A02Z01C02.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A03Z01C03.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A04Z01C04.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F001L01A05Z01C05.tif,],

    [args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A01Z01C01.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A02Z01C02.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A03Z01C03.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A04Z01C04.tif,
    args.main_path\args.experiment\f"{args.assay}"\f"{args.assay}"_B02_T0001F002L01A05Z01C05.tif,]

    Then define an iterator that creates batches of groups from those groups, "my_iter".
    Then feed those batches one at a time to cellpose for segmentation of nucleus and cytoplasm.
    Make sure batch_size does not equal the number of channels and also that it is a number small enough
    to fit all the images in the batch into your GPUs memory.
    Note that if the number of cells segmented in an image is smaller than "MIN_CELLS",
    meaning the FOV/image is mostly empty, this function will NOT save the corresponding mask into disk!!!

    First, quality check those segmentation by setting TESTING = True.
    Once satisfied, set the TESTING= False and run the code again.

    In addition make sure to choose a proper unique key for your experiment.
    for example the master folder containing the images.
    At the moment it is set as either "EXPERIMENT" or EXPIDS[your_index]

    Enjoy!!!"""

    MODEL = models.Cellpose(gpu=True, torch=True, model_type='cyto2')
    # f"{ASSAY}_A02_T0001F002L01A02Z01C01.tif"
    img_paths = get_img_paths(args.main_path, args.experiment, args.lab)

    # ################################################################
    # group files that are channels of the same image together.
    keys, img_paths_groups = [], []
    for item in itertools.groupby(
            img_paths, key=lambda x: get_key_from_img_path(x, args.lab, key_purpose="to_group_channels")):
        keys.append(item[0])
        img_paths_groups.append(list(item[1]))
    keys = np.array(keys, dtype=object)
    args.num_channels = len(img_paths_groups[0])
    print("num_channels: ", args.num_channels)
    assert args.batch_size > args.num_channels

    img_paths_groups = np.array(img_paths_groups, dtype=object)
    # create the generator object my_iter to read groups of images in batches
    # which significantly speeds up Cellpose's segmentation compared to reading one image at a time
    my_iter = get_batches(keys, img_paths_groups, batch_size=args.batch_size)
    ######################################################################

    for iii, (batch_keys, batch_paths) in enumerate(my_iter):
        # if batch_keys[0][1] not in ["O05", "O06", "P05", "P06"]:
        #     continue
        N = len(batch_paths)
        batch_imgs = np.zeros((N, args.num_channels, args.height, args.width), dtype=np.float32)

        # print(batch_keys[0])
        for jjj, pgroup in enumerate(batch_paths):
            for kkk, channel in enumerate(pgroup):
                batch_imgs[jjj, kkk] = tifffile.imread(channel)

        batch_masks_nucleus, _, _, _ = MODEL.eval(
            [it for it in batch_imgs],
            diameter=args.cellpose_nucleus_diam,
            channels=[1, 0],
            batch_size=N)
        batch_masks_cyto, _, _, _ = MODEL.eval(
            [it for it in batch_imgs],
            diameter=args.cellpose_cyto_diam,
            channels=[2, 1],
            batch_size=N)

        if args.testing:
            print(batch_keys)
            for item in batch_paths:
                for it in item:
                    print(it.stem)
                print('\n')

            for idx in range(0, 6):
                print(len(np.unique(batch_masks_nucleus[idx])))
                print(len(np.unique(batch_masks_cyto[idx])))
                print('\n')
                M0, m0, M1, m1 = \
                    np.amax(batch_imgs[idx, 0]), \
                    np.amin(batch_imgs[idx, 0]), \
                    np.amax(batch_imgs[idx, 1]), \
                    np.amin(batch_imgs[idx, 1])
                batch_imgs[idx, 0] = (batch_imgs[idx, 0] - m0) / (M0 - m0)
                batch_imgs[idx, 1] = (batch_imgs[idx, 1] - m1) / (M1 - m1)
                batch_imgs[idx, 0] = rescale_intensity(
                    batch_imgs[idx, 0],
                    in_range=tuple(np.percentile(batch_imgs[idx, 0], (40, 99.99))))
                batch_imgs[idx, 1] = rescale_intensity(
                    batch_imgs[idx, 1],
                    in_range=tuple(np.percentile(batch_imgs[idx, 1], (10, 99.9))))

                mito_channel = 3
                new_img = batch_imgs[idx, mito_channel].copy()
                new_img[batch_masks_cyto[idx] == 0] = 0
                new_img[batch_masks_nucleus[idx] > 0] = 0
                threshold_img_filter = sitk.MomentsThresholdImageFilter()
                threshold_img_filter.SetInsideValue(0)
                threshold_img_filter.SetOutsideValue(1)
                new_mask = get_sitk_img_thresholding_mask_v1(new_img, threshold_img_filter)
                # plt.imshow(new_mask)
                # plt.show()

                fig, axes = plt.subplots(2, 3, sharex=True, sharey=True)
                axes[0, 0].imshow(batch_imgs[idx, 0], cmap="gray")
                axes[0, 1].imshow(batch_imgs[idx, 1], cmap="gray")
                axes[0, 2].imshow(batch_imgs[idx, mito_channel], cmap="gray")
                axes[1, 0].imshow(get_overlay(batch_imgs[idx, 0], batch_masks_nucleus[idx], args.colors), cmap="gray")
                axes[1, 1].imshow(get_overlay(batch_imgs[idx, 1], batch_masks_cyto[idx], args.colors), cmap="gray")
                axes[1, 2].imshow(get_overlay(batch_imgs[idx, mito_channel], new_mask, args.colors), cmap="gray")
                plt.show()
        else:
            for lll, (key, mm0, mm1) in enumerate(zip(batch_keys, batch_masks_nucleus, batch_masks_cyto)):
                #####################################################################################################
                # If the total number of segmented cells in both DAPI and CYTO channels is small then skip that image
                if (len(np.unique(mm1)) + len(np.unique(mm0))) / 2 <= args.min_cell_count + 1:
                    continue
                ####################################################################################################
                # Create a savename choosing a name for the experiment name, and also using the well_id, and fov.
                well_id, fov = key[1], key[2]
                save_name = f"{args.expid}_{well_id}_{fov}"
                ####################################################################################################
                # Save the masks into disk
                io.imsave(args.cellpose_masks_path / f"w0_{save_name}.png", mm0, check_contrast=False)
                io.imsave(args.cellpose_masks_path / f"w1_{save_name}.png", mm1, check_contrast=False)
        # print('\n')

    # Read a few example for to check the quality of the segmentation
    ###########################################################################################
    # for mykey in [
    #     np.array([EXPERIMENT, "A01", "F001"]),
    #     np.array([EXPERIMENT, "B02", "F002"]),
    #     np.array([EXPERIMENT, "C03", "F003"]),
    #     np.array([EXPERIMENT, "D04", "F004"]),
    #     np.array([EXPERIMENT, "E04", "F005"]),
    #     np.array([EXPERIMENT, "F04", "F006"]),
    # ]:
    #     # print(MAIN_PATH/EXPERIMENT)
    #     for iii, (key, fpath_group) in enumerate(zip(keys, img_paths_groups)):
    #         N = len(fpath_group)
    #         # print(key)
    #         # print(fpath_group)
    #         # if iii == 2:
    #         #     break
    #         if np.array_equal(key, mykey):
    #             img = np.zeros((NUM_CHANNELS, HEIGHT, WIDTH), dtype=np.float32)
    #             print(keys[0][0], keys[0][1], keys[0][2])
    #             for kkk, channel in enumerate(fpath_group):
    #                 img[kkk] = tifffile.imread(channel)
    #
    #             mask0, _, _, _ = MODEL.eval(
    #                 img,
    #                 diameter=100,
    #                 channels=[1, 0],
    #                 batch_size=N)
    #             mask1, _, _, _ = MODEL.eval(
    #                 img,
    #                 diameter=100,
    #                 channels=[2, 1],
    #                 batch_size=N)
    #
    #             img[0] = rescale_intensity(img[0], in_range=tuple(np.percentile(img[0], (90, 99.99))))
    #             img[1] = rescale_intensity(img[1], in_range=tuple(np.percentile(img[1], (50, 99.9))))
    #
    #             fig, axes = plt.subplots(2, 2, sharex=True, sharey=True)
    #             axes[0, 0].imshow(img[0], cmap="gray")
    #             axes[0, 1].imshow(img[1], cmap="gray")
    #             axes[1, 0].imshow(get_overlay(img[0], mask0), cmap="gray")
    #             axes[1, 1].imshow(get_overlay(img[1], mask1), cmap="gray")
    #             plt.show()


if __name__ == "__main__":
    main()
