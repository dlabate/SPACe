from pprint import pprint
from tqdm import tqdm

import multiprocessing as mp
from functools import partial

import numpy as np
from pathlib import Path, WindowsPath
import re
import itertools
import tifffile

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as font_manager

import SimpleITK as sitk
from scipy.ndimage.morphology import binary_fill_holes


from skimage import exposure
from skimage.io import imread, imsave
from skimage.measure import label, regionprops_table
from skimage.segmentation import find_boundaries, clear_border, mark_boundaries
from skimage.morphology import disk, erosion, dilation, \
    binary_dilation, binary_erosion, binary_closing, remove_small_objects
from skimage.segmentation import watershed, expand_labels
from skimage.filters import threshold_triangle, threshold_otsu, gaussian
# from skimage import feature
# from skimage.color import label2rgb
# from skimage.restoration import rolling_ball, ellipsoid_kernel
# from skimage.exposure import rescale_intensity


from utils.args import args, ignore_imgaeio_warning, create_shared_multiprocessing_name_space_object
from utils.image_and_mask_files import get_matching_img_group_nuc_mask_cyto_mask, \
    load_img, get_sitk_img_thresholding_mask_v1, \
    get_overlay, move_figure, creat_segmentation_example_fig


def get_w0w1_masks_step1(mask0_path, mask1_path, file_path_group, args):
    img_thresholding_filter = sitk.OtsuThresholdImageFilter()
    img_thresholding_filter.SetInsideValue(0)
    img_thresholding_filter.SetOutsideValue(1)

    img = load_img(file_path_group, args.num_channels, args.height, args.width)

    # make sure mask0 and mask1 are both cast to uint16
    mask0 = imread(str(mask0_path)).astype(np.uint16)
    mask1 = imread(str(mask1_path)).astype(np.uint16)

    mask0 = clear_border(mask0)
    mask0[remove_small_objects(
        mask0.astype(bool),
        min_size=args.min_nucleus_size,
        connectivity=8).astype(int) == 0] = 0
    mask1 = clear_border(mask1)
    # remove nuclei with no cytoplasm
    mask0[mask1 == 0] = 0

    props00 = regionprops_table(
        mask1,
        intensity_image=mask0,
        properties=["intensity_image"])
    props10 = regionprops_table(
        mask1,
        intensity_image=img[args.dapi_channel_index],
        properties=["label", "image", "intensity_image", "bbox"])
    # total, cnt0, cnt1, cnt2 = len(props10["label"]), 0, 0, 0
    unix0 = np.unique(mask0)
    unix1 = np.unique(mask1)

    counter0 = unix0[-1]
    counter1 = unix1[-1]
    for iiiiii, (ll, ii, tmp0, mm,  y0, x0, y1, x1) in \
        enumerate(zip(
            props10["label"],
            props10["intensity_image"],
            props00["intensity_image"],
            props10["image"],
            props10["bbox-0"],
            props10["bbox-1"],
            props10["bbox-2"],
            props10["bbox-3"],
            )):

        if np.sum(mm) < args.min_nucleus_size:
            mask1[mask1 == ll] = 0
            mask0[mask1 == ll] = 0
            continue

        # # removing edge artifact, so that the two masks do not touch on the bd
        tmp0_props = regionprops_table(tmp0, properties=["label", "area"])
        idxs = tmp0_props["label"][tmp0_props["area"] < 400]
        tmp0[np.isin(tmp0, idxs)] = 0

        uu = np.unique(tmp0)
        # print(ll, len(uu), uu)
        if len(uu) == 2:
            # cnt1 += 1
            continue

        # there is cytoplasm but no nuclei inside
        # segment inside of it in nuclei channel
        elif len(uu) == 1:

            tmp0 = get_sitk_img_thresholding_mask_v1(ii, img_thresholding_filter)
            tmp0 = binary_closing(tmp0, disk(8))
            tmp0 = binary_fill_holes(tmp0, structure=np.ones((2, 2)))
            if np.sum(tmp0) < args.min_nucleus_size:
                mask1[mask1 == ll] = 0
                continue
            # # remove small noisy dots
            # tmp0 = label(tmp0, connectivity=2)
            # tmp_props = regionprops_table(tmp0, properties=("label", "area"))
            # idxs = tmp_props["label"][tmp_props["area"] < 400]
            # tmp0[np.isin(tmp0, idxs)] = 0

            # fig, axes = plt.subplots(1, 2, sharex=True, sharey=True)
            # axes[0].imshow(tmp0, cmap="gray")
            # axes[1].imshow(ii, cmap="gray")
            # plt.show()
            mask0[y0:y1, x0:x1][tmp0 > 0] = tmp0[tmp0 > 0]+counter0
            # cnt0 += 1
            counter0 += 1

        elif len(uu) > 2:  # there is cytoplasm but more than one nuclei

            # segment and break down this cyto based on the nucleous
            tmp1 = watershed(
                mm,
                markers=tmp0,
                connectivity=tmp0.ndim,
                mask=mm)
            shape = tmp1.shape
            tmp_unix, tmp1 = np.unique(tmp1, return_inverse=True)
            tmp1 = tmp1.reshape(shape)

            mask1[y0:y1, x0:x1][tmp1 > 0] = tmp1[tmp1 > 0]+counter1
            counter1 += len(np.setdiff1d(tmp_unix, [0]))
            # cnt2 += 1
            # fig, axes = plt.subplots(3, 2, sharex=True, sharey=True)
            # axes[1, 0].imshow(label2rgb(tmp0, bg_label=0), cmap="gray")
            # axes[2, 0].imshow(label2rgb(mm, bg_label=0), cmap="gray")
            # axes[2, 1].imshow(label2rgb(tmp1, bg_label=0), cmap="gray")
            # plt.show()
    # print(total, 100*cnt0/total, 100*cnt1/total, 100*cnt2/total)
    # # remove noisy bd effects
    mask_bd = find_boundaries(
        mask1,
        connectivity=2,
        mode="inner").astype(np.uint16)
    mask_bd = binary_dilation(mask_bd, disk(2))
    mask0[(mask0 > 0) & mask_bd] = 0
    mask0[remove_small_objects(
        mask0.astype(bool),
        min_size=400,
        connectivity=8).astype(int) == 0] = 0

    # match the labels for mask1 and mask0
    _, mask1 = np.unique(mask1, return_inverse=True)
    mask1 = mask1.reshape((args.height, args.width))
    mask1 = np.uint16(mask1)
    mask0[mask0 > 0] = mask1[mask0 > 0]
    # remove the leftovers from matching step
    diff = np.setdiff1d(np.unique(mask1), np.unique(mask0))
    mask1[np.isin(mask1, diff)] = 0
    # # trim mask1 a bit
    # mask1 = erosion(mask1, disk(1))
    # if args.testing and args.show_intermediate_steps:
    #     if args.rescale_image:
    #         img[args.dapi_channel_index] = rescale_intensity(img[
    #         args.dapi_channel_index],
    #         in_range=tuple(np.percentile(img[args.dapi_channel_index], (70, 99.99))))
    #         img[args.cyto_channel_index] = rescale_intensity(
    #         img[args.cyto_channel_index],
    #         in_range=tuple(np.percentile(img[args.cyto_channel_index], (50, 99.9))))
    #     fig, axes = plt.subplots(2, 3, sharex=True, sharey=True)
    #     axes[0, 0].imshow(img[args.dapi_channel_index], cmap="gray")
    #     axes[1, 0].imshow(img[args.cyto_channel_index], cmap="gray")
    #     axes[0, 1].imshow(get_overlay(img[args.dapi_channel_index], mask0, args.colors), cmap="gray")
    #     axes[1, 1].imshow(get_overlay(img[args.cyto_channel_index], mask0, args.colors), cmap="gray")
    #     axes[0, 2].imshow(get_overlay(img[args.dapi_channel_index], mask1, args.colors), cmap="gray")
    #     axes[1, 2].imshow(get_overlay(img[args.cyto_channel_index], mask1, args.colors), cmap="gray")
    #     plt.show()

    assert np.array_equal(np.unique(mask0), np.unique(mask1))
    return mask0, mask1, img


def get_w0_mask_step2(mask0, mask1, img, args):
    img_thresholding_filter = sitk.OtsuThresholdImageFilter()
    img_thresholding_filter.SetInsideValue(0)
    img_thresholding_filter.SetOutsideValue(1)

    assert np.array_equal(np.unique(mask0), np.unique(mask1))
    # Condition: if nuclei mask and cyto mask overlap than 70 percent, then we will redo that nuclei mask
    props0 = regionprops_table(mask0,
                               properties=("area", "label"))
    props1 = regionprops_table(mask1,
                               img[args.dapi_channel_index],
                               properties=("area", "bbox", "image", "intensity_image"))
    cond = (props0["area"] / props1["area"]) > .6
    if np.sum(cond) >= 1:
        for (y0, x0, y1, x1, llabel, area, lmask1, limg01) in zip(
                props1["bbox-0"][cond],
                props1["bbox-1"][cond],
                props1["bbox-2"][cond],
                props1["bbox-3"][cond],
                props0["label"][cond],
                props0["area"][cond],
                props1["image"][cond],
                props1["intensity_image"][cond]):

            limg01 = gaussian(limg01, sigma=3)
            limg01 = exposure.rescale_intensity(
                limg01,
                in_range=tuple(np.percentile(limg01, (50, 90))))
            # rewrite the nuclei mask with a new mask
            lmask2 = get_sitk_img_thresholding_mask_v1(limg01, myfilter=img_thresholding_filter)
            # remove small nuclei
            if np.sum(lmask2) < args.min_nucleus_size:
                continue
            # zero out the previous mask
            mask0[y0:y1, x0:x1][lmask1 > 0] = 0
            # add in the new mask at the same location
            mask0[y0:y1, x0:x1][lmask2 > 0] = llabel
    assert np.array_equal(np.unique(mask0), np.unique(mask1))

    # if args.testing and args.show_intermediate_steps:
    #     fig, axes = plt.subplots(2, 3, sharex=True, sharey=True)
    #     axes[0, 0].imshow(img[0], cmap="gray")
    #     axes[1, 0].imshow(img[1], cmap="gray")
    #
    #     axes[0, 1].imshow(get_overlay(img[0], mask0, args.colors), cmap="gray")
    #     axes[1, 1].imshow(get_overlay(img[1], mask0, args.colors), cmap="gray")
    #
    #     axes[0, 2].imshow(get_overlay(img[0], mask1, args.colors), cmap="gray")
    #     axes[1, 2].imshow(get_overlay(img[1], mask1, args.colors), cmap="gray")
    #
    #     plt.show()

    return mask0, img


def get_nucleoli_mask(mask0, mask1, img, args):
    # nucleoli
    # mask0d = dilation(mask0, disk(2))
    img_thresholding_filter = sitk.YenThresholdImageFilter()
    img_thresholding_filter.SetInsideValue(0)
    img_thresholding_filter.SetOutsideValue(1)

    mask2 = np.zeros_like(mask0)
    props01 = regionprops_table(
        mask0,
        intensity_image=img[args.nucleoli_channel_index],
        properties=["label", "image", "intensity_image", "bbox", "area"])
    for iiiiii, (ll, ii, mm, y0, x0, y1, x1, nuc_area) in \
            enumerate(zip(
                props01["label"],
                props01["intensity_image"],
                props01["image"],
                props01["bbox-0"],
                props01["bbox-1"],
                props01["bbox-2"],
                props01["bbox-3"],
                props01["area"],
            )):
        val = threshold_otsu(ii)
        lb = np.sum(ii < val) / np.size(ii)
        ii = gaussian(ii, sigma=1)
        ii = exposure.rescale_intensity(
            ii,
            in_range=tuple(np.percentile(ii, (lb, args.nucleoli_channel_rescale_intensity_percentile_ub))))
        # (40, 88), (30, 95)
        min_nucleoli_size = args.min_nucleoli_size_multiplier * (np.sum(mm))
        max_nucleoli_size = args.max_nucleoli_size_multiplier * (np.sum(mm))

        bd = find_boundaries(
            np.pad(mm, ((5, 5), (5, 5)), mode='constant', constant_values=(0, 0)),
            connectivity=2)
        bd = bd[5:-5, 5:-5]
        bd = binary_dilation(bd, disk(3))

        tmp = get_sitk_img_thresholding_mask_v1(ii, img_thresholding_filter).astype(np.uint16)
        # tmp1 = tmp.copy()
        tmp = binary_erosion(tmp, disk(1))
        # tmp2 = tmp.copy()
        tmp = label(tmp, connectivity=2)
        tmp_props = regionprops_table(tmp, properties=["label", "area"])
        tmp_bd_props = regionprops_table(tmp * bd, properties=["label", "area"])
        inds = []
        for kkk in tmp_bd_props["label"]:
            if tmp_bd_props['area'][tmp_bd_props["label"] == kkk] / \
                    tmp_props['area'][tmp_props["label"] == kkk] > args.nucleoli_bd_area_to_nucleoli_area_threshold:
                inds.append(kkk)
        tmp[np.isin(tmp, inds)] = 0
        cond = (tmp_props["area"] < min_nucleoli_size) | \
               (tmp_props["area"] > max_nucleoli_size)
        inds = tmp_props["label"][cond]
        tmp[np.isin(tmp, inds)] = 0

        # fig, axes = plt.subplots(1, 7, sharex=True, sharey=True)
        # axes[0].imshow(img[args.dapi_channel_index][y0:y1, x0:x1], cmap="gray")
        # axes[1].imshow(ii, cmap="gray")
        # axes[2].imshow(mm, cmap="gray")
        # axes[3].imshow(tmp1, cmap="gray")
        # axes[4].imshow(tmp2, cmap="gray")
        # axes[5].imshow(bd, cmap="gray")
        # axes[6].imshow(tmp, cmap="gray")
        # plt.show()
        mask2[y0:y1, x0:x1][tmp > 0] = ll

    if args.testing and args.show_intermediate_steps:
        fig, axes = plt.subplots(1, 3, sharex=True, sharey=True)
        fig.set_size_inches(13, 9)
        move_figure(fig, 30, 30)
        names = ["Raw Image", "Nuclei Mask", "Cytoplasm Mask", "Nucleoli Mask"]
        # for ii, ax in enumerate(axes.flatten()):
        #     if ii == 0:
        #         ax.set_xticks([])
        #         ax.set_yticks([])
        #         ax.set_ylabel("Nuclei Channel", **args.csfont)
        #     elif ii == 4:
        #         ax.set_ylabel("Cytoplasm Channel", **args.csfont)
        #         ax.set_xticks([])
        #         ax.set_yticks([])
        #     else:
        #         ax.axis('off')
        #     if ii in [0, 1, 2, 3]:
        #         ax.set_title(names[ii], **args.csfont)
        #     else:
        #         ax.set_title("")

        axes[0].imshow(get_overlay(img[args.dapi_channel_index], mask0, args.colors), cmap="gray")
        axes[1].imshow(get_overlay(img[args.cyto_channel_index], mask1, args.colors), cmap="gray")
        axes[2].imshow(get_overlay(img[args.nucleoli_channel_index], mask2, args.colors), cmap="gray")
        axes[0].set_title("Nucleus Channel", **args.csfont)
        axes[1].set_title("Cytoplasm Channel", **args.csfont)
        axes[2].set_title("Nucleoli Channel", **args.csfont)
        plt.show()
    return mask2


def get_masks(triplet, args):
    mask0_path, mask1_path, filepath_group = triplet
    mask0, mask1, img = get_w0w1_masks_step1(mask0_path, mask1_path, filepath_group, args)
    mask0, img = get_w0_mask_step2(mask0, mask1, img, args)
    mask2 = get_nucleoli_mask(mask0, mask1, img, args)
    # mask1[mask0 > 0] = 0
    assert mask0.dtype == mask1.dtype == mask2.dtype == np.uint16

    imsave(args.final_masks_path / f"{mask0_path.stem}.png", mask0, check_contrast=False)
    imsave(args.final_masks_path / f"{mask1_path.stem}.png", mask1, check_contrast=False)
    imsave(args.final_masks_path / f"w2_{'_'.join(mask1_path.stem.split('_')[1:])}.png",
           mask2,
           check_contrast=False)
    if args.testing:
        return img, mask0, mask1, mask2


def main_worker(args):
    # TODO: Get number of channels as an independent separate step
    # TODO: Check nucleus area at every single stage.
    img_path_groups, mask0_paths, mask1_paths, args.num_channels = \
        get_matching_img_group_nuc_mask_cyto_mask(args.main_path, args.experiment, args.lab)

    if args.testing:
        for iiii, (m0, m1, fp_group) in enumerate(zip(
                mask0_paths, mask1_paths, img_path_groups)):

            well_id = m0.stem.split("_")[2]
            fov = m0.stem.split("_")[3]
            # print(well_id)
            # choose some specific well-ids you like to check for quality control
            # if well_id == "A01" and fov == "F004":
            print(m0.stem)
            img, mask0, mask1, mask2 = get_masks((m0, m1, fp_group), args)
            # print(config.num_channels)
            # creat_segmentation_example_fig(img, mask0, mask1, mask2, m0)

    else:
        args = create_shared_multiprocessing_name_space_object(args)
        # for key, item in args.items():
        #     print(key)
        #     print(item)
        #     print('\n')
        total = len(mask0_paths)
        myfn = partial(get_masks, args=args)
        with mp.Pool(processes=mp.cpu_count(),) as pool:
            # print(args)
            # print(args.num_channels)
            for _, _ in tqdm(enumerate(pool.imap(
                    myfn,
                    zip(mask0_paths, mask1_paths, img_path_groups))),
                    total=total):
                pass


if __name__ == "__main__":
    ignore_imgaeio_warning()
    mp.freeze_support()
    main_worker(args)


