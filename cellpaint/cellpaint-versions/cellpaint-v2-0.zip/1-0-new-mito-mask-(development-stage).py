from pprint import pprint
from tqdm import tqdm

import multiprocessing as mp
from functools import partial

import numpy as np
from pathlib import Path, WindowsPath
import re
import itertools
import tifffile

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as font_manager

import SimpleITK as sitk
from scipy.ndimage.morphology import binary_fill_holes


from skimage import exposure
from skimage.io import imread, imsave
from skimage.measure import label, regionprops_table
from skimage.segmentation import find_boundaries, clear_border, mark_boundaries
from skimage.morphology import disk, erosion, dilation, \
    binary_dilation, binary_erosion, binary_closing, remove_small_objects
from skimage.segmentation import watershed, expand_labels
from skimage.filters import threshold_triangle, threshold_otsu, gaussian
from skimage import feature
# from skimage.color import label2rgb
# from skimage.restoration import rolling_ball, ellipsoid_kernel
from skimage.exposure import rescale_intensity

from PIL import Image

from utils.args import args, ignore_imgaeio_warning, create_shared_multiprocessing_name_space_object
from utils.image_and_mask_files import get_matching_img_group_nuc_mask_cyto_mask, \
    load_img, get_sitk_img_thresholding_mask_v1, \
    get_overlay, move_figure, creat_segmentation_example_fig

# for it, key in args.wellid2treat.items():
#     print(it, key)

img_path_groups, mask0_paths, mask1_paths, args.num_channels = \
    get_matching_img_group_nuc_mask_cyto_mask(args.main_path, args.experiment, args.lab, mask_folder="Masks")
# for it in mask0_paths:
#     print(it)
mask2_paths = [it.parents[0] / f"w2_{'_'.join(it.stem.split('_')[1:])}.png" for it in mask0_paths]

# img_path_groups0 = [it
#                    for it in img_path_groups
#                    if args.wellid2treat[it[0].stem.split("_")[-2]] in ["berberine", ]]
# img_path_groups1 = [it
#                    for it in img_path_groups
#                    if args.wellid2treat[it[0].stem.split("_")[-2]] in ["veh", ]]
#
#
# for it0, it1 in zip(img_path_groups0, img_path_groups1):
#     wellid0 = it0[0].stem.split("_")[-2]
#     wellid1 = it1[0].stem.split("_")[-2]
#
#     img0 = load_img(it0, args.num_channels, args.height, args.width)
#     img1 = load_img(it1, args.num_channels, args.height, args.width)
#     # print(wellid, img.shape, treatment)
#     fig, axes = plt.subplots(2, 5, sharex=True, sharey=True)
#     for jj in range(0, 5):
#         axes[0, jj].imshow(img0[jj], cmap="gray")
#         axes[0, jj].set_title("berberine")
#         axes[1, jj].imshow(img1[jj], cmap="gray")
#         axes[1, jj].set_title("veh")
#     plt.show()

f1 = sitk.OtsuThresholdImageFilter()
f1.SetInsideValue(0)
f1.SetOutsideValue(1)

f2 = sitk.MomentsThresholdImageFilter()
f2.SetInsideValue(0)
f2.SetOutsideValue(1)

f3 = sitk.MaximumEntropyThresholdImageFilter()
f3.SetInsideValue(0)
f3.SetOutsideValue(1)


for it0, it1, it2, it3 in zip(img_path_groups, mask0_paths, mask1_paths, mask2_paths):
    if args.wellid2treatment[it0[0].stem.split("_")[-2]] not in ["veh","berberine",]:
        continue
    img = load_img(it0, args.num_channels, args.height, args.width)
    mask0 = np.array(Image.open(it1)).astype(np.uint16)  # nucleus mask
    mask1 = np.array(Image.open(it2)).astype(np.uint16)  # cyto/mito mask
    mask2 = np.array(Image.open(it3)).astype(np.uint16)  # nucleoli mask

    # relabel mask2 with the nuclei/cytoplasm masks (already matching) labels
    mask2[mask2 > 0] = mask0[mask2 > 0]
    tmp_img = img[-1].copy()
    tmp_img[(mask1 == 0) & (mask0 > 0)] = 0
    mask_global = get_sitk_img_thresholding_mask_v1(tmp_img, f1)
    mask_global_canny = feature.canny(img[-1], sigma=1)
    # mask_global = np.logical_or(mask_global, mask_canny)

    mask_local = np.zeros_like(mask1)
    mask_local_canny = np.zeros_like(mask1)
    props = regionprops_table(mask1, img[-1], properties=["label", "bbox", "intensity_image"])
    for lb, limg, y0, x0, y1, x1 in zip(
            props["label"],
            props["intensity_image"],
            props["bbox-0"],
            props["bbox-1"],
            props["bbox-2"],
            props["bbox-3"]):
        scaled_img = rescale_intensity(limg, in_range=tuple(np.percentile(limg, [5, 99])))
        mask_canny_tmp = feature.canny(scaled_img, sigma=1)
        tmp_mask = get_sitk_img_thresholding_mask_v1(scaled_img, f1)

        mask_local[y0:y1, x0:x1][tmp_mask > 0] = (tmp_mask[tmp_mask > 0])
        mask_local_canny[y0:y1, x0:x1][mask_canny_tmp > 0] = (mask_canny_tmp[mask_canny_tmp > 0])

    # mask1[mask0 > 0] = 0
    # mask_global_canny[mask1 == 0] = 0
    # mask_global[mask1 == 0] = 0
    # mask_local[mask1 == 0] = 0
    # mask_local_canny[mask1 == 0] = 0

    # tmp_img1 = img[-1].copy()
    # tmp_img1 = tmp_img1
    img[-1] = rescale_intensity(img[-1], in_range=tuple(np.percentile(img[-1], [10, 99.9])))
    fig, axes = plt.subplots(3, 3, sharex=True, sharey=True)
    axes[0, 0].imshow(img[-1], cmap="gray")
    axes[0, 0].set_title("raw image")

    axes[0, 1].imshow(mask_global_canny, cmap="gray")
    axes[0, 1].set_title("global canny mask")

    axes[0, 2].imshow(mask_local_canny, cmap="gray")
    axes[0, 2].set_title("local canny mask")

    axes[1, 0].imshow(mask_global, cmap="gray")
    axes[1, 0].set_title("global thresholding mask")

    axes[1, 1].imshow(mask_local, cmap="gray")
    axes[1, 1].set_title("local thresholding mask")

    axes[1, 2].imshow(np.logical_or(mask_global, mask_local), cmap="gray")
    axes[1, 2].set_title("local thresholding and global thresholding mask")

    axes[2, 0].imshow(np.logical_or(mask_global, mask_global_canny), cmap="gray")
    axes[2, 0].set_title("global thresholding and global canny mask")

    axes[2, 1].imshow(np.logical_or(mask_local, mask_local_canny), cmap="gray")
    axes[2, 1].set_title("local and local canny mask")

    axes[2, 2].imshow((mask_global.astype(bool) | mask_local.astype(bool) | mask_global_canny.astype(bool)), cmap="gray")
    axes[2, 2].set_title("local thresholding, global thresholding, and global canny mask")

    # axes[1, 2].set_axis_off()
    # axes[1, 2].imshow(np.logical_or(mask3, mask6), cmap="gray")
    # axes[0, 2].imshow(mask3, cmap="gray")
    # axes[1, 0].imshow(mask4, cmap="gray")
    # axes[1, 1].imshow(mask5, cmap="gray")
    plt.suptitle(it1.stem)
    plt.show()
